/////////////////////////////////////////////////////////////////////////////
// Name:        BgHarrisCorners.cpp
// Purpose:     BgHarrisCorners class functions
// Author:      Bogdan Georgescu
// Modified by:
// Created:     06/22/2000
// Copyright:   (c) Bogdan Georgescu
// Version:     v0.1
/////////////////////////////////////////////////////////////////////////////
#include <math.h>
#include <stdio.h>
#include "BgImage.h"
#include "BgHarrisCorners.h"

extern double factorial(double);

BgHarrisCorners::BgHarrisCorners(int kSize, int vecSize, double cPerc)
{
   kSize_ = WL_ = kSize;
   WW_ = 2*WL_+1;
   vecSize_ = vecSize;
   wSize_ = 2*vecSize_+1;
   elimSize_ = vecSize;//+4;
   cPerc_ = cPerc;
   cTresh_ = CORNER_TRESH;
   gfilter_ = 0;
   CreateFilters();
}

BgHarrisCorners::~BgHarrisCorners()
{
   if (gfilter_ != 0)
      delete [] gfilter_;
}

void BgHarrisCorners::DoHarrisCorners(BgImage* cim, int* cornx, int* corny, int* nCorn)
{
   x_ = cim->x_;
   y_ = cim->y_;
   float* grx;
   float* gry;
   float* lambda2;

   grx = new float[x_*y_];
   gry = new float[x_*y_];
   lambda2 = new float[x_*y_];

   BgImage* tempim;

   if (cim->colorIm_ == true)
   {
      tempim = new BgImage(x_, y_, false);
      cim->GetImageBW(tempim->im_);
   } else
   {
      tempim = cim;
   }


   GaussDiffFilter(tempim, grx, gry);

   ComputeLambda2(grx, gry, lambda2);


   // use grx as possible corners (memory)
   float* posCorners;
   posCorners = grx;
   ComputeCorners(lambda2, posCorners);
   int i,j;

	*nCorn = 0;
   //sorted on y
   // xcorn and ycorn memory must be allocated
	for (j=vecSize_; j<(y_-vecSize_); j++)
   {
		for (i=vecSize_; i<(x_-vecSize_); i++)
      {
			if (posCorners[j*x_+i]>cTresh_)
         {
				cornx[*nCorn] = i;
				corny[*nCorn] = j;
				*nCorn += 1;
			}
		}
	}

   if (cim->colorIm_ == true)
      delete tempim;

   delete [] lambda2;
   delete [] gry;
   delete [] grx;
}

void BgHarrisCorners::GaussDiffFilter(BgImage* cim, float* grx, float* gry)
{
   
#ifdef DEBUG_H_CORN
   printf("Gaussian-Weighted Differentiation filtering\n");
#endif
   double* sf; //smooth filter
   double* df; //diff filter
   unsigned char* im;
   
   double* tim;
   double sum = 0;
   double sum1 = 0;
   int i, j, k;
   
   //create kernels
   sf = smofil_;
   df = diffil_;
   
   im = cim->im_;
   tim = new double[x_*y_];
   for (i=0; i<x_*y_; i++)
   {
      grx[i] = gry[i] = 0;
      tim[i] = 0;
   }

   //filter image x
   //smooth on y
   for (i=0; i<x_; i++)
   {
      for (j=WL_; j<(y_-WL_); j++)
      {
         sum = 0;
         for (k=-WL_; k<=WL_; k++)
            sum += im[(j+k)*x_+i]*sf[k+WL_];
         tim[j*x_+i] = sum;
      }
   }
   //diff on x
   for (j=0; j<y_; j++)
   {
      for (i=WL_; i<(x_-WL_); i++)
      {
         sum = 0;
         for (k=-WL_; k<=WL_; k++)
            sum += tim[j*x_+i+k]*df[k+WL_];
         grx[j*x_+i] = (float) (sum);
      }
   }

   //filter image y
   for (i=0; i<x_*y_;i++)
      tim[i] = 0;
   im = cim->im_;
   //smooth on x
   for (j=0; j<y_; j++)
   {
      for (i=WL_; i<(x_-WL_); i++)
      {
         sum = 0;
         for (k=-WL_; k<=WL_; k++)
            sum += im[j*x_+i+k]*sf[k+WL_];
         tim[j*x_+i] = sum;
      }
   }
   //diff on y
   for (i=0; i<x_; i++)
   {
      for (j=WL_; j<(y_-WL_); j++)
      {
         sum = 0;
         for (k=-WL_; k<=WL_; k++)
            sum += tim[(j+k)*x_+i]*df[k+WL_];
         gry[j*x_+i] = (float) (sum);
      }
   }
   delete [] tim;
}

void BgHarrisCorners::CreateFilters(void)
{
   int i,j;
   double w;
   for (i=-WL_; i<=WL_; i++)
   {
      w = pow(2,(-2*WL_))*factorial(2*WL_)/(factorial(WL_-i)*factorial(WL_+i));
      smofil_[i+WL_] = w;
      diffil_[i+WL_] = (2*i*w)/WL_;
   }
   //create weight kernel
   if (gfilter_ != 0)
      delete [] gfilter_;
   gfilter_ = new double[wSize_*wSize_];
   double sum = 0;
   double har_sigma2_good = vecSize_ / HAR_SIGMA;
   har_sigma2_good *= har_sigma2_good;
   for (i=-vecSize_; i<=vecSize_; i++)
   {
      for (j=-vecSize_; j<=vecSize_; j++)
      {
         sum += gfilter_[(i+vecSize_)*wSize_+j+vecSize_] = exp(-i*i/(2.0*har_sigma2_good))*exp(-j*j/(2.0*har_sigma2_good));
      }
   }
   for (i=0; i<(wSize_*wSize_); i++)
      gfilter_[i] /= sum;

}

void BgHarrisCorners::ComputeLambda2(float* grx, float* gry, float* lambda2)
{
   
   int i,j,ki,kj;
   double a,b,c;
   double gx,gy,gf;
   for (i=0; i<x_*y_; i++)
      lambda2[i] = 0;

   // just for sake
//   double* lambda1;
//   lambda1 = new double[x_*y_];
//   double gg;

   for (j= vecSize_; j<(y_-vecSize_); j++)
   {
      for (i=vecSize_; i<(x_-vecSize_); i++)
      {
         a = b = c = 0;
         for (kj=-vecSize_; kj<=vecSize_; kj++)
         {
            for (ki=-vecSize_; ki<=vecSize_; ki++)
            {
               /* one way of weighting
               gx = gfilter_[(kj+vecSize_)*kSize_+ki+vecSize_]*grx[(j+kj)*x_+i+ki];
               gy = gfilter_[(kj+vecSize_)*kSize_+ki+vecSize_]*gry[(j+kj)*x_+i+ki];
               a += gx*gx;
               b += gx*gy;
               c += gy*gy;
               */

               /* other way of weighting */
               gf=gfilter_[(kj+vecSize_)*wSize_+ki+vecSize_];
               gx = grx[(j+kj)*x_+i+ki];
               gy = gry[(j+kj)*x_+i+ki];
               a += gf*gx*gx;
               b += gf*gx*gy;
               c += gf*gy*gy;
            }
         }
         //find eigv
         lambda2[j*x_+i] = (float) (((a+c)-sqrt((a-c)*(a-c)+4*b*b))/2.0);

         // way with determinants and trace
         //lambda2[j*x_+i] = (float) ((a*c - b*b) - 0.04*(a+c)*(a+c));

         // alternate way
         /*
         gg = (((a+c)+sqrt((a-c)*(a-c)+4*b*b))/2.0);
         if (gg>0)
            lambda2[j*x_+i] = (float) ((((a+c)-sqrt((a-c)*(a-c)+4*b*b))/2.0)/gg);
         else
            lambda2[j*x_+i] = 0;
         */

//         lambda1[j*x_+i] = (float) (((a+c)+sqrt((a-c)*(a-c)+4*b*b))/2.0);
      }
   }
   // compute treshold 
   double lambdamax = -1;
   for (i=0; i<x_*y_; i++)
   {
      if (lambda2[i] > lambdamax)
         lambdamax = lambda2[i];
   }
   cTresh_ =  cPerc_*lambdamax;
/*
   // save lambda2 values
   FILE* fld;
   fld = fopen("lambda2val.txt","w");
   for (i=0; i<x_*y_; i++)
      fprintf(fld, "%f\n",lambda2[i]);
   fclose(fld);
   // save lambda2/lambda1 values
   //FILE* fld;
   fld = fopen("lambda21val.txt","w");
   for (i=0; i<x_*y_; i++)
   {
      if (lambda1[i]>0)
      {
        fprintf(fld, "%f\n",lambda2[i]/lambda1[i]);
      }
      else
      {
         fprintf(fld, "0\n");
      }
   }
   fclose(fld);
*/

}

void BgHarrisCorners::ComputeCorners(float* lambda2, float* corn)
{
   
   int i,j,ki,kj;
   bool do_cont;
   for (i=0; i<x_*y_; i++)
      corn[i] = 0;
   
   for (j=elimSize_; j<(y_-elimSize_); j++)
   {
      for (i = elimSize_; i<(x_-elimSize_); i++)
      {

         if (lambda2[j*x_+i]>cTresh_)
         {
            corn[j*x_+i] = lambda2[j*x_+i];
            do_cont = true;
            for (kj=-elimSize_; kj<=elimSize_ && do_cont; kj++)
            {
               for (ki=-elimSize_; ki<=elimSize_ && do_cont; ki++)
               {
                  if(lambda2[j*x_+i]<lambda2[(j+kj)*x_+i+ki])
                  {
                     corn[j*x_+i] = 0;
                     do_cont = false;
                  }
               }
            }

         }
      }
   }
}


void BgHarrisCorners::DoHarrisCorners(BgImage* cim, float* cornx, float* corny, int* nCorn)
{
   // do an additional weighting for subpixel accuracy
   x_ = cim->x_;
   y_ = cim->y_;
   float* grx;
   float* gry;
   float* lambda2;

   grx = new float[x_*y_];
   gry = new float[x_*y_];
   lambda2 = new float[x_*y_];

   BgImage* tempim;

   if (cim->colorIm_ == true)
   {
      tempim = new BgImage(x_, y_, false);
      cim->GetImageBW(tempim->im_);
   } else
   {
      tempim = cim;
   }

   GaussDiffFilter(tempim, grx, gry);

   ComputeLambda2(grx, gry, lambda2);


   //sorted on y
   // xcorn and ycorn memory must be allocated and also compute subpixel accuracy
   ComputeSubpixelCorners(lambda2, cornx, corny, nCorn);

   // save corners for matlab
   /*
   FILE* fd;
   fd = fopen("ctest.txt", "wb");
   int i;
   for (i=0; i<(*nCorn); i++)
      fprintf(fd,"%g\n", lambda2[int(cornx[i]) + int(corny[i])*x_]);
   fclose(fd);
   */

   if (cim->colorIm_ == true)
      delete tempim;

   delete [] lambda2;
   delete [] gry;
   delete [] grx;
}

void BgHarrisCorners::ComputeSubpixelCorners(float* lambda2, float* cornx, float* corny, int* nCorn)
{
   int nc;
   nc = 0;
   
   int i,j,ki,kj;
   bool do_cont;
   float* tlambda2;
   double tval1, tval2, tsum;

   for (j=elimSize_; j<(y_-elimSize_); j++)
   {
      for (i = elimSize_; i<(x_-elimSize_); i++)
      {

         if (lambda2[j*x_+i]>cTresh_)
         {
            tlambda2 = & (lambda2[j*x_+i]);
            do_cont = true;

            for (kj=-elimSize_; kj<=elimSize_ && do_cont; kj++)
            {
               for (ki=-elimSize_; ki<=elimSize_ && do_cont; ki++)
               {
                  if(*tlambda2 < lambda2[(j+kj)*x_+i+ki])
                  {
                     do_cont = false;
                  }
               }
            }

            if (do_cont == true) {
               // good corner, compute it
               tval2 = tsum = *(tlambda2-x_-1) + *(tlambda2-1) + *(tlambda2+x_-1);
               tval1 = (i-1.0) * tval2;
               tval2 = *(tlambda2-x_) + *(tlambda2) + *(tlambda2+x_);
               tsum += tval2;
               tval1 += (i-0.0) * tval2;
               tval2 = *(tlambda2-x_+1) + *(tlambda2+1) + *(tlambda2+x_+1);
               tsum += tval2;
               tval1 += (i+1.0) * tval2;
               tval1 /= tsum;
               cornx[nc] = (float) tval1;

               tval2 = tsum = *(tlambda2-x_-1) + *(tlambda2-x_) + *(tlambda2-x_+1);
               tval1 = (j-1.0) * tval2;
               tval2 = *(tlambda2-1) + *(tlambda2) + *(tlambda2+1);
               tsum += tval2;
               tval1 += (j-0.0) * tval2;
               tval2 = *(tlambda2+x_-1) + *(tlambda2+x_) + *(tlambda2+x_+1);
               tsum += tval2;
               tval1 += (j+1.0) * tval2;
               tval1 /= tsum;
               corny[nc] = (float) tval1;
               nc++;
            }
         }
      }
   }
   *nCorn = nc;
}