/////////////////////////////////////////////////////////////////////////////
// Name:        BgImageProcessing.h
// Purpose:     BgImageProcessing class
// Author:      Bogdan Georgescu
// Modified by:
// Created:     07/25/2001
// Copyright:   (c) Bogdan Georgescu
// Version:     v0.1
/////////////////////////////////////////////////////////////////////////////

#ifndef _BG_IMAGEPROCESSING_H
#define _BG_IMAGEPROCESSING_H

#include <assert.h>
#include "BgImage.h"
#include "BgFilterFactory.h"
#include "BgPoints2D.h"
//#include "BgMatrix.h"

const double g_Xn			= 0.95050;
const double g_Yn			= 1.00000;
const double g_Zn			= 1.08880;
const double g_Un_prime	= 0.19780;
const double g_Vn_prime	= 0.46830;
const double g_Lt			= 0.00856;

	//RGB to LUV conversion
const double g_XYZ[3][3] = {	{  0.4125,  0.3576,  0.1804 },
							{  0.2125,  0.7154,  0.0721 },
							{  0.0193,  0.1192,  0.9502 }	};

	//LUV to RGB conversion
const double g_RGB[3][3] = {	{  3.2405, -1.5371, -0.4985 },
							{ -0.9693,  1.8760,  0.0416 },
							{  0.0556, -0.2040,  1.0573 }	};

const double g_RGB2GRAY[3] = {0.299, 0.587, 0.114};

#define BG_IPR_GAUSS_TAIL 0.1

class BgImageProcessing
{
public:
   BgImageProcessing();
   ~BgImageProcessing();


   int ExtractBoundaries(BgImage& imin, BgImage& imout);

   // image ordered columnwise! for these functions
   int ImFilter(double* im_in, double* im_out, int wx, int wy, double* filt_x, double* filt_y, int WL, int color_im);
   int GradientFilter(double* cim, int wx, int wy, double* grx, double* gry, int color_im, int wsz);
   int ImWarp(double* im, int wx, int wy, double* A, double* cent, double* imw, int color_images);

   // compute covariance matrices by 2 methods
   // method = 0; derivative-based
   //          1; residual-based

   /*
   int PointCovariances(double* im, int wx, int wy, int color_im, BgPoints2D& p2d, BgMatrix* p2dcov, int method, int wsz);
   */

   // LUV ranges from RGB 0 - 255
   // L 0 - 100
   // U -83.080850880619 -> 175.23992246038
   // V -134.08156497712 -> 107.46582320085

   int RGB2LUV_Normalized(double *im_in, double *im_out, int wx, int wy);
   int LUV2RGB(double *im_in, double *im_out, int wx, int wy);
   int LUV2RGB_Normalized(double *im_in, double *im_out, int wx, int wy);
   int RGB2LUV(double *im_in, double *im_out, int wx, int wy);

   int RGB2GRAY(double *im_in, double *im_out, int wx, int wy);
};

#endif