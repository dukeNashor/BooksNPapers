/////////////////////////////////////////////////////////////////////////////
// Name:        BGDefaults.h
// Purpose:     Defines some program constants
// Author:      Bogdan Georgescu
// Modified by:
// Created:     06/22/2000
// Copyright:   (c) Bogdan Georgescu
// Version:     v0.1
/////////////////////////////////////////////////////////////////////////////

#ifndef _BG_DEFAULTS_H
#define _BG_DEFAULTS_H


#define PI 3.1415926535

extern double bgSign(double);
extern int bgSolveCubic(double, double, double, double, double&, double&, double&);
extern inline int bgRound(double);
extern inline int bgMax(int, int);
extern inline int bgMin(int, int);
extern inline int bgMin(double*, int);
extern inline int bgIMin(double ,double , double );
extern inline double bgMin3(double , double , double );
extern inline double bgMax(double, double);
extern inline double bgMin(double, double);
extern inline int bgRoundSign(double);
extern inline double bgEuclidianDistance2D(double*, double*);
extern inline double bgEuclidianDistance2D2(double*, double*);
extern double bgMedian(double*, int, double);
extern inline double bgMedianToSigmaGaussian(double);
extern void bgSort(double*, int);
extern void bgISort(double*, int, int*);
extern double factorial(double);

extern void bgLog(const char*, ...);
extern void bgLogFile(const char*, ...);
extern int write_pgm_image(const char *outfilename, unsigned char *image, int rows,
    int cols, char *comment, int maxval);
extern int write_ppm_image(char *outfilename, unsigned char *image_red,
    unsigned char *image_grn, unsigned char *image_blu, int rows,
    int cols, char *comment, int maxval);
extern int write_ppm_image2(char *outfilename, unsigned char *image_all,
    int rows, int cols, char *comment, int maxval);
extern int read_pgm_image(char *infilename, unsigned char *image, int *rows,
    int *cols);
extern void timer_start();
extern void timer_stop();
extern void timer_elapsed(int prnt=0);

#endif