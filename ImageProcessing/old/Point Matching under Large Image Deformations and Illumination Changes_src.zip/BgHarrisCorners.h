/////////////////////////////////////////////////////////////////////////////
// Name:        BgHarrisCorners.h
// Purpose:     BgHarrisCorners class
// Author:      Bogdan Georgescu
// Modified by:
// Created:     06/22/2000
// Copyright:   (c) Bogdan Georgescu
// Version:     v0.1
/////////////////////////////////////////////////////////////////////////////

#ifndef _BG_HARRISCORNERS_H
#define _BG_HARRISCORNERS_H

#ifndef MAX_FILTS
#define MAX_FILTS 11
#endif

#define CORNER_TRESH 1000
#define HAR_SIGMA 2
#define HAR_SIGMA2 HAR_SIGMA*HAR_SIGMA
#define HAR_TRESH_PERC 0.1
#define HAR_SDKER_SZ 4
#define HAR_VECKER_SZ 4


class BgHarrisCorners
{
public:
   int kSize_;
   int vecSize_;
   int wSize_;
   int elimSize_;
   double cTresh_;
   double cPerc_;
   int x_, y_;

   int WW_;
   int WL_;
   double smofil_[MAX_FILTS];
   double diffil_[MAX_FILTS];
   double *gfilter_;


   BgHarrisCorners(int, int, double cPerc = HAR_TRESH_PERC);
   ~BgHarrisCorners();

   void DoHarrisCorners(BgImage*, int*, int*, int*);
   void GaussDiffFilter(BgImage*, float*, float*);
   void CreateFilters(void);
   void ComputeLambda2(float*, float*, float*);
   void ComputeCorners(float*, float*);
   void ComputeSubpixelCorners(float* lambda2, float* cornx, float* corny, int* nCorn);
   void DoHarrisCorners(BgImage* cim, float* cornx, float* corny, int* nCorn);


};

#endif