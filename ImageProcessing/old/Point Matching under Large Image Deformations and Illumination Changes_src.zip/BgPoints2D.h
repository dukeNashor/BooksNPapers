/////////////////////////////////////////////////////////////////////////////
// Name:        BgPoints2D.h
// Purpose:     BgPoints2D class
// Author:      Bogdan Georgescu
// Modified by:
// Created:     06/22/2000
// Copyright:   (c) Bogdan Georgescu
// Version:     v0.1
/////////////////////////////////////////////////////////////////////////////

#ifndef _BG_POINTS2D_H
#define _BG_POINTS2D_H

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include "BgDefaults.h"

class BgPoints2D
{
public:
   double* x_;
   double* y_;
   int n_;

   BgPoints2D();
   ~BgPoints2D();
   void CleanData();
   void SetPoints(int*, int* ,int);
   void SetPoints(double*, double*, int);
   void SetPoints(float*, float*, int);
   void SetPoints(double*, int);
   void GetPoints(double*);
   void SetHomogPoints(double*, int);
   void InverseYValues(double);
   void InverseXValues(double);
   void Resize(int n);
   //expensive
   void AddPoints(double* x, double* y, int n);
   void AddPoints(BgPoints2D& p2d);

   void Read(const char*);
   void Write(const char*, int bin_wr=0);
   void Read(FILE*);
   void Write(FILE*, int bin_wr=0);
};

#endif