/////////////////////////////////////////////////////////////////////////////
// Name:        BgFilterFactory.cpp
// Purpose:     BgFilterFactory class functions
// Author:      Bogdan Georgescu
// Modified by:
// Created:     11/26/2002
// Copyright:   (c) Bogdan Georgescu
// Version:     v0.1
/////////////////////////////////////////////////////////////////////////////

#include <math.h>
#include "BgFilterFactory.h"

BgFilterFactory::BgFilterFactory()
{
}

BgFilterFactory::~BgFilterFactory()
{
}

double BgFilterFactory::factorial(double num)
{
   int i;
   double fnum = 1;
   for (i=2; i<=num; i++)
      fnum *= i;
   return fnum;
}

void BgFilterFactory::binomial_filters(double* smofil, double* diffil, int WL)
{
   int i;
   double w;
   for (i=-WL; i<=WL; i++)
   {
      w = pow(2,(-2*WL))*factorial(2*WL)/(factorial(WL-i)*factorial(WL+i));
      smofil[i+WL] = w;
      diffil[i+WL] = (2*i*w)/WL;
   }
}

void BgFilterFactory::binomial_filters(double* smofil, int WL)
{
   int i;
   double w;
   for (i=-WL; i<=WL; i++)
   {
      w = pow(2,(-2*WL))*factorial(2*WL)/(factorial(WL-i)*factorial(WL+i));
      smofil[i+WL] = w;
   }
}

void BgFilterFactory::gauss_filters(double* smofil, int WL)
{
   int WL2 = 2*WL+1;
   double sigma2 = -(WL2*WL2)/log(BG_CDOF_GAUSS_TAIL);
   double sumv;
   int i;
   sumv = 0;
   for (i=-WL; i<=WL; i++)
      sumv += smofil[i+WL] = exp(- (i*i)/sigma2);
   for (i=0; i<WL2; i++)
      smofil[i] /= sumv;
}