/////////////////////////////////////////////////////////////////////////////
// Name:        BgFilterFactory.h
// Purpose:     BgFilterFactory class
// Author:      Bogdan Georgescu
// Modified by:
// Created:     11/27/2002
// Copyright:   (c) Bogdan Georgescu
// Version:     v0.1
/////////////////////////////////////////////////////////////////////////////

#ifndef _BG_FILTERFACTORY_H
#define _BG_FILTERFACTORY_H

#define BG_CDOF_GAUSS_TAIL 0.01

class BgFilterFactory
{
public:
   BgFilterFactory();
   ~BgFilterFactory();

   double factorial(double num);
   void binomial_filters(double* smofil, double* diffil, int WL);
   void binomial_filters(double* smofil, int WL);
   void gauss_filters(double* smofil, int WL);
};

#endif
