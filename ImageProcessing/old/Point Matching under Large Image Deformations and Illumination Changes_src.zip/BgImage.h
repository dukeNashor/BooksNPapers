/////////////////////////////////////////////////////////////////////////////
// Name:        BgImage.h
// Purpose:     BgImage class
// Author:      Bogdan Georgescu
// Modified by:
// Created:     06/22/2000
// Copyright:   (c) Bogdan Georgescu
// Version:     v0.1
/////////////////////////////////////////////////////////////////////////////

#ifndef _BG_IMAGE_H
#define _BG_IMAGE_H

#include <assert.h>
#include "BgDefaults.h"

#define RED_WEIGHT 0.299
#define GREEN_WEIGHT 0.587
#define BLUE_WEIGHT 0.114

class BgImage
{
public:
   int x_;
   int y_;
   unsigned char* im_;
   bool hasIm_;
   bool colorIm_; // false - bw image
                  // true  - color RGB image

   BgImage();
   BgImage(int, int, bool colorIm = false);
   ~BgImage();

   void SetImage(unsigned char*, int, int, bool colorIm = false);
   void SetImageFromRGB(unsigned char*, int, int, bool colorIm = false);
   void SetSameImageFromRGB(unsigned char*);
   void SetImage(short*, int, int, bool colorIm = false);
   void GetImage(unsigned char*);
   void GetImageBW(unsigned char*);
   void GetImageColor(unsigned char*);
   void GetImageR(unsigned char*);
   void GetImageG(unsigned char*);
   void GetImageB(unsigned char*);
   bool ValidCoord(int, int);
   int ValidReturnBW(int in_x, int in_y, int& cval);
   int ValidReturnCol(int in_x, int in_y, int& rval, int& gval, int& bval);
   int ReturnCol(int in_x, int in_y, int& rval, int& gval, int& bval);
   inline void FReturnCol(int inl_x, int inl_y, int& inl_rval, int& inl_gval, int& inl_bval);
   inline void DReturnCol(int inl_x, int inl_y, double& inl_rval, double& inl_gval, double& inl_bval);

   int SaveImage(char* fname);

   unsigned char cR(int in_x, int in_y);
   unsigned char cG(int in_x, int in_y);
   unsigned char cB(int in_x, int in_y);

   inline int GetWidth() {return x_;};
   inline int GetHeight() {return y_;};


   const BgImage& operator=(const BgImage& im);
   bool IsAllocated(void) const;

   void CleanData();
   inline unsigned char operator()(int, int) const;
   inline unsigned char& operator()(int, int);
   unsigned char PixelValue(int, int);

   void Resize(int width, int height, bool color);

private:
   void PrivateCopyToThis(const BgImage& im);
   void PrivateResize(int width, int height, bool color);


};
extern inline unsigned char gBgImPt(BgImage*, int, int);

inline void BgImage::FReturnCol(int inl_x, int inl_y, int& inl_rval, int& inl_gval, int& inl_bval)
{
   inl_rval = im_[inl_x*3+0+inl_y*(x_*3)];
   inl_gval = im_[inl_x*3+1+inl_y*(x_*3)];
   inl_bval = im_[inl_x*3+2+inl_y*(x_*3)];
}

inline void BgImage::DReturnCol(int inl_x, int inl_y, double& inl_rval, double& inl_gval, double& inl_bval)
{
   inl_rval = im_[inl_x*3+0+inl_y*(x_*3)];
   inl_gval = im_[inl_x*3+1+inl_y*(x_*3)];
   inl_bval = im_[inl_x*3+2+inl_y*(x_*3)];
}


class BgMetaImage
{
public:
   int wx_;     // width
   int wy_;     // height
   int npl_;    // number of color planes
   double* im_; // data organized by color_planes x columns x rows
   bool hasIm_;
   int type_;   // the meaning of color planes (can be normalized)
                // 0 = gray; npl_ = 1
                // 1 = RGB;  npl_ = 3
                // 2 = LUV;  npl_ = 3
                // 10 = Other;

   BgMetaImage();
   BgMetaImage(int wx, int wy, int npl, int type=10);
   BgMetaImage(BgImage& bgim);
   ~BgMetaImage();

   void SetMetaImage(unsigned char* im, int wx, int wy, int npl);
   void SetMetaImage(double* im, int wx, int wy, int npl);

   inline bool ValidCoord(int in_x, int in_y, int in_pl);

   inline int GetWidth() {return wx_;};
   inline int GetHeight() {return wy_;};
   inline int GetNCPlanes() {return npl_;};

   const BgMetaImage& operator=(const BgMetaImage& mim);
   bool IsAllocated(void) const;

   void CleanData();
   inline double operator()(int in_x, int in_y, int in_pl) const;
   inline double& operator()(int in_x, int in_y, int in_pl);

   void Resize(int wx, int wy, int npl);

private:
   void PrivateCopyToThis(const BgMetaImage& mim);
   void PrivateResize(int wx, int wy, int npl);


};

#endif