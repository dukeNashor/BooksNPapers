Color Distribution/Optical Flow Point Matcher v0.1 README
-------------------------------------------------------------------

Overview:
=========

The CDOF system is a low-level vision tool that performs point matching between two images. It is packaged under a platform independent graphical user interface.

In order to compile the graphical user interface version, wxWindows must be downloaded and installed. It may be obtained from the wxWindows web site at http://www.wxWindows.org.

Quick usage
===========

- select M toolbar button to open a matcher window
- open left and right image
- select with a mouse a point in the left image
- run matcher to detect the selected point in the right image

right click over the points tree root labeled "left points" opens a local menu; by checking "add points" the new selected point will be added to the current set of left points.


References
==========

B. Georgescu and P. Meer, Point matching under large deformations and illumination changes,  to appear in IEEE Trans. Pattern Anal. Machine Intell., 2004.


Contact Information
===================

	georgesc@caip.rutgers.edu	(Bogdan Georgescu)

	www.caip.rutgers.edu/riul/

========================