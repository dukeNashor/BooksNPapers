/////////////////////////////////////////////////////////////////////////////
// Name:        BgImageProcessing.cpp
// Purpose:     BgImageProcessing class functions
// Author:      Bogdan Georgescu
// Modified by:
// Created:     07/25/2001
// Copyright:   (c) Bogdan Georgescu
// Version:     v0.1
/////////////////////////////////////////////////////////////////////////////

#include <math.h>
#include "BgImage.h"
#include "BgImageProcessing.h"

BgImageProcessing::BgImageProcessing()
{
}

BgImageProcessing::~BgImageProcessing()
{
}

int BgImageProcessing::ExtractBoundaries(BgImage& imin, BgImage& imout)
{
   if (imin.colorIm_ == false)
      return 0;

   int dimx, dimy;
   dimx = imin.GetWidth();
   dimy = imin.GetHeight();

   imout.Resize(dimx, dimy, 0);
   unsigned char* tmpimout;
   tmpimout = imout.im_;
   int i;
   for (i=0; i<(dimx*dimy); i++)
      tmpimout[i] = 0;

   unsigned char recCR, recCG, recCB;
   unsigned char* tmpimin;
   tmpimin = imin.im_;
   int x, y;

   int* crtX;
   int* crtY;
   crtX = new int[dimx*dimy+1];
   crtY = new int[dimx*dimy+1];



   x = 0;
   y = 0;
   recCR = tmpimin[(x)*3 + 0 + (y)*(dimx*3)];
   recCG = tmpimin[(x)*3 + 1 + (y)*(dimx*3)];
   recCB = tmpimin[(x)*3 + 2 + (y)*(dimx*3)];

   crtX[1] = x;
   crtY[1] = y;
   int crtPt = 1;
   while (crtPt > 0)
   {
      x = crtX[crtPt];
      y = crtY[crtPt];
      crtPt--;
      tmpimout[x + y*dimx] = 255;

      if (((x+1)<dimx) && (tmpimout[(x+1) + (y)*dimx] == 0) && 
            (tmpimin[(x+1)*3 + 0 + (y)*(dimx*3)] == recCR) &&
            (tmpimin[(x+1)*3 + 1 + (y)*(dimx*3)] == recCG) && 
            (tmpimin[(x+1)*3 + 2 + (y)*(dimy*3)] == recCB))
      {
         crtPt++;
         crtX[crtPt] = x+1;
         crtY[crtPt] = y;
      }

      if (((x-1)>=0) && (tmpimout[(x-1) + (y)*dimx] == 0) && 
            (tmpimin[(x-1)*3 + 0 + (y)*(dimx*3)] == recCR) &&
            (tmpimin[(x-1)*3 + 1 + (y)*(dimx*3)] == recCG) && 
            (tmpimin[(x-1)*3 + 2 + (y)*(dimy*3)] == recCB))
      {
         crtPt++;
         crtX[crtPt] = x-1;
         crtY[crtPt] = y;
      }

      if (((y+1)<dimy) && (tmpimout[(x) + (y+1)*dimx] == 0) && 
            (tmpimin[(x)*3 + 0 + (y+1)*(dimx*3)] == recCR) &&
            (tmpimin[(x)*3 + 1 + (y+1)*(dimx*3)] == recCG) && 
            (tmpimin[(x)*3 + 2 + (y+1)*(dimy*3)] == recCB))
      {
         crtPt++;
         crtX[crtPt] = x;
         crtY[crtPt] = y+1;
      }

      if (((y-1)>=0) && (tmpimout[(x) + (y-1)*dimx] == 0) && 
            (tmpimin[(x)*3 + 0 + (y-1)*(dimx*3)] == recCR) &&
            (tmpimin[(x)*3 + 1 + (y-1)*(dimx*3)] == recCG) && 
            (tmpimin[(x)*3 + 2 + (y-1)*(dimy*3)] == recCB))
      {
         crtPt++;
         crtX[crtPt] = x;
         crtY[crtPt] = y-1;
      }
   }
   

   x = 0;
   y = dimy-1;
   if (tmpimout[x + y*dimx] == 0)
   {
      recCR = tmpimin[(x)*3 + 0 + (y)*(dimx*3)];
      recCG = tmpimin[(x)*3 + 1 + (y)*(dimx*3)];
      recCB = tmpimin[(x)*3 + 2 + (y)*(dimx*3)];
      
      crtX[1] = x;
      crtY[1] = y;
      int crtPt = 1;
      while (crtPt > 0)
      {
         x = crtX[crtPt];
         y = crtY[crtPt];
         crtPt--;
         tmpimout[x + y*dimx] = 1;
         
         if (((x+1)<dimx) && (tmpimout[(x+1) + (y)*dimx] == 0) && 
            (tmpimin[(x+1)*3 + 0 + (y)*(dimx*3)] == recCR) &&
            (tmpimin[(x+1)*3 + 1 + (y)*(dimx*3)] == recCG) && 
            (tmpimin[(x+1)*3 + 2 + (y)*(dimy*3)] == recCB))
         {
            crtPt++;
            crtX[crtPt] = x+1;
            crtY[crtPt] = y;
         }
         
         if (((x-1)>=0) && (tmpimout[(x-1) + (y)*dimx] == 0) && 
            (tmpimin[(x-1)*3 + 0 + (y)*(dimx*3)] == recCR) &&
            (tmpimin[(x-1)*3 + 1 + (y)*(dimx*3)] == recCG) && 
            (tmpimin[(x-1)*3 + 2 + (y)*(dimy*3)] == recCB))
         {
            crtPt++;
            crtX[crtPt] = x-1;
            crtY[crtPt] = y;
         }
         
         if (((y+1)<dimy) && (tmpimout[(x) + (y+1)*dimx] == 0) && 
            (tmpimin[(x)*3 + 0 + (y+1)*(dimx*3)] == recCR) &&
            (tmpimin[(x)*3 + 1 + (y+1)*(dimx*3)] == recCG) && 
            (tmpimin[(x)*3 + 2 + (y+1)*(dimy*3)] == recCB))
         {
            crtPt++;
            crtX[crtPt] = x;
            crtY[crtPt] = y+1;
         }
         
         if (((y-1)>=0) && (tmpimout[(x) + (y-1)*dimx] == 0) && 
            (tmpimin[(x)*3 + 0 + (y-1)*(dimx*3)] == recCR) &&
            (tmpimin[(x)*3 + 1 + (y-1)*(dimx*3)] == recCG) && 
            (tmpimin[(x)*3 + 2 + (y-1)*(dimy*3)] == recCB))
         {
            crtPt++;
            crtX[crtPt] = x;
            crtY[crtPt] = y-1;
         }
      }
   }

   x = dimx-1;
   y = dimy-1;
   if (tmpimout[x + y*dimx] == 0)
   {
      recCR = tmpimin[(x)*3 + 0 + (y)*(dimx*3)];
      recCG = tmpimin[(x)*3 + 1 + (y)*(dimx*3)];
      recCB = tmpimin[(x)*3 + 2 + (y)*(dimx*3)];
      
      crtX[1] = x;
      crtY[1] = y;
      int crtPt = 1;
      while (crtPt > 0)
      {
         x = crtX[crtPt];
         y = crtY[crtPt];
         crtPt--;
         tmpimout[x + y*dimx] = 1;
         
         if (((x+1)<dimx) && (tmpimout[(x+1) + (y)*dimx] == 0) && 
            (tmpimin[(x+1)*3 + 0 + (y)*(dimx*3)] == recCR) &&
            (tmpimin[(x+1)*3 + 1 + (y)*(dimx*3)] == recCG) && 
            (tmpimin[(x+1)*3 + 2 + (y)*(dimy*3)] == recCB))
         {
            crtPt++;
            crtX[crtPt] = x+1;
            crtY[crtPt] = y;
         }
         
         if (((x-1)>=0) && (tmpimout[(x-1) + (y)*dimx] == 0) && 
            (tmpimin[(x-1)*3 + 0 + (y)*(dimx*3)] == recCR) &&
            (tmpimin[(x-1)*3 + 1 + (y)*(dimx*3)] == recCG) && 
            (tmpimin[(x-1)*3 + 2 + (y)*(dimy*3)] == recCB))
         {
            crtPt++;
            crtX[crtPt] = x-1;
            crtY[crtPt] = y;
         }
         
         if (((y+1)<dimy) && (tmpimout[(x) + (y+1)*dimx] == 0) && 
            (tmpimin[(x)*3 + 0 + (y+1)*(dimx*3)] == recCR) &&
            (tmpimin[(x)*3 + 1 + (y+1)*(dimx*3)] == recCG) && 
            (tmpimin[(x)*3 + 2 + (y+1)*(dimy*3)] == recCB))
         {
            crtPt++;
            crtX[crtPt] = x;
            crtY[crtPt] = y+1;
         }
         
         if (((y-1)>=0) && (tmpimout[(x) + (y-1)*dimx] == 0) && 
            (tmpimin[(x)*3 + 0 + (y-1)*(dimx*3)] == recCR) &&
            (tmpimin[(x)*3 + 1 + (y-1)*(dimx*3)] == recCG) && 
            (tmpimin[(x)*3 + 2 + (y-1)*(dimy*3)] == recCB))
         {
            crtPt++;
            crtX[crtPt] = x;
            crtY[crtPt] = y-1;
         }
      }
   }

   x = dimx-1;
   y = 0;
   if (tmpimout[x + y*dimx] == 0)
   {
      recCR = tmpimin[(x)*3 + 0 + (y)*(dimx*3)];
      recCG = tmpimin[(x)*3 + 1 + (y)*(dimx*3)];
      recCB = tmpimin[(x)*3 + 2 + (y)*(dimx*3)];
      
      crtX[1] = x;
      crtY[1] = y;
      int crtPt = 1;
      while (crtPt > 0)
      {
         x = crtX[crtPt];
         y = crtY[crtPt];
         crtPt--;
         tmpimout[x + y*dimx] = 1;
         
         if (((x+1)<dimx) && (tmpimout[(x+1) + (y)*dimx] == 0) && 
            (tmpimin[(x+1)*3 + 0 + (y)*(dimx*3)] == recCR) &&
            (tmpimin[(x+1)*3 + 1 + (y)*(dimx*3)] == recCG) && 
            (tmpimin[(x+1)*3 + 2 + (y)*(dimy*3)] == recCB))
         {
            crtPt++;
            crtX[crtPt] = x+1;
            crtY[crtPt] = y;
         }
         
         if (((x-1)>=0) && (tmpimout[(x-1) + (y)*dimx] == 0) && 
            (tmpimin[(x-1)*3 + 0 + (y)*(dimx*3)] == recCR) &&
            (tmpimin[(x-1)*3 + 1 + (y)*(dimx*3)] == recCG) && 
            (tmpimin[(x-1)*3 + 2 + (y)*(dimy*3)] == recCB))
         {
            crtPt++;
            crtX[crtPt] = x-1;
            crtY[crtPt] = y;
         }
         
         if (((y+1)<dimy) && (tmpimout[(x) + (y+1)*dimx] == 0) && 
            (tmpimin[(x)*3 + 0 + (y+1)*(dimx*3)] == recCR) &&
            (tmpimin[(x)*3 + 1 + (y+1)*(dimx*3)] == recCG) && 
            (tmpimin[(x)*3 + 2 + (y+1)*(dimy*3)] == recCB))
         {
            crtPt++;
            crtX[crtPt] = x;
            crtY[crtPt] = y+1;
         }
         
         if (((y-1)>=0) && (tmpimout[(x) + (y-1)*dimx] == 0) && 
            (tmpimin[(x)*3 + 0 + (y-1)*(dimx*3)] == recCR) &&
            (tmpimin[(x)*3 + 1 + (y-1)*(dimx*3)] == recCG) && 
            (tmpimin[(x)*3 + 2 + (y-1)*(dimy*3)] == recCB))
         {
            crtPt++;
            crtX[crtPt] = x;
            crtY[crtPt] = y-1;
         }
      }
   }

   delete [] crtY;
   delete [] crtX;
   return 1;
}

// image ordered columnwise!
int BgImageProcessing::ImFilter(double* im_in, double* im_out, int wx, int wy, double* filt_x, double* filt_y, int WL, int color_im)
{
   double* tim;
   double sum = 0;
   double sum1 = 0;
   int i, j, k;
   double sumR, sumG, sumB;

   int WW = 2*WL+1;
   
   if (color_im == 0)
   {
      tim = new double[wx*wy];
      for (i=0; i<wx*wy; i++)
         tim[i] = 0;
   } else 
   {
      tim = new double[3*wx*wy];
      for (i=0; i<3*wx*wy; i++)
         tim[i] = 0;
   }
   
   if (color_im == 0)
   {
      //filter on y
      for (i=0; i<wx; i++)
      {
         // upper border
         for (j=0; j<WL; j++)
         {
            sum = 0;
            for (k=-WL; k<-j; k++)
               sum += im_in[0 + i*wy] * filt_y[k+WL];
            for (k=-j; k<=WL; k++)
               sum += im_in[(j+k) + i*wy] * filt_y[k+WL];
            tim[j+i*wy] = sum;
         }
         // main
         for (; j<(wy-WL); j++)
         {
            sum = 0;
            for (k=-WL; k<=WL; k++)
               sum += im_in[(j+k) + i*wy] * filt_y[k+WL];
            tim[j+i*wy] = sum;
         }
         // lower border
         for (; j<wy; j++)
         {
            sum = 0; 
            for (k=-WL; k<(wy-j); k++)
               sum += im_in[(j+k) + i*wy] * filt_y[k+WL];
            for (; k<=WL; k++)
               sum += im_in[wy-1 + i*wy] * filt_y[k+WL];
            tim[j+i*wy] = sum;
         }
      }
      
      //filter on x
      for (j=0; j<wy; j++)
      {
         // left border
         for (i=0; i<WL; i++)
         {
            sum = 0;
            for (k=-WL; k<-i; k++)
               sum += tim[j + 0*wy] * filt_x[k+WL];
            for (k=-i; k<=WL; k++)
               sum += tim[j + (i+k)*wy] * filt_x[k+WL];
            im_out[j+i*wy] = sum;
         }
         // main
         for (; i<(wx-WL); i++)
         {
            sum = 0;
            for (k=-WL; k<=WL; k++)
               sum += tim[j + (i+k)*wy] * filt_x[k+WL];
            im_out[j+i*wy] = sum;
         }
         // right border
         for (; i<wx; i++)
         {
            sum = 0; 
            for (k=-WL; k<(wx-i); k++)
               sum += tim[j + (i+k)*wy] * filt_x[k+WL];
            for (; k<=WL; k++)
               sum += im_in[j + (wx-1)*wy] * filt_x[k+WL];
            im_out[j+i*wy] = sum;
         }
      }
   } else 
   {
      //filter on y
      for (i=0; i<wx; i++)
      {
         // upper border
         for (j=0; j<WL; j++)
         {
            sumR = 0;
            sumG = 0;
            sumB = 0;
            for (k=-WL; k<-j; k++)
            {
               sumR += im_in[3*(0 + i*wy)+0] * filt_y[k+WL];
               sumG += im_in[3*(0 + i*wy)+1] * filt_y[k+WL];
               sumB += im_in[3*(0 + i*wy)+2] * filt_y[k+WL];
            }
            for (k=-j; k<=WL; k++)
            {
               sumR += im_in[3*((j+k) + i*wy)+0] * filt_y[k+WL];
               sumG += im_in[3*((j+k) + i*wy)+1] * filt_y[k+WL];
               sumB += im_in[3*((j+k) + i*wy)+2] * filt_y[k+WL];
            }
            tim[3*(j+i*wy)+0] = sumR;
            tim[3*(j+i*wy)+1] = sumG;
            tim[3*(j+i*wy)+2] = sumB;
         }
         // main
         for (; j<(wy-WL); j++)
         {
            sumR = 0;
            sumG = 0;
            sumB = 0;
            for (k=-WL; k<=WL; k++)
            {
               sumR += im_in[3*((j+k) + i*wy)+0] * filt_y[k+WL];
               sumG += im_in[3*((j+k) + i*wy)+1] * filt_y[k+WL];
               sumB += im_in[3*((j+k) + i*wy)+2] * filt_y[k+WL];
            }
            tim[3*(j+i*wy)+0] = sumR;
            tim[3*(j+i*wy)+1] = sumG;
            tim[3*(j+i*wy)+2] = sumB;
         }
         // lower border
         for (; j<wy; j++)
         {
            sumR = 0;
            sumG = 0;
            sumB = 0;
            for (k=-WL; k<(wy-j); k++)
            {
               sumR += im_in[3*((j+k) + i*wy)+0] * filt_y[k+WL];
               sumG += im_in[3*((j+k) + i*wy)+1] * filt_y[k+WL];
               sumB += im_in[3*((j+k) + i*wy)+2] * filt_y[k+WL];
            }
            for (; k<=WL; k++)
            {
               sumR += im_in[3*(wy-1 + i*wy)+0] * filt_y[k+WL];
               sumG += im_in[3*(wy-1 + i*wy)+1] * filt_y[k+WL];
               sumB += im_in[3*(wy-1 + i*wy)+2] * filt_y[k+WL];
            }
            tim[3*(j+i*wy)+0] = sumR;
            tim[3*(j+i*wy)+1] = sumG;
            tim[3*(j+i*wy)+2] = sumB;
         }
      }
      
      //filter on x
      for (j=0; j<wy; j++)
      {
         // left border
         for (i=0; i<WL; i++)
         {
            sumR = 0;
            sumG = 0;
            sumB = 0;
            for (k=-WL; k<-i; k++)
            {
               sumR += tim[3*(j + 0*wy)+0] * filt_x[k+WL];
               sumG += tim[3*(j + 0*wy)+1] * filt_x[k+WL];
               sumB += tim[3*(j + 0*wy)+2] * filt_x[k+WL];
            }
            for (k=-i; k<=WL; k++)
            {
               sumR += tim[3*(j + (i+k)*wy)+0] * filt_x[k+WL];
               sumG += tim[3*(j + (i+k)*wy)+1] * filt_x[k+WL];
               sumB += tim[3*(j + (i+k)*wy)+2] * filt_x[k+WL];
            }
            im_out[3*(j+i*wy)+0] = sumR;
            im_out[3*(j+i*wy)+1] = sumG;
            im_out[3*(j+i*wy)+2] = sumB;
         }
         // main
         for (; i<(wx-WL); i++)
         {
            sumR = 0;
            sumG = 0;
            sumB = 0;
            for (k=-WL; k<=WL; k++)
            {
               sumR += tim[3*(j + (i+k)*wy)+0] * filt_x[k+WL];
               sumG += tim[3*(j + (i+k)*wy)+1] * filt_x[k+WL];
               sumB += tim[3*(j + (i+k)*wy)+2] * filt_x[k+WL];
            }
            im_out[3*(j+i*wy)+0] = sumR;
            im_out[3*(j+i*wy)+1] = sumG;
            im_out[3*(j+i*wy)+2] = sumB;
         }
         // right border
         for (; i<wx; i++)
         {
            sumR = 0;
            sumG = 0;
            sumB = 0;
            for (k=-WL; k<(wx-i); k++)
            {
               sumR += tim[3*(j + (i+k)*wy)+0] * filt_x[k+WL];
               sumG += tim[3*(j + (i+k)*wy)+1] * filt_x[k+WL];
               sumB += tim[3*(j + (i+k)*wy)+2] * filt_x[k+WL];
            }
            for (; k<=WL; k++)
            {
               sumR += im_in[3*(j + (wx-1)*wy)+0] * filt_x[k+WL];
               sumG += im_in[3*(j + (wx-1)*wy)+1] * filt_x[k+WL];
               sumB += im_in[3*(j + (wx-1)*wy)+2] * filt_x[k+WL];
            }
            im_out[3*(j+i*wy)+0] = sumR;
            im_out[3*(j+i*wy)+1] = sumG;
            im_out[3*(j+i*wy)+2] = sumB;

         }
      }
   }

   delete [] tim;
   return 0;
}

int BgImageProcessing::GradientFilter(double* cim, int wx, int wy, double* grx, double* gry, int color_im, int wsz)
{
   BgFilterFactory cff;
   double* sf; //smooth filter
   double* df; //diff filter
   
   double* tim;
   double sum = 0;
   double sum1 = 0;
   double sumR, sumG, sumB;
   int i, j, k;

   int dtg = wsz;
   int dwg = 2*dtg+1;
   //create kernels
   sf = new double[dwg];
   df = new double[dwg];
   cff.binomial_filters(sf, df, dtg);
   
   if (color_im == 0)
   {
      tim = new double[wx*wy];
      for (i=0; i<wx*wy; i++)
      {
         grx[i] = gry[i] = 0;
         tim[i] = 0;
      }
   } else
   {
      tim = new double[3*wx*wy];
      for (i=0; i<3*wx*wy; i++)
      {
         grx[i] = gry[i] = 0;
         tim[i] = 0;
      }
   }
   
   if (color_im == 0)
   {
      //filter image x
      //smooth on y
      for (i=0; i<wx; i++)
      {
         for (j=dtg; j<(wy-dtg); j++)
         {
            sum = 0;
            for (k=-dtg; k<=dtg; k++)
               sum += cim[(j+k)+i*wy]*sf[k+dtg];
            tim[j+i*wy] = sum;
         }
      }
      //diff on x
      for (j=0; j<wy; j++)
      {
         for (i=dtg; i<(wx-dtg); i++)
         {
            sum = 0;
            for (k=-dtg; k<=dtg; k++)
               sum += tim[j+(i+k)*wy]*df[k+dtg];
            grx[j+i*wy] = sum;
         }
      }
      
      //filter image y
      for (i=0; i<wx*wy;i++)
         tim[i] = 0;
      //smooth on x
      for (j=0; j<wy; j++)
      {
         for (i=dtg; i<(wx-dtg); i++)
         {
            sum = 0;
            for (k=-dtg; k<=dtg; k++)
               sum += cim[j+(i+k)*wy]*sf[k+dtg];
            tim[j+i*wy] = sum;
         }
      }
      //diff on y
      for (i=0; i<wx; i++)
      {
         for (j=dtg; j<(wy-dtg); j++)
         {
            sum = 0;
            for (k=-dtg; k<=dtg; k++)
               sum += tim[(j+k)+i*wy]*df[k+dtg];
            gry[j+i*wy] = sum;
         }
      }
   } else
   {
      //filter image x
      //smooth on y
      for (i=0; i<wx; i++)
      {
         for (j=dtg; j<(wy-dtg); j++)
         {
            sumR = sumG = sumB = 0;
            for (k=-dtg; k<=dtg; k++)
            {
               sumR += cim[3*((j+k)+i*wy)+0]*sf[k+dtg];
               sumG += cim[3*((j+k)+i*wy)+1]*sf[k+dtg];
               sumB += cim[3*((j+k)+i*wy)+2]*sf[k+dtg];
            }
            tim[3*(j+i*wy)+0] = sumR;
            tim[3*(j+i*wy)+1] = sumG;
            tim[3*(j+i*wy)+2] = sumB;
         }
      }
      //diff on x
      for (j=0; j<wy; j++)
      {
         for (i=dtg; i<(wx-dtg); i++)
         {
            sumR = sumG = sumB = 0;
            for (k=-dtg; k<=dtg; k++)
            {
               sumR += tim[3*(j+(i+k)*wy)+0]*df[k+dtg];
               sumG += tim[3*(j+(i+k)*wy)+1]*df[k+dtg];
               sumB += tim[3*(j+(i+k)*wy)+2]*df[k+dtg];
            }
            grx[3*(j+i*wy)+0] = sumR;
            grx[3*(j+i*wy)+1] = sumG;
            grx[3*(j+i*wy)+2] = sumB;
         }
      }
      
      //filter image y
      for (i=0; i<3*wx*wy;i++)
         tim[i] = 0;
      //smooth on x
      for (j=0; j<wy; j++)
      {
         for (i=dtg; i<(wx-dtg); i++)
         {
            sumR = sumG = sumB = 0;
            for (k=-dtg; k<=dtg; k++)
            {
               sumR += cim[3*(j+(i+k)*wy)+0]*sf[k+dtg];
               sumG += cim[3*(j+(i+k)*wy)+1]*sf[k+dtg];
               sumB += cim[3*(j+(i+k)*wy)+2]*sf[k+dtg];
            }
            tim[3*(j+i*wy)+0] = sumR;
            tim[3*(j+i*wy)+1] = sumG;
            tim[3*(j+i*wy)+2] = sumB;
         }
      }
      //diff on y
      for (i=0; i<wx; i++)
      {
         for (j=dtg; j<(wy-dtg); j++)
         {
            sumR = sumG = sumB = 0;
            for (k=-dtg; k<=dtg; k++)
            {
               sumR += tim[3*((j+k)+i*wy)+0]*df[k+dtg];
               sumG += tim[3*((j+k)+i*wy)+1]*df[k+dtg];
               sumB += tim[3*((j+k)+i*wy)+2]*df[k+dtg];
            }
            gry[3*(j+i*wy)+0] = sumR;
            gry[3*(j+i*wy)+1] = sumG;
            gry[3*(j+i*wy)+2] = sumB;
         }
      }
   }
   delete [] tim;
   delete [] sf;
   delete [] df;
   return 0;
}


int BgImageProcessing::ImWarp(double* im, int wx, int wy, double* A, double* cent, double* imw, int color_images)
{
   
   int x, y;
   double m_xw, m_yw;
   double mx, my;
   int xi, yi;
   double dx, dy;
   double z11, z12, z21, z22;
   if (color_images == 0)
   {
      for (x=0; x<wx; x++)
      {
         for (y=0; y<wy; y++)
         {
            m_xw = x-cent[0];
            m_yw = y-cent[1];
            mx = A[0]*m_xw+A[2]*m_yw+cent[0];
            my = A[1]*m_xw+A[3]*m_yw+cent[1];
            xi = (int) mx;
            yi = (int) my;
            dx = mx-xi;
            dy = my-yi;
            if ((xi>=0) && (yi>=0) && (yi<(wy-1)) && (xi<(wx-1)))
            {
               z11 = im[yi+xi*wy];
               z21 = im[yi+(xi+1)*wy];
               z12 = im[yi+1+xi*wy];
               z22 = im[yi+1+(xi+1)*wy];
               imw[y+x*wy] = z11+dx*(z21-z11)+dy*(z12-z11)+dx*dy*(z11-z12-z21+z22);
            } else
            {
               imw[y+x*wy] = 0;
            }
         }
      }
   } else
   {
      for (x=0; x<wx; x++)
      {
         for (y=0; y<wy; y++)
         {
            m_xw = x-cent[0];
            m_yw = y-cent[1];
            mx = A[0]*m_xw+A[2]*m_yw+cent[0];
            my = A[1]*m_xw+A[3]*m_yw+cent[1];
            xi = (int) mx;
            yi = (int) my;
            dx = mx-xi;
            dy = my-yi;
            if ((xi>=0) && (yi>=0) && (yi<(wy-1)) && (xi<(wx-1)))
            {
               z11 = im[3*(yi+xi*wy)+0];
               z21 = im[3*(yi+(xi+1)*wy)+0];
               z12 = im[3*(yi+1+xi*wy)+0];
               z22 = im[3*(yi+1+(xi+1)*wy)+0];
               imw[3*(y+x*wy)+0] = z11+dx*(z21-z11)+dy*(z12-z11)+dx*dy*(z11-z12-z21+z22);
               z11 = im[3*(yi+xi*wy)+1];
               z21 = im[3*(yi+(xi+1)*wy)+1];
               z12 = im[3*(yi+1+xi*wy)+1];
               z22 = im[3*(yi+1+(xi+1)*wy)+1];
               imw[3*(y+x*wy)+1] = z11+dx*(z21-z11)+dy*(z12-z11)+dx*dy*(z11-z12-z21+z22);
               z11 = im[3*(yi+xi*wy)+2];
               z21 = im[3*(yi+(xi+1)*wy)+2];
               z12 = im[3*(yi+1+xi*wy)+2];
               z22 = im[3*(yi+1+(xi+1)*wy)+2];
               imw[3*(y+x*wy)+2] = z11+dx*(z21-z11)+dy*(z12-z11)+dx*dy*(z11-z12-z21+z22);
            } else
            {
               imw[3*(y+x*wy)+0] = 0;
               imw[3*(y+x*wy)+1] = 0;
               imw[3*(y+x*wy)+2] = 0;
            }
         }
      }

   }
   return 0;
}

int BgImageProcessing::RGB2LUV_Normalized(double *im_in, double *im_out, int wx, int wy)
{
   double *rgbVal;
   double *luvVal;

   int i;
   
	//declare variables
	double	x, y, z, L0, u_prime, v_prime, constant;


   for (i=0; i<(wx*wy); i++)
   {
      rgbVal = &im_in[3*i];
      luvVal = &im_out[3*i];
      
      //convert RGB to XYZ...
      x		= g_XYZ[0][0]*rgbVal[0] + g_XYZ[0][1]*rgbVal[1] + g_XYZ[0][2]*rgbVal[2];
      y		= g_XYZ[1][0]*rgbVal[0] + g_XYZ[1][1]*rgbVal[1] + g_XYZ[1][2]*rgbVal[2];
      z		= g_XYZ[2][0]*rgbVal[0] + g_XYZ[2][1]*rgbVal[1] + g_XYZ[2][2]*rgbVal[2];
      
      //convert XYZ to LUV...
      
      //compute L*
      L0		= y / (255.0 * g_Yn);
      if(L0 > g_Lt)
         luvVal[0]	= (float)(116.0 * (pow(L0, 1.0/3.0)) - 16.0);
      else
         luvVal[0]	= (float)(903.3 * L0);
      
      //compute u_prime and v_prime
      constant	= x + 15 * y + 3 * z;
      if(constant != 0)
      {
         u_prime	= (4 * x) / constant;
         v_prime = (9 * y) / constant;
      }
      else
      {
         u_prime	= 4.0;
         v_prime	= 9.0/15.0;
      }
      
      //compute u* and v*
      luvVal[1] = (float) (13 * luvVal[0] * (u_prime - g_Un_prime));
      luvVal[2] = (float) (13 * luvVal[0] * (v_prime - g_Vn_prime));
   }

   double minV, deltaV;
   minV = -135;
   deltaV = 176-minV;
   for (i=0; i<(3*wx*wy); i++)
      im_out[i] = (im_out[i]-minV)/deltaV;

	//done.
	return 0;
}

int BgImageProcessing::LUV2RGB(double *im_in, double *im_out, int wx, int wy)
{

	//declare variables...
	int		r, g, b;
	double	x, y, z, u_prime, v_prime;
   double *rgbVal;
   double *luvVal;

   int i;
   for (i=0; i<(wx*wy); i++)
   {
      rgbVal = &im_in[3*i];
      luvVal = &im_out[3*i];
            
      //perform conversion
      if(luvVal[0] < 0.1)
         r = g = b = 0;
      else
      {
         //convert luv to xyz...
         if(luvVal[0] < 8.0)
            y	= g_Yn * luvVal[0] / 903.3;
         else
         {
            y	= (luvVal[0] + 16.0) / 116.0;
            y  *= g_Yn * y * y;
         }
         
         u_prime	= luvVal[1] / (13 * luvVal[0]) + g_Un_prime;
         v_prime	= luvVal[2] / (13 * luvVal[0]) + g_Vn_prime;
         
         x		= 9 * u_prime * y / (4 * v_prime);
         z		= (12 - 3 * u_prime - 20 * v_prime) * y / (4 * v_prime);
         
         //convert xyz to rgb...
         //[r, g, b] = RGB*[x, y, z]*255.0
         r		= bgRoundSign((g_RGB[0][0]*x + g_RGB[0][1]*y + g_RGB[0][2]*z)*255.0);
         g		= bgRoundSign((g_RGB[1][0]*x + g_RGB[1][1]*y + g_RGB[1][2]*z)*255.0);
         b		= bgRoundSign((g_RGB[2][0]*x + g_RGB[2][1]*y + g_RGB[2][2]*z)*255.0);
         
         //check bounds...
         if(r < 0)	r = 0; if(r > 255)	r = 255;
         if(g < 0)	g = 0; if(g > 255)	g = 255;
         if(b < 0)	b = 0; if(b > 255)	b = 255;
         
      }
      
      //assign rgb values to rgb vector rgbVal
      rgbVal[0]	= r;
      rgbVal[1]	= g;
      rgbVal[2]	= b;
   }
	//done.
	return 0;

}

int BgImageProcessing::LUV2RGB_Normalized(double *im_in, double *im_out, int wx, int wy)
{

	//declare variables...
	int		r, g, b;
	double	x, y, z, u_prime, v_prime;
   double *rgbVal;
   double L, u, v;
   double *tluv;

   double minV, deltaV;
   minV = -135;
   deltaV = 176-minV;

   int i;
   for (i=0; i<(wx*wy); i++)
   {
      rgbVal = &im_out[3*i];
      tluv = &im_in[3*i];

      L = tluv[0]*deltaV + minV;
      u = tluv[1]*deltaV + minV;
      v = tluv[2]*deltaV + minV;
            
      //perform conversion
      if(L < 0.1)
         r = g = b = 0;
      else
      {
         //convert luv to xyz...
         if(L < 8.0)
            y	= g_Yn * L / 903.3;
         else
         {
            y	= (L + 16.0) / 116.0;
            y  *= g_Yn * y * y;
         }
         
         u_prime	= u / (13 * L) + g_Un_prime;
         v_prime	= v / (13 * L) + g_Vn_prime;
         
         x		= 9 * u_prime * y / (4 * v_prime);
         z		= (12 - 3 * u_prime - 20 * v_prime) * y / (4 * v_prime);
         
         //convert xyz to rgb...
         //[r, g, b] = RGB*[x, y, z]*255.0
         r		= bgRoundSign((g_RGB[0][0]*x + g_RGB[0][1]*y + g_RGB[0][2]*z)*255.0);
         g		= bgRoundSign((g_RGB[1][0]*x + g_RGB[1][1]*y + g_RGB[1][2]*z)*255.0);
         b		= bgRoundSign((g_RGB[2][0]*x + g_RGB[2][1]*y + g_RGB[2][2]*z)*255.0);
         
         //check bounds...
         if(r < 0)	r = 0; if(r > 255)	r = 255;
         if(g < 0)	g = 0; if(g > 255)	g = 255;
         if(b < 0)	b = 0; if(b > 255)	b = 255;
         
      }
      
      //assign rgb values to rgb vector rgbVal
      rgbVal[0]	= r;
      rgbVal[1]	= g;
      rgbVal[2]	= b;
   }
	//done.
	return 0;
}

int BgImageProcessing::RGB2LUV(double *im_in, double *im_out, int wx, int wy)
{
   double *rgbVal;
   double *luvVal;

   int i;
   

	//declare variables
	double	x, y, z, L0, u_prime, v_prime, constant;


   for (i=0; i<(wx*wy); i++)
   {
      rgbVal = &im_in[3*i];
      luvVal = &im_out[3*i];
      
      //convert RGB to XYZ...
      x		= g_XYZ[0][0]*rgbVal[0] + g_XYZ[0][1]*rgbVal[1] + g_XYZ[0][2]*rgbVal[2];
      y		= g_XYZ[1][0]*rgbVal[0] + g_XYZ[1][1]*rgbVal[1] + g_XYZ[1][2]*rgbVal[2];
      z		= g_XYZ[2][0]*rgbVal[0] + g_XYZ[2][1]*rgbVal[1] + g_XYZ[2][2]*rgbVal[2];
      
      //convert XYZ to LUV...
      
      //compute L*
      L0		= y / (255.0 * g_Yn);
      if(L0 > g_Lt)
         luvVal[0]	= (float)(116.0 * (pow(L0, 1.0/3.0)) - 16.0);
      else
         luvVal[0]	= (float)(903.3 * L0);
      
      //compute u_prime and v_prime
      constant	= x + 15 * y + 3 * z;
      if(constant != 0)
      {
         u_prime	= (4 * x) / constant;
         v_prime = (9 * y) / constant;
      }
      else
      {
         u_prime	= 4.0;
         v_prime	= 9.0/15.0;
      }
      
      //compute u* and v*
      luvVal[1] = (float) (13 * luvVal[0] * (u_prime - g_Un_prime));
      luvVal[2] = (float) (13 * luvVal[0] * (v_prime - g_Vn_prime));
   }

	//done.
	return 0;

}

int BgImageProcessing::RGB2GRAY(double *im_in, double* im_out, int wx, int wy)
{
   int i;
   int iidx;
   for (i=0, iidx=0; i<(wx*wy); i++, iidx+=3)
      im_out[i] = im_in[iidx+0]*g_RGB2GRAY[0] + im_in[iidx+1]*g_RGB2GRAY[1] + im_in[iidx+2]*g_RGB2GRAY[2];
   return 0;
}

/*
int BgImageProcessing::PointCovariances(double* im, int wx, int wy, int color_im, BgPoints2D& p2d, BgMatrix* p2dcov, int method, int wsz)
{
   // p2dcov already allocated

   // precompute kernel
   int dt = wsz;
   int dw = 2*dt+1;
   double *weight;
   weight = new double[dw*dw];
   int x, y, widx;
   double sumw;
   double sigma2 = -(dw*dw)/log(BG_IPR_GAUSS_TAIL);
   widx = 0;
   sumw = 0;
   for (x=-dt; x<=dt; x++)
   {
      for (y=-dt; y<=dt; y++)
      {
         sumw += weight[widx] = exp(-(x*x+y*y)/sigma2);
         widx++;
      }
   }
   for (widx=0; widx<(dw*dw); widx++)
      weight[widx] /= sumw;

   int cp, npoints;
   npoints = p2d.n_;
   BgMatrix covmat(2,2);
   int cpx, cpy, crtx, crty, pidx;

   // method = 0; derivative-based
   if (method == 0)
   {
      // convert 2 grayscale
      double* grayim;
      double *grx, *gry;
      grx = new double[wx*wy];
      gry = new double[wx*wy];

      if (color_im==1)
      {
         grayim = new double[wx*wy];
         //convert
         RGB2GRAY(im, grayim, wx, wy);
      } else
         grayim = im;

      // compute gradient
      GradientFilter(grayim, wx, wy, grx, gry, 0, wsz);

      // compute covariances for each point
      for (cp = 0; cp<npoints; cp++)
      {
         cpx = bgRound(p2d.x_[cp]);
         cpy = bgRound(p2d.y_[cp]);

         covmat.Resize(2,2,0.0);
         widx = 0;
         for (x=-dt; x<=dt; x++)
         {
            for (y=-dt; y<=dt; y++, widx++)
            {
               // find point index in image
               crtx = cpx+x;
               crty = cpy+y;
               if ((crtx>=0) && (crtx<wx) && (crty>=0) && (crty<wy))
               {
                  pidx = crty + crtx*wy;
                  covmat(0,0) += weight[widx]*grx[pidx]*grx[pidx];
                  covmat(1,0) += weight[widx]*grx[pidx]*gry[pidx];
                  covmat(1,1) += weight[widx]*gry[pidx]*gry[pidx];
               }
            }
         }
         covmat(0,1) = covmat(1,0);
         p2dcov[cp] = covmat;
      }

      delete [] grx;
      delete [] gry;
      if (color_im==1)
         delete [] grayim;
   }

   if (method == 1)
   {
      // residual-based

      // build system for each point
      

   }


   delete [] weight;
   return 0;
}
*/
