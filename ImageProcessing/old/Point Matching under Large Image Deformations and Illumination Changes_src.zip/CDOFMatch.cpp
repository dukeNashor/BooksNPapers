/////////////////////////////////////////////////////////////////////////////
// Name:        CDOFMatch.cpp
// Purpose:     Color Distribution/Optical Flow Matcher
// Author:      Bogdan Georgescu
// Modified by:
// Created:     09/01/2003
// Copyright:   (c) Bogdan Georgescu
// Version:     v0.1
/////////////////////////////////////////////////////////////////////////////


// For compilers that support precompilation, includes "wx/wx.h".
#include "wx/wxprec.h"
#include <wx/filesys.h>
#ifdef __BORLANDC__
   #pragma hdrstop
#endif

#ifndef WX_PRECOMP
   #include "wx/wx.h"
   #include "wx/bgimsystem.h"
#endif

#include <wx/toolbar.h>

#if defined(__WXGTK__) || defined(__WXMOTIF__)
   #include "mondrian.xpm"
   #include "bitmaps/bg_wimage.xpm"
   #include "bitmaps/bg_wsegm.xpm"
#endif

#include <math.h>

#include "BgDefaults.h"
#include "BgImagPGM.h"
#include "BgPoints2D.h"
#include "BgImage.h"
#include "BgHarrisCorners.h"
#include "CDOFMatch.h"
#include "BgCdOfTracker.h"
IMPLEMENT_APP(BgApp)

BgMdiFrame *g_frame = (BgMdiFrame *) NULL;
wxList g_children;

static int gs_nFrames = 0;
static bool	on_exit		= false;
#define DEFAULT_LOG_SIZE 100

// ---------------------------------------------------------------------------
// event tables
// ---------------------------------------------------------------------------


// main frame
BEGIN_EVENT_TABLE(BgMdiFrame, wxMDIParentFrame)
//EVT_MENU(BG_LOAD_IMAGE, BgMdiFrame::OnLoadImage)
EVT_MENU(BG_ABOUT, BgMdiFrame::OnAbout)
EVT_MENU(BG_NEW_IMAGE_WINDOW, BgMdiFrame::OnNewImageWindow)
EVT_MENU(BG_NEW_IMMATCH_WINDOW, BgMdiFrame::OnNewImMatchWindow)
EVT_MENU(BG_QUIT, BgMdiFrame::OnQuit)

EVT_CLOSE(BgMdiFrame::OnClose)

EVT_SIZE(BgMdiFrame::OnSize)
END_EVENT_TABLE()

// image window
BEGIN_EVENT_TABLE(BgMdiImChild, wxMDIChildFrame)
EVT_MENU(BG_LOAD_IMAGE, BgMdiImChild::OnLoadImage)
EVT_MENU(BG_CHILD_IMAGE_QUIT, BgMdiImChild::OnQuit)
EVT_MENU(BG_REFRESH, BgMdiImChild::OnRefresh)
EVT_CLOSE(BgMdiImChild::OnClose)
END_EVENT_TABLE()

// match window
BEGIN_EVENT_TABLE(BgMdiImMatchingChild, wxMDIChildFrame)
EVT_MENU(BG_LOAD_IMAGE, BgMdiImMatchingChild::OnLoadImages)
EVT_MENU(BG_IMMATCH_QUIT, BgMdiImMatchingChild::OnQuit)
EVT_MENU(BG_REFRESH, BgMdiImMatchingChild::OnRefresh)
EVT_MENU(BG_IMMATCH_CORNERS, BgMdiImMatchingChild::OnHarrisCorners)
EVT_MENU(BG_IMMATCH_LOADLIMAGE, BgMdiImMatchingChild::OnLoadLeftImage)
EVT_MENU(BG_IMMATCH_LOADRIMAGE, BgMdiImMatchingChild::OnLoadRightImage)

EVT_BUTTON(BG_IMMATCH_LOADLIMAGE, BgMdiImMatchingChild::OnLoadLeftImage)
EVT_BUTTON(BG_IMMATCH_LOADRIMAGE, BgMdiImMatchingChild::OnLoadRightImage)

EVT_MENU(BG_IMMATCH_LOAD_POINTS, BgMdiImMatchingChild::OnLoadCorners)
EVT_MENU(BG_IMMATCH_SAVE_POINTS, BgMdiImMatchingChild::OnSaveCorners)

EVT_MENU(BG_IMMATCH_REMOVEALL, BgMdiImMatchingChild::OnRemoveAllPoints)
EVT_MENU(BG_IMMATCH_ADDPOINTS, BgMdiImMatchingChild::OnAddPointsCheck)

EVT_MENU(BG_IMMATCH_ADDCANVASPOINT, BgMdiImMatchingChild::OnAddCanvasPoint)

EVT_TREE_ITEM_ACTIVATED(BG_IMMATCH_TREE_CLICK, BgMdiImMatchingChild::OnTreeFrameClick)
//EVT_TREE_SEL_CHANGED(BG_IMMATCH_TREE_CLICK, BgMdiImMatchingChild::OnTreeFrameSelect) 
EVT_TREE_ITEM_RIGHT_CLICK(BG_IMMATCH_TREE_CLICK, BgMdiImMatchingChild::OnTreeFrameSelect)

EVT_BUTTON(BG_IMMATCH_RUNALG, BgMdiImMatchingChild::OnRunAlgorithm)
EVT_CHOICE(BG_IMMATCH_ALG_SEL, BgMdiImMatchingChild::OnChoiceAlgorithm)

EVT_CLOSE(BgMdiImMatchingChild::OnClose)

EVT_SIZE(BgMdiImMatchingChild::OnSize)
END_EVENT_TABLE()

BEGIN_EVENT_TABLE(BgImageCanvas, wxScrolledWindow)
EVT_LEFT_DOWN(BgImageCanvas::OnMouseLClick)
END_EVENT_TABLE()

// ===========================================================================
// implementation
// ===========================================================================

// ---------------------------------------------------------------------------
// Log function
// ---------------------------------------------------------------------------

// ----------------------------------------------------------------------------
// wxLogTextCtrl implementation
// ----------------------------------------------------------------------------

bgLogTextCtrl::bgLogTextCtrl(wxTextCtrl *pTextCtrl)
{
    m_pTextCtrl = pTextCtrl;
}

void bgLogTextCtrl::DoLogString(const wxChar *szString, time_t WXUNUSED(t))
{
    wxString msg;
    TimeStamp(&msg);
    msg << szString;

    m_pTextCtrl->AppendText(msg);
}

#define VAR_LOG_BUFFER_SIZE   (4096)

static wxChar varszBuf[VAR_LOG_BUFFER_SIZE];

FILE* glogfile;

void bgLog(const char* szFormat, ...)
{
   va_list argptr;
   va_start(argptr, szFormat);
   wxVsnprintf(varszBuf, WXSIZEOF(varszBuf), szFormat, argptr);
   va_end(argptr);
   ::wxLogMessage(varszBuf);

   bgLogFile(varszBuf);
}

void bgLogVar(const char* first, va_list alist)
{
   wxVsnprintf(varszBuf, WXSIZEOF(varszBuf), first, alist);
   ::wxLogMessage(varszBuf);
}

void bgLogFile(const char* szFormat, ...)
{
   va_list argptr;
   va_start(argptr, szFormat);
   vfprintf(glogfile, szFormat, argptr);
   va_end(argptr);
   fflush(glogfile);
}

// ---------------------------------------------------------------------------
// BgApp
// ---------------------------------------------------------------------------

// Initialise this in OnInit, not statically
bool BgApp::OnInit()
{
   // Create the main frame window
   
   g_frame = new BgMdiFrame((wxFrame *)NULL, -1, "Color Distribution - Optical Flow Matcher",
      wxPoint(10, 10), wxSize(1024, 768),
      wxDEFAULT_FRAME_STYLE | wxHSCROLL | wxVSCROLL);
   
   // Give it an icon
#ifdef __WXMSW__
   g_frame->SetIcon(wxIcon("bg_icn"));
#else
   g_frame->SetIcon(wxIcon( mondrian_xpm ));
#endif
   
   // Make a menubar
   wxMenu *file_menu = new wxMenu;
   
   file_menu->Append(BG_NEW_IMAGE_WINDOW, "New &image window");
   file_menu->Append(BG_NEW_IMMATCH_WINDOW, "New &match window");
   file_menu->Append(BG_QUIT, "&Exit\tAlt-X", "Quit the program");
   
   wxMenu *help_menu = new wxMenu;
   help_menu->Append(BG_ABOUT, "&About\tF1");
   
   wxMenuBar *menu_bar = new wxMenuBar;
   
   menu_bar->Append(file_menu, "&File");
   menu_bar->Append(help_menu, "&Help");
   
   // Associate the menu bar with the frame
   g_frame->SetMenuBar(menu_bar);
   
   g_frame->CreateStatusBar();
   
   g_frame->Show(TRUE);
   
   SetTopWindow(g_frame);

#if wxUSE_LIBPNG
  wxImage::AddHandler( new wxPNGHandler );
#endif

#if wxUSE_LIBJPEG
  wxImage::AddHandler( new wxJPEGHandler );
#endif

#if wxUSE_LIBTIFF
  wxImage::AddHandler( new wxTIFFHandler );
#endif

#if wxUSE_GIF
  wxImage::AddHandler( new wxGIFHandler );
#endif

#if wxUSE_PCX
  wxImage::AddHandler( new wxPCXHandler );
#endif

#if wxUSE_PNM
  wxImage::AddHandler( new wxPNMHandler );
#endif

  wxImage::AddHandler( new bgPGMHandler );
   
   return TRUE;
}

// ---------------------------------------------------------------------------
// BgMdiFrame
// ---------------------------------------------------------------------------

// Define my frame constructor
BgMdiFrame::BgMdiFrame(wxWindow *parent,
                       const wxWindowID id,
                       const wxString& title,
                       const wxPoint& pos,
                       const wxSize& size,
                       const long style)
                       : wxMDIParentFrame(parent, id, title, pos, size, style)
{
    logtext_ = new wxTextCtrl(this, -1, "Log window.\n",
                            wxDefaultPosition, wxDefaultSize, wxTE_MULTILINE | wxSUNKEN_BORDER | wxTE_READONLY);
    logtext_->SetBackgroundColour("wheat");
    bglogctrl_ = new bgLogTextCtrl(logtext_);
    logTargetOld_ = wxLog::SetActiveTarget(bglogctrl_);
    logsize_ = DEFAULT_LOG_SIZE;
   

   CreateToolBar(wxNO_BORDER | wxTB_FLAT | wxTB_HORIZONTAL);
   InitToolBar(GetToolBar());
   
   // Accelerators
   wxAcceleratorEntry entries[4];
   entries[0].Set(wxACCEL_CTRL, (int) 'I', BG_NEW_IMAGE_WINDOW);
   entries[1].Set(wxACCEL_CTRL, (int) 'M', BG_NEW_IMMATCH_WINDOW);
   entries[2].Set(wxACCEL_CTRL, (int) 'X', BG_QUIT);
   entries[3].Set(wxACCEL_CTRL, (int) 'A', BG_ABOUT);
   wxAcceleratorTable accel(4, entries);
   SetAcceleratorTable(accel);


   // bgFileLog
   glogfile = fopen("filelog.txt", "w");
}

void BgMdiFrame::OnClose(wxCloseEvent& event)
{
   if ( event.CanVeto() && (gs_nFrames > 0) )
   {
      wxString msg;
      msg.Printf(_T("%d windows still open, close anyhow?"), gs_nFrames);
      if ( wxMessageBox(msg, "Please confirm",
         wxICON_QUESTION | wxYES_NO) != wxYES )
      {
         event.Veto();
         
         return;
      }
   }
   wxLog::SetActiveTarget(logTargetOld_);
   delete bglogctrl_;
   delete logtext_;

   // bgFileLog
   fclose(glogfile);

   event.Skip();
}

void BgMdiFrame::OnQuit(wxCommandEvent& WXUNUSED(event))
{
   Close();
}

void BgMdiFrame::OnLoadImage(wxCommandEvent& event)
{
   wxMDIChildFrame* actcld;
   if (actcld=GetActiveChild())
   {
      actcld->AddPendingEvent(event);
   }
}

void BgMdiFrame::OnAbout(wxCommandEvent& WXUNUSED(event) )
{
   (void)wxMessageBox("Color Distribution - Optical Flow Matcher v0.1\n"
      "Author: Bogdan Georgescu (c) 2003\n"
      "CAIP, Rutgers University", "About CDOFMatch");
}

void BgMdiFrame::OnNewImageWindow(wxCommandEvent& WXUNUSED(event) )
{
   // Make another frame, containing a canvas
   BgMdiImChild *subframe = new BgMdiImChild(g_frame, "Image Frame",
      wxPoint(-1, -1), wxSize(-1, -1),
      wxDEFAULT_FRAME_STYLE);
   
   wxString title;
   title.Printf(_T("Image Frame %d"), ++gs_nFrames);
   
   subframe->SetTitle(title);
   
   // Give it an icon
#ifdef __WXMSW__
   subframe->SetIcon(wxIcon("chrt_icn"));
#else
   subframe->SetIcon(wxIcon( mondrian_xpm ));
#endif
   
   // Make a menubar
   wxMenu *file_menu = new wxMenu;
   
   file_menu->Append(BG_NEW_IMAGE_WINDOW, "New &image window");
   file_menu->Append(BG_NEW_IMMATCH_WINDOW, "New &match window");
   file_menu->Append(BG_LOAD_IMAGE, "Load image");
   file_menu->Append(BG_CHILD_IMAGE_QUIT, "&Close image window", "Close this window");
   file_menu->Append(BG_QUIT, "&Exit");
   
   wxMenu *option_menu = new wxMenu;
   
   option_menu->Append(BG_REFRESH, "&Refresh picture");

   wxMenu *help_menu = new wxMenu;
   help_menu->Append(BG_ABOUT, "&About");
   
   wxMenuBar *menu_bar = new wxMenuBar;
   
   menu_bar->Append(file_menu, "&File");
   menu_bar->Append(option_menu, "&Options");
   menu_bar->Append(help_menu, "&Help");
   
   // Associate the menu bar with the frame
   subframe->SetMenuBar(menu_bar);
   
   subframe->CreateStatusBar();
   subframe->SetStatusText(title);
   
   int width, height;
   subframe->GetClientSize(&width, &height);
   BgImageCanvas *canvas = new BgImageCanvas(subframe, wxPoint(0, 0), wxSize(width, height));
   canvas->SetCursor(wxCursor(wxCURSOR_PENCIL));
   subframe->canvas = canvas;
   
   // Give it scrollbars
   canvas->SetScrollbars(20, 20, 50, 50);
   
   subframe->Show(TRUE);
}

void BgMdiFrame::OnNewImMatchWindow(wxCommandEvent& WXUNUSED(event) )
{
   
   // Make another frame, containing a image sequence processing window
   BgMdiImMatchingChild *subframe = new BgMdiImMatchingChild(g_frame, "Image Matching Frame",
      wxPoint(-1, -1), wxSize(-1, -1),
      wxDEFAULT_FRAME_STYLE);
   
   wxString title;
   title.Printf(_T("Image Matching Frame %d"), ++gs_nFrames);
   
   subframe->SetTitle(title);
   
   // Give it an icon
#ifdef __WXMSW__
   subframe->SetIcon(wxIcon("chrt_icn"));
#else
   subframe->SetIcon(wxIcon( mondrian_xpm ));
#endif
   
   // Make a menubar
   wxMenu *file_menu = new wxMenu;
   
   file_menu->Append(BG_NEW_IMAGE_WINDOW, "New &image window");
   file_menu->Append(BG_NEW_IMMATCH_WINDOW, "New &match window");
   file_menu->Append(BG_LOAD_IMAGE, "Load image");
   file_menu->Append(BG_IMMATCH_QUIT, "&Close window", "Close this window");
   file_menu->Append(BG_QUIT, "&Exit");
   
   wxMenu *matching_menu = new wxMenu;
   
   matching_menu->Append(BG_IMMATCH_CORNERS, "Find &Corners");
   matching_menu->Append(BG_IMMATCH_MATCH, "&Match Points");

   wxMenu *filedata_menu = new wxMenu;
   filedata_menu->Append(BG_IMMATCH_LOAD_POINTS, "Load Points");
   filedata_menu->AppendSeparator();
   filedata_menu->Append(BG_IMMATCH_SAVE_POINTS, "Save Points");
   
   wxMenu *help_menu = new wxMenu;
   help_menu->Append(BG_ABOUT, "&About");
   
   wxMenuBar *menu_bar = new wxMenuBar;
   
   menu_bar->Append(file_menu, "&File");
   menu_bar->Append(matching_menu, "&Matching");
   menu_bar->Append(filedata_menu, "&Data Access");
   menu_bar->Append(help_menu, "&Help");
   
   // Associate the menu bar with the frame
   subframe->SetMenuBar(menu_bar);
   
   subframe->CreateStatusBar();
   subframe->SetStatusText(title);
   
   int width, height;
   subframe->GetClientSize(&width, &height);
   
   subframe->Show(TRUE);
}


void BgMdiFrame::OnSize(wxSizeEvent& WXUNUSED(event))
{
   int w, h;
   GetClientSize(&w, &h);
   
   logtext_->SetSize(0, h-logsize_, w, logsize_);
   GetClientWindow()->SetSize(0, 0, w, h-logsize_);
}

void BgMdiFrame::InitToolBar(wxToolBar* toolBar)
{
   wxBitmap* bitmaps[2];
   int nbitmaps = 2;
#ifdef __WXMSW__
   bitmaps[0] = new wxBitmap("bg_ti_wimage", wxBITMAP_TYPE_RESOURCE);
   bitmaps[1]= new wxBitmap("bg_ti_wsegm", wxBITMAP_TYPE_RESOURCE);
   nbitmaps = 2;
#else
   bitmaps[0] = new wxBitmap( bg_wimage_xpm );
   bitmaps[1] = new wxBitmap( bg_wsegm_xpm );
#endif
   
#ifdef __WXMSW__
   int width = 24;
#else
   int width = 16;
#endif
   int currentX = 5;

   toolBar->AddTool( BG_NEW_IMAGE_WINDOW, *(bitmaps[0]), wxNullBitmap, FALSE, currentX, -1, (wxObject *) NULL, "New image window");
   currentX += width + 5;
   toolBar->AddTool( BG_NEW_IMMATCH_WINDOW, *(bitmaps[1]), wxNullBitmap, FALSE, currentX, -1, (wxObject *) NULL, "New matcher window");
   currentX += width + 5;
   toolBar->AddSeparator();

/*   
   toolBar->AddTool(BG_LOAD_IMAGE, *bitmaps[1], wxNullBitmap, FALSE, currentX, -1, (wxObject *) NULL, "Open file");
   currentX += width + 5;
   toolBar->AddTool(2, *bitmaps[2], wxNullBitmap, FALSE, currentX, -1, (wxObject *) NULL, "Save file");
   currentX += width + 5;
   toolBar->AddSeparator();
   toolBar->AddTool(3, *bitmaps[3], wxNullBitmap, FALSE, currentX, -1, (wxObject *) NULL, "Copy");
   currentX += width + 5;
   toolBar->AddTool(4, *bitmaps[4], wxNullBitmap, FALSE, currentX, -1, (wxObject *) NULL, "Cut");
   currentX += width + 5;
   toolBar->AddTool(5, *bitmaps[5], wxNullBitmap, FALSE, currentX, -1, (wxObject *) NULL, "Paste");
   currentX += width + 5;
   currentX += width + 5;
   toolBar->AddSeparator();
   toolBar->AddTool(6, *bitmaps[6], wxNullBitmap, FALSE, currentX, -1, (wxObject *) NULL, "Print");
   currentX += width + 5;
   toolBar->AddSeparator();
   toolBar->AddTool(7, *bitmaps[7], wxNullBitmap, TRUE, currentX, -1, (wxObject *) NULL, "Help");
 */  
   toolBar->Realize();
   
   int i;
   for (i = 0; i < nbitmaps; i++)
      delete bitmaps[i];
}

// ---------------------------------------------------------------------------
// BgMdiImChild
// ---------------------------------------------------------------------------

BgMdiImChild::BgMdiImChild(wxMDIParentFrame *parent, const wxString& title,
                           const wxPoint& pos, const wxSize& size,
                           const long style)
                           : wxMDIChildFrame(parent, -1, title, pos, size, style)
{
   canvas = (BgImageCanvas *) NULL;
   g_children.Append(this);
}

BgMdiImChild::~BgMdiImChild()
{
   g_children.DeleteObject(this);
}

void BgMdiImChild::OnQuit(wxCommandEvent& WXUNUSED(event))
{
   Close(TRUE);
}

void BgMdiImChild::OnRefresh(wxCommandEvent& WXUNUSED(event))
{
   if ( canvas )
      canvas->Refresh();
}

void BgMdiImChild::OnChangeTitle(wxCommandEvent& WXUNUSED(event))
{
   static wxString s_title = _T("Image Canvas");
   
   wxString title = wxGetTextFromUser(_T("Enter the new title for Image Canvas child"),
      _T("title change"),
      s_title,
      GetParent()->GetParent());
   if ( !title )
      return;
   
   s_title = title;
   SetTitle(s_title);
}

void BgMdiImChild::OnActivate(wxActivateEvent& event)
{
   if ( event.GetActive() && canvas )
      canvas->SetFocus();
}

void BgMdiImChild::OnClose(wxCloseEvent& event)
{
   if ( canvas && canvas->IsDirty() )
   {
      if ( wxMessageBox("Really close?", "Please confirm",
         wxICON_QUESTION | wxYES_NO) != wxYES )
      {
         event.Veto();
         
         return;
      }
   }
   
   gs_nFrames--;
   
   event.Skip();
}

void BgMdiImChild::OnLoadImage(wxCommandEvent& WXUNUSED(event) )
{

   // get the file name
   wxFileDialog filedialog(this,"Choose an image file","","",
      "PNG files (*.png)|*.png|BMP files (*.bmp)|*.bmp|GIF files (*.gif)|*.gif|TIFF files (*.tif)|*.tif|JPEG files (*.jpg)|*.jpg|PNM files (*.pnm)|*.pnm|All files (*.*)|*.*",
      wxOPEN);
   if(filedialog.ShowModal()==wxID_OK) {
      canvas->SetImage ( filedialog.GetPath() );
   }
   
}

// Start BgImageCanvas
/******************************************************************************/

// Define a constructor for my canvas
BgImageCanvas::BgImageCanvas(wxWindow *parent, const wxPoint& pos, const wxSize& size)
: wxScrolledWindow(parent, -1, pos, size,
                   wxSIMPLE_BORDER|wxVSCROLL|wxHSCROLL)
{
   SetBackgroundColour(wxColour("WHITE"));
   pbitmap_=(wxBitmap*) NULL;
   pimage_=(wxImage*) NULL;
   hasbitmap_=FALSE;
   showbitmap_ = TRUE;
   m_dirty = FALSE;
   nLineSets_ = nPointSets_ = 0;
   InitStyles();
   overDraw_ = 0;
   vimg_ = 1;
   mouseLClick_.Resize(1);
   mouseLClick_.x_[0] = mouseLClick_.y_[0] = 0;
   showMouseClick_ = 0;
   haveMouseClick_ = 0;
}


BgImageCanvas::~BgImageCanvas()
{
   ClearData();
}

void BgImageCanvas::ClearData()
{
   if(hasbitmap_==TRUE) {
      delete pbitmap_;
      delete pimage_;
   }
   hasbitmap_=FALSE;
   pbitmap_=(wxBitmap*) NULL;
   pimage_=(wxImage*) NULL;

   showbitmap_ = TRUE;
   m_dirty = FALSE;
   nLineSets_ = nPointSets_ = 0;
}

void BgImageCanvas::InitStyles()
{
   pstyle_[0].type_ = 0;
   pstyle_[0].pen_.SetColour(*wxBLUE);
   pstyle_[0].pen_.SetWidth(1);
   pstyle_[0].pen_.SetStyle(wxSOLID);

   pstyle_[1].type_ = 1;
   pstyle_[1].pen_.SetColour(*wxRED);
   pstyle_[1].pen_.SetWidth(1);
   pstyle_[1].pen_.SetStyle(wxSOLID);

   pstyle_[2].type_ = 0;
   pstyle_[2].pen_.SetColour(*wxRED);
   pstyle_[2].pen_.SetWidth(1);
   pstyle_[2].pen_.SetStyle(wxSOLID);

   lstyle_[0].type_ = 0;
   lstyle_[0].pen_.SetColour(*wxRED);
   lstyle_[0].pen_.SetWidth(1);
   lstyle_[0].pen_.SetStyle(wxSOLID);

   lstyle_[1].type_ = 1;
   lstyle_[1].pen_.SetColour(*wxBLUE);
   lstyle_[1].pen_.SetWidth(1);
   lstyle_[1].pen_.SetStyle(wxSOLID);

   lstyle_[2].type_ = 2;
   lstyle_[2].pen_.SetColour(*wxRED);
   lstyle_[2].pen_.SetWidth(1);
   lstyle_[2].pen_.SetStyle(wxSOLID);

   lstyle_[3].type_ = 1;
   lstyle_[3].pen_.SetColour(*wxWHITE);
   lstyle_[3].pen_.SetWidth(2);
   lstyle_[3].pen_.SetStyle(wxSOLID);
}

void BgImageCanvas::AddPointSet(BgPoints2D* p2d, int style)
{
   pointSet_[nPointSets_] = p2d;
   pointSetStyle_[nPointSets_++] = style;
   overDraw_ = 1;
   Refresh(FALSE);
}

void BgImageCanvas::ShowMouseClick(bool show)
{
   showMouseClick_ = show;
   Refresh(FALSE);
}

void BgImageCanvas::RemovePointSet(BgPoints2D* p2d)
{
   int i = 0;
   while (i<nPointSets_ && pointSet_[i]!=p2d)
      i++;
   if (i<nPointSets_)
   {
      i++;
      while(i<nPointSets_)
      {
         pointSet_[i-1] = pointSet_[i];
         pointSetStyle_[i-1] = pointSetStyle_[i];
         i++;
      }
      nPointSets_--;
   }
   overDraw_ = 1;
   Refresh(FALSE);
}

void BgImageCanvas::AddLineSet(BgPoints2D* p2d, int style)
{
   lineSet_[nLineSets_] = p2d;
   lineSetStyle_[nLineSets_++] = style;
   overDraw_ = 1;
   Refresh(FALSE);
}

void BgImageCanvas::RemoveLineSet(BgPoints2D* p2d)
{
   int i = 0;
   while (i<nLineSets_ && lineSet_[i]!=p2d)
      i++;
   if (i<nLineSets_)
   {
      i++;
      while(i<nLineSets_)
      {
         lineSet_[i-1] = lineSet_[i];
         lineSetStyle_[i-1] = lineSetStyle_[i];
         i++;
      }
      nLineSets_--;
   }
   overDraw_ = 1;
   Refresh(FALSE);
}

int BgImageCanvas::SetImage(wxString imname)
{
   ClearData();
   pimage_=new wxImage();
   if (!pimage_->LoadFile(imname))
   {
      wxLogError("Can't load image "+imname);
      return 0;
   }
   else
   {
      SetScrollbars(1, 1, (pimage_->GetWidth())/1, (pimage_->GetHeight())/1);
#if wxCHECK_VERSION(2, 3, 0)
      pbitmap_ = new wxBitmap(pimage_);
#else // new version
      pbitmap_ = new wxBitmap(pimage_->ConvertToBitmap());
#endif
      hasbitmap_=TRUE;
      m_dirty=TRUE;
      overDraw_ = 1;
      Refresh(FALSE);
      return 1;
   }
   return 0;
}

void BgImageCanvas::SetImage(wxImage& image)
{
   ClearData();
   pimage_=new wxImage();
   *pimage_ = image;
   SetScrollbars(1, 1, (pimage_->GetWidth())/1, (pimage_->GetHeight())/1);
#if wxCHECK_VERSION(2, 3, 0)
   pbitmap_ = new wxBitmap(pimage_);
#else
   pbitmap_ = new wxBitmap(pimage_->ConvertToBitmap());
#endif
   hasbitmap_=TRUE;
   m_dirty=TRUE;
   overDraw_ = 1;
   Refresh(FALSE);
   
}

void BgImageCanvas::SetSameImage(wxImage& image)
{
   *pimage_ = image;
#if wxCHECK_VERSION(2, 3, 0)
   *pbitmap_ = wxBitmap(image);
#else
   *pbitmap_ = image.ConvertToBitmap();
#endif
   overDraw_ = 1;
   Refresh(FALSE);
}

void BgImageCanvas::SetImageFromGray(unsigned char* data, int w, int h)
{
   ClearData();
   
   pimage_ = new wxImage(w, h);

   int i;
   unsigned char* itTData;
   itTData = pimage_->GetData();

   for (i=0; i<w*h; i++)
   {
      *(itTData++)=data[i];
      *(itTData++)=data[i];
      *(itTData++)=data[i];
   }
   SetScrollbars(1, 1, (pimage_->GetWidth())/1, (pimage_->GetHeight())/1);
#if wxCHECK_VERSION(2, 3, 0)
   pbitmap_ = new wxBitmap(pimage_);
#else
   pbitmap_ = new wxBitmap(pimage_->ConvertToBitmap());
#endif
   hasbitmap_=TRUE;
   m_dirty=TRUE;
   overDraw_ = 1;
   Refresh(FALSE);
}


// Define the repainting behaviour
void BgImageCanvas::OnDraw(wxDC& dc)
{
   if((hasbitmap_==TRUE && showbitmap_==TRUE) && (vimg_==1))
   {
      dc.DrawBitmap(*pbitmap_,0,0);
   }
   else 
   {
      dc.Clear();
   }

   // draw pointSets

   if (nPointSets_ > 0)
   {
      int i,j;
      double* tx;
      double* ty;
      int nt;
      wxPen tPen=dc.GetPen();
      dc.SetBrush(*wxTRANSPARENT_BRUSH);
      for (i=0; i<nPointSets_; i++)
      {
         dc.SetPen(pstyle_[pointSetStyle_[i]].pen_);
         nt = pointSet_[i]->n_;
         tx = pointSet_[i]->x_;
         ty = pointSet_[i]->y_;
         if(pstyle_[pointSetStyle_[i]].type_ == 0) // circle
         {
            for (j=0; j<nt; j++)
            {
               dc.DrawEllipse((int) (tx[j]-1.5), (int) (ty[j]-1.5), 5,5);
            }
         }
         else if(pstyle_[pointSetStyle_[i]].type_ == 1) // point
         {
            for (j=0; j<nt; j++)
            {
               dc.DrawPoint((int) (tx[j]+0.5), (int) (ty[j]+0.5));
            }
         }
         else if(pstyle_[pointSetStyle_[i]].type_ == 2) // cross
         {
            for (j=0; j<nt; j++)
            {
               dc.DrawPoint((int) (tx[j]+0.5), (int) (ty[j]+0.5));
            }
         }
      }
      dc.SetPen(tPen);
      dc.SetBrush(wxNullBrush);
   }

   if (showMouseClick_)
   {
      int j;
      double* tx;
      double* ty;
      int nt;
      wxPen tPen=dc.GetPen();
      dc.SetBrush(*wxTRANSPARENT_BRUSH);
      dc.SetPen(pstyle_[2].pen_);
      nt = mouseLClick_.n_;
      tx = mouseLClick_.x_;
      ty = mouseLClick_.y_;
      for (j=0; j<nt; j++)
      {
          dc.DrawEllipse((int) (tx[j]-1.5), (int) (ty[j]-1.5), 5,5);
      }
      dc.SetPen(tPen);
      dc.SetBrush(wxNullBrush);
   }

   if (nLineSets_ > 0)
   {
      int i,j;
      double* tx;
      double* ty;
      int nt;
      wxPen tPen=dc.GetPen();
      dc.SetBrush(*wxTRANSPARENT_BRUSH);
      for (i=0; i<nLineSets_; i++)
      {
         dc.SetPen(lstyle_[lineSetStyle_[i]].pen_);
         nt = lineSet_[i]->n_;
         tx = lineSet_[i]->x_;
         ty = lineSet_[i]->y_;

         if (lstyle_[lineSetStyle_[i]].type_ == 0) // continuous line
         {
            for (j=0; j<(nt-1); j++)
            {
               dc.DrawLine((int) (tx[j]+0.5), (int) (ty[j]+0.5), (int) (tx[j+1]+0.5), (int) (ty[j+1]+0.5));
            }
         } else if (lstyle_[lineSetStyle_[i]].type_ == 1) // separate lines
         {
            for (j=0; j<(nt-1); j+=2)
            {
               dc.DrawLine((int) (tx[j]+0.5), (int) (ty[j]+0.5), (int) (tx[j+1]+0.5), (int) (ty[j+1]+0.5));
            }
         } else if (lstyle_[lineSetStyle_[i]].type_ == 2) // separate lines with end point
         {
            for (j=0; j<(nt-1); j+=2)
            {
               dc.DrawLine((int) (tx[j]+0.5), (int) (ty[j]+0.5), (int) (tx[j+1]+0.5), (int) (ty[j+1]+0.5));
               dc.DrawEllipse((int) (tx[j]-1.5), (int) (ty[j]-1.5), 5, 5);
            }
         }

      }
      dc.SetPen(tPen);
      dc.SetBrush(wxNullBrush);
   }
}

void BgImageCanvas::OnMouseLClick(wxMouseEvent& event)
{
   wxClientDC dc(this);
   PrepareDC(dc);
   wxPoint pt(event.GetLogicalPosition(dc));
   int x;
   int y;
   x = pt.x;
   y = pt.y;
   mouseLClick_.SetPoints(&x, &y, 1);
   bgLog("position: %d %d\n", x, y);
   if (showMouseClick_)
      Refresh(FALSE);
   if (haveMouseClick_ == 0)
   {
      haveMouseClick_ = 1;
      AddPendingEvent(wxCommandEvent(wxEVT_COMMAND_MENU_SELECTED, BG_IMMATCH_ADDCANVASPOINT));
   }
}


// End BgImageCanvas
/******************************************************************************/


// ---------------------------------------------------------------------------
// BgMdiMatchingChild
// ---------------------------------------------------------------------------

BgMdiImMatchingChild::BgMdiImMatchingChild(wxMDIParentFrame *parent, const wxString& title,
                           const wxPoint& pos, const wxSize& size,
                           const long style)
                           : wxMDIChildFrame(parent, -1, title, pos, size, style)
{

   canvasSplitter_ = new wxSplitterWindow(this, -1, wxPoint(SEQ_PANEL_SIZE_X, 0), wxDefaultSize, wxSP_NOBORDER | wxSP_3DSASH);
   leftCanvas_ = new BgImageCanvas(canvasSplitter_, wxDefaultPosition, wxDefaultSize);
   leftCanvas_->SetScrollbars(20,20,50,50);
   rightCanvas_ = new BgImageCanvas(canvasSplitter_, wxDefaultPosition, wxDefaultSize);
   rightCanvas_->SetScrollbars(20,20,50,50);

   // build the panels
   buttonPanel_ = new wxPanel(this, -1, wxPoint(0, 0), wxSize(SEQ_PANEL_SIZE_X, SEQ_BPANEL_SIZE_Y));

   //buttonLLImageBmp_ = new wxBitmap("BG_LL_LOAD_IMAGE", wxBITMAP_TYPE_RESOURCE);
   //buttonLRImageBmp_ = new wxBitmap("BG_LR_LOAD_IMAGE", wxBITMAP_TYPE_RESOURCE);
   //buttonLLImage_ = new wxBitmapButton(buttonPanel_, BG_IMMATCH_LOADLIMAGE, *buttonLLImageBmp_, wxPoint(5,5), wxSize(-1,-1));
   //buttonLRImage_ = new wxBitmapButton(buttonPanel_, BG_IMMATCH_LOADRIMAGE, *buttonLRImageBmp_, wxPoint(25,5), wxSize(-1,-1));
   buttonLLImage_ = new wxButton(buttonPanel_, BG_IMMATCH_LOADLIMAGE, "Left Image", wxPoint(5,5), wxSize(-1,-1));
   buttonLRImage_ = new wxButton(buttonPanel_, BG_IMMATCH_LOADRIMAGE, "Right Image", wxPoint(135,5), wxSize(-1,-1));

   seqTreeCtrl_ = new wxTreeCtrl(buttonPanel_, BG_IMMATCH_TREE_CLICK, wxPoint(0, SEQ_TPANEL_POZ_Y), wxSize(SEQ_PANEL_SIZE_X, SEQ_BPANEL_SIZE_Y-SEQ_TPANEL_POZ_Y));
   seqRootAllId_ = seqTreeCtrl_->AddRoot("Left Points");

   algorithmPanel_ = new wxPanel(this, -1, wxPoint(0, SEQ_BPANEL_SIZE_Y), wxSize(SEQ_PANEL_SIZE_X, SEQ_APANEL_SIZE_Y));

   labelChoice_ = new wxStaticText(algorithmPanel_, -1, "Algorithm\nparameters",wxPoint(5,5), wxSize(-1,-1));
   algorithmRunButton_ = new wxButton(algorithmPanel_, BG_IMMATCH_RUNALG, "Run",wxPoint(75, 5), wxSize(40,20));
   algorithmChoice_ = new wxChoice(algorithmPanel_, BG_IMMATCH_ALG_SEL, wxPoint(120, 5), wxSize(-1,-1));
   algorithmChoice_->Append("Corner Detection");
   algorithmChoice_->Append("CDOF Matching");
   algorithmChoice_->SetSelection(1);


   // property panel init
   listValidatorRegistry_.RegisterValidator((wxString)"real", new wxRealListValidator);
   listValidatorRegistry_.RegisterValidator((wxString)"string", new wxStringListValidator);
   listValidatorRegistry_.RegisterValidator((wxString)"integer", new wxIntegerListValidator);
   listValidatorRegistry_.RegisterValidator((wxString)"bool", new wxBoolListValidator);
   listValidatorRegistry_.RegisterValidator((wxString)"stringlist", new wxListOfStringsListValidator);
   listValidatorRegistry_.RegisterValidator((wxString)"intkernel", new wxIntegerListValidator(1,41));
   
   // corner property sheet init
   cornerPropSheet_ = new wxPropertySheet;
   pcornFilterSize_=new wxProperty("filter size", (long) HAR_SDKER_SZ, "intkernel");
   cornerPropSheet_->AddProperty(pcornFilterSize_);
   pcornVecinitySize_=new wxProperty("vecinity size", (long) HAR_VECKER_SZ, "intkernel");
   cornerPropSheet_->AddProperty(pcornVecinitySize_);
   pcornPercentSelect_=new wxProperty("selection percent", HAR_TRESH_PERC, "real", new wxRealListValidator(0,1));
   cornerPropSheet_->AddProperty(pcornPercentSelect_);
   pcornBorder_ = new wxProperty("border", (long) BG_HAR_BORDER, "intkernel");
   cornerPropSheet_->AddProperty(pcornBorder_);

   pSearchTypeString_ = new wxStringList("same as left", "best grid", "full grid", NULL);
   listValidatorRegistry_.RegisterValidator((wxString)"mystring", new wxStringListValidator(pSearchTypeString_));


   // color distribution/optical flow params
   cdofSheet_ = new wxPropertySheet;
   pcdofpyrLevels_ = new wxProperty("Levels", (long) BG_CDOF_PLEVELS, "integer"); //int
   pcdofpyrRatio_ = new wxProperty("pratio", (long) BG_CDOF_PRATIO, "integer") ; //int
   pcdofpyrFSize_ = new wxProperty("pfsize", (long) BG_CDOF_PFSIZE, "integer") ; //int
   pcdofpyrType_ = new wxProperty("ptype", (long) BG_CDOF_PTYPE, "integer"); //int
   switch (BG_CDOF_SEARCHTYPE)
   {
   case 0:
      pcdofsearchType_ = new wxProperty("Search start", "same as left", "mystring");
      break;
   case 2:
      pcdofsearchType_ = new wxProperty("Search start", "full grid", "mystring");
      break;
   default:
      pcdofsearchType_ = new wxProperty("Search start", "best grid", "mystring");
      break;
   }
   pcdofdt_ = new wxProperty("Win. Size", (long) BG_CDOF_DT, "integer"); //int
   pcdofmaxNTrial_ = new wxProperty("Max trials", (long) BG_CDOF_MAXTRIAL, "integer"); //int
   pcdofnormLimit_ = new wxProperty("Min norm", (double) BG_CDOF_MINNORM, "real"); //double
   pcdofuseBiweight_ = new wxProperty("useBW", (long) BG_CDOF_USEBW, "integer"); //int
   pcdofnBwTrials_ = new wxProperty("nBWtrials", (long) BG_CDOF_NBWTRIALS, "integer"); //int
   pcdofbwSigmaOF_ = new wxProperty("sigmaOF", (double) BG_CDOF_SIGMAOF, "real"); //double
   pcdofbwSigmaCDP_ = new wxProperty("sigmaCDP", (double) BG_CDOF_SIGMACDP, "real"); //double
   pcdofbwSigmaCDM_ = new wxProperty("sigmaCDM", (double) BG_CDOF_SIGMACDM, "real"); //double
   pcdofalgUseTr_ = new wxProperty("useTr", (long) BG_CDOF_USETR, "integer"); //int
   pcdofalgUseRot1_ = new wxProperty("useR1", (long) BG_CDOF_USER1, "integer"); //int
   pcdofalgUseRot2_ = new wxProperty("useR2", (long) BG_CDOF_USER2, "integer"); //int
   pcdofalgUseScale_ = new wxProperty("useSc", (long) BG_CDOF_USESC, "integer"); //int
   pcdofalgUseProj_ = new wxProperty("usePr", (long) BG_CDOF_USEPR, "integer"); //int
   pcdofalgUseCScale_ = new wxProperty("useCSC", (long) BG_CDOF_USECSC, "integer"); //int
   pcdofratioOF_ = new wxProperty("ratioOF", (double) BG_CDOF_RATIOOF, "real"); //double
   pcdofratioCD_ = new wxProperty("ratioCD", (double) BG_CDOF_RATIOCD, "real"); //double
   pcdofdeltaGS_ = new wxProperty("Grid Step", (long) BG_CDOF_DELTAGS, "integer"); //int
   pcdoflblend_ = new wxProperty("trk blend", (double) BG_CDOF_TBLEND, "real"); //double
   pcdofnbins_ = new wxProperty("CD Bins", (long) BG_CDOF_NBINS, "integer"); // int
   pcdofsave_ = new wxProperty("Full Save", (long) 0, "integer");

   //if you include this take them out from destructor
   cdofSheet_->AddProperty(pcdofpyrLevels_);
//   cdofSheet_->AddProperty(pcdofpyrRatio_);
//   cdofSheet_->AddProperty(pcdofpyrFSize_);
//   cdofSheet_->AddProperty(pcdofpyrType_);
   cdofSheet_->AddProperty(pcdofsearchType_);
   cdofSheet_->AddProperty(pcdofdt_);
   cdofSheet_->AddProperty(pcdofmaxNTrial_);
   cdofSheet_->AddProperty(pcdofnormLimit_);
//   cdofSheet_->AddProperty(pcdofuseBiweight_);
//   cdofSheet_->AddProperty(pcdofnBwTrials_);
//   cdofSheet_->AddProperty(pcdofbwSigmaOF_);
//   cdofSheet_->AddProperty(pcdofbwSigmaCDP_);
//   cdofSheet_->AddProperty(pcdofbwSigmaCDM_);
   cdofSheet_->AddProperty(pcdofalgUseTr_);
   cdofSheet_->AddProperty(pcdofalgUseRot1_);
   cdofSheet_->AddProperty(pcdofalgUseRot2_);
   cdofSheet_->AddProperty(pcdofalgUseScale_);
   cdofSheet_->AddProperty(pcdofalgUseProj_);
   cdofSheet_->AddProperty(pcdofalgUseCScale_);
   cdofSheet_->AddProperty(pcdofratioOF_);
   cdofSheet_->AddProperty(pcdofratioCD_);
   cdofSheet_->AddProperty(pcdofdeltaGS_);
//   cdofSheet_->AddProperty(pcdoflblend_);
   cdofSheet_->AddProperty(pcdofnbins_);
   cdofSheet_->AddProperty(pcdofsave_);

   
   propListView_ = new wxPropertyListView(NULL, wxPROP_BUTTON_CHECK_CROSS|wxPROP_DYNAMIC_VALUE_FIELD|wxPROP_PULLDOWN|wxPROP_SHOWVALUES);

   propListPanel_ = new wxPropertyListPanel(propListView_, algorithmPanel_, wxPoint(0, SEQ_APPANEL_POZ_Y), wxSize(SEQ_PANEL_SIZE_X, SEQ_APANEL_SIZE_Y-SEQ_APPANEL_POZ_Y));

   propListView_->AddRegistry(&listValidatorRegistry_);

   propListView_->ShowView(cornerPropSheet_, propListPanel_);

   g_children.Append(this);

   canvasSplitter_->SplitVertically(leftCanvas_, rightCanvas_, 256);

   int w, h;
   GetClientSize(&w, &h);
   
   canvasSplitter_->SetSize(SEQ_PANEL_SIZE_X, 0, w-SEQ_PANEL_SIZE_X, h);
   canvasSplitter_->SetSashPosition((int) (2*(w-SEQ_PANEL_SIZE_X)/3), true);
   w=h-SEQ_APANEL_SIZE_Y;
   w = w>SEQ_BPANEL_SIZE_Y ? w : SEQ_BPANEL_SIZE_Y;
   buttonPanel_->SetSize(0,0,SEQ_PANEL_SIZE_X, w);
   algorithmPanel_->SetSize(0, w, SEQ_PANEL_SIZE_X, SEQ_APANEL_SIZE_Y);
   hasLImage_ = 0;
   hasRImage_ = 0;
   addPointsCheck_ = 0;
}

BgMdiImMatchingChild::~BgMdiImMatchingChild()
{
   ClearData();

   delete buttonPanel_;
   delete algorithmPanel_;
   delete propListView_;
   delete cornerPropSheet_;
   delete cdofSheet_;


delete pcdofpyrRatio_;
delete pcdofpyrFSize_;
delete pcdofpyrType_;
delete pcdofuseBiweight_;
delete pcdofnBwTrials_;
delete pcdofbwSigmaOF_;
delete pcdofbwSigmaCDP_;
delete pcdofbwSigmaCDM_;
delete pcdoflblend_;


   delete leftCanvas_;
   delete rightCanvas_;
   delete canvasSplitter_;

   g_children.DeleteObject(this);
}

void BgMdiImMatchingChild::OnQuit(wxCommandEvent& WXUNUSED(event))
{
   Close(TRUE);
}

void BgMdiImMatchingChild::OnRefresh(wxCommandEvent& WXUNUSED(event))
{
   if ( canvasSplitter_ )
      canvasSplitter_->Refresh();
}

void BgMdiImMatchingChild::OnClose(wxCloseEvent& event)
{
   if ( leftCanvas_ && leftCanvas_->IsDirty() )
   {
      if ( wxMessageBox("Really close?", "Please confirm",
         wxICON_QUESTION | wxYES_NO) != wxYES )
      {
         event.Veto();
         
         return;
      }
   }
   
   gs_nFrames--;
   
   event.Skip();
}

void BgMdiImMatchingChild::OnSize(wxSizeEvent& WXUNUSED(event))
{
   int w, h;
   GetClientSize(&w, &h);
   
   canvasSplitter_->SetSize(SEQ_PANEL_SIZE_X, 0, w-SEQ_PANEL_SIZE_X, h);
   w=h-SEQ_APANEL_SIZE_Y;
   w = w>SEQ_BPANEL_SIZE_Y ? w : SEQ_BPANEL_SIZE_Y;
   buttonPanel_->SetSize(0,0,SEQ_PANEL_SIZE_X, w);
   seqTreeCtrl_->SetSize(0,SEQ_TPANEL_POZ_Y, SEQ_PANEL_SIZE_X, w-SEQ_TPANEL_POZ_Y);
   algorithmPanel_->SetSize(0, w, SEQ_PANEL_SIZE_X, SEQ_APANEL_SIZE_Y);
}

void BgMdiImMatchingChild::ClearData()
{
   seqTreeCtrl_->DeleteAllItems();
   leftCanvas_->RemovePointSet(&limselpoints_);
   leftCanvas_->RemovePointSet(&limpoints_);
   rightCanvas_->RemovePointSet(&rimselpoints_);
   rightCanvas_->RemovePointSet(&rimpoints_);
}

void BgMdiImMatchingChild::OnChoiceAlgorithm(wxCommandEvent& WXUNUSED(event))
{
   switch(algorithmChoice_->GetSelection()) {
   case 0:
      propListView_->ShowView(cornerPropSheet_, propListPanel_);
      break;
   case 1:
      propListView_->ShowView(cdofSheet_, propListPanel_);
      break;
   }
}

void BgMdiImMatchingChild::OnRunAlgorithm(wxCommandEvent& WXUNUSED(event))
{
   wxCommandEvent zcev;
   switch(algorithmChoice_->GetSelection())
   {
   case 0:
      OnHarrisCorners(zcev);
      break;

   case 1:
      OnCDOFMatching(zcev);
      break;
   }
}

void BgMdiImMatchingChild::OnLoadCorners(wxCommandEvent&  WXUNUSED(event))
{
   // get the file name
   wxFileDialog filedialog(this,"Choose the points file","","",
      "PTR files (*.ptr)|*.ptr|all files (*.*)|*.*",
      wxOPEN);
   if (filedialog.ShowModal()==wxID_OK)
   {
      bgLog("Load points...");
      // clear view
   
      ClearData();

      wxString stTmp = filedialog.GetPath();

      // load corners
      limpoints_.CleanData();
      rimpoints_.CleanData();
      FILE* fd;
      fd = fopen(stTmp.c_str(), "r");
      if (fd==0)
         return;
      limpoints_.Read(fd);
      rimpoints_.Read(fd);
      fclose(fd);

      if (hasLImage_ == 1)
         leftCanvas_->AddPointSet(&limpoints_);
      if (hasRImage_ == 1)
         rightCanvas_->AddPointSet(&rimpoints_);

      ResetPointsTree();

      // update image canvas

      bgLog("done\n");
   }
}


void BgMdiImMatchingChild::OnSaveCorners(wxCommandEvent&  WXUNUSED(event))
{
   wxFileDialog filedialog(this,"Choose an file to save","","",
      "PTR files (*.ptr)|*.ptr",
      wxSAVE | wxOVERWRITE_PROMPT);
   if (filedialog.ShowModal()==wxID_OK)
   {

      // open the file
      wxString seqFileName=filedialog.GetPath();

      bgLog("Save corners...");
      FILE* fd;
      fd = fopen(seqFileName.c_str(), "w");
      if(fd==0)
         return;
      limpoints_.Write(fd);
      rimpoints_.Write(fd);
      fclose(fd);

      // save corners

      bgLog("done\n");
   }
}

void BgMdiImMatchingChild::OnLoadLeftImage(wxCommandEvent& WXUNUSED(event))
{
#if defined(__WXGTK__) || defined(__WXMOTIF__)
  wxFileDialog filedialog(this,"Choose the left image","","",
			  "*",wxOPEN);
#else
   wxFileDialog filedialog(this,"Choose the left image","","",
      "Common image files|*.png;*.bmp;*.gif;*.tif;*.tiff;*.jpg;*.pnm;*.pgm;*.ppm|PNG files (*.png)|*.png|BMP files (*.bmp)|*.bmp|GIF files (*.gif)|*.gif|TIFF files (*.tif)|*.tif|JPEG files (*.jpg)|*.jpg|PNM files (*.pnm)|*.pnm|PGM/PPM files (*.pgm,*.ppm)|*.pgm;*.ppm",
      wxOPEN);
#endif
   if(filedialog.ShowModal()==wxID_OK)
   {
      // clear views
      ClearData();
      limpoints_.CleanData();
      rimpoints_.CleanData();
      ResetPointsTree();


      if (leftCanvas_->SetImage(filedialog.GetPath().c_str()) == 0)
         return;
      bgLog("Left image %s loaded\n",filedialog.GetPath().c_str());

	  //obtain and store image filename
	  strcpy(limname_, filedialog.GetFilename().c_str());

      leftCanvas_->showbitmap_ = true;

      // set cbgImage
      bglimage_.SetImageFromRGB(leftCanvas_->pimage_->GetData(), leftCanvas_->pimage_->GetWidth(), leftCanvas_->pimage_->GetHeight(), true);
      hasLImage_ = 1;

      //suggest pyramid size
      int tsize = leftCanvas_->pimage_->GetWidth();
      if (leftCanvas_->pimage_->GetHeight() < tsize)
         tsize = leftCanvas_->pimage_->GetHeight();
      int mysize;
      mysize = (int) (floor(log(tsize/200.0)/log(2)) + 1.5);
      pcdofpyrLevels_->SetValue(wxPropertyValue((long) mysize));
   
      mysize = BG_HAR_BORDER*(tsize/100);
      if(mysize>41)
         mysize = 41;
      pcornBorder_->SetValue(wxPropertyValue((long) mysize));
      mysize = HAR_VECKER_SZ*(tsize/100);
      if(mysize>41)
         mysize = 41;
      pcornVecinitySize_->SetValue(wxPropertyValue((long) mysize));

      if(algorithmChoice_->GetSelection() == 1)
         propListView_->ShowView(cdofSheet_, propListPanel_);
      if(algorithmChoice_->GetSelection() == 0)
         propListView_->ShowView(cornerPropSheet_, propListPanel_);

   }
}

void BgMdiImMatchingChild::OnLoadRightImage(wxCommandEvent& WXUNUSED(event))
{
#if defined(__WXGTK__) || defined(__WXMOTIF__)
  wxFileDialog filedialog(this,"Choose the right image","","",
			  "*",wxOPEN);
#else
   wxFileDialog filedialog(this,"Choose the right image","","",
      "Common image files|*.png;*.bmp;*.gif;*.tif;*.tiff;*.jpg;*.pnm;*.pgm;*.ppm|PNG files (*.png)|*.png|BMP files (*.bmp)|*.bmp|GIF files (*.gif)|*.gif|TIFF files (*.tif)|*.tif|JPEG files (*.jpg)|*.jpg|PNM files (*.pnm)|*.pnm|PGM/PPM files (*.pgm,*.ppm)|*.pgm;*.ppm",
      wxOPEN);
#endif
   if(filedialog.ShowModal()==wxID_OK)
   {
      // clear views
      rightCanvas_->RemovePointSet(&rimpoints_);
      rimpoints_.CleanData();

      if (rightCanvas_->SetImage(filedialog.GetPath().c_str()) == 0)
         return;
      bgLog("Right image %s loaded\n",filedialog.GetPath().c_str());

	  //obtain and store image filename
	  strcpy(rimname_, filedialog.GetFilename().c_str());

      rightCanvas_->showbitmap_ = true;

      // set cbgImage
      bgrimage_.SetImageFromRGB(rightCanvas_->pimage_->GetData(), rightCanvas_->pimage_->GetWidth(), rightCanvas_->pimage_->GetHeight(), true);
      hasRImage_ = 1;

   }
}

void BgMdiImMatchingChild::OnTreeFrameClick(wxTreeEvent& treevent)
{
   
   const wxTreeItemId clickedIt = treevent.GetItem();
   if (seqTreeCtrl_->GetItemParent(clickedIt) == seqRootAllId_)
   {
      wxString crtstr;
      wxString tstr;
      long index;
      crtstr = seqTreeCtrl_->GetItemText(clickedIt);
      if (crtstr.StartsWith("Point ",&tstr))
         tstr.ToLong(&index);
      if ((index >= 0) && (index<limpoints_.n_))
      {
         bgLog("Point %d: (%.1f, %.1f)", index, limpoints_.x_[index], limpoints_.y_[index]);
         limselpoints_.Resize(1);
         limselpoints_.x_[0] = limpoints_.x_[index];
         limselpoints_.y_[0] = limpoints_.y_[index];
         leftCanvas_->RemovePointSet(&limselpoints_);
         leftCanvas_->AddPointSet(&limselpoints_,2);
         if (index<rimpoints_.n_)
         {
            rimselpoints_.Resize(1);
            rimselpoints_.x_[0] = rimpoints_.x_[index];
            rimselpoints_.y_[0] = rimpoints_.y_[index];
            rightCanvas_->RemovePointSet(&rimselpoints_);
            rightCanvas_->AddPointSet(&rimselpoints_,2);
            bgLog("  (%.1f, %.1f) score: %g",rimpoints_.x_[index], rimpoints_.y_[index], rimpointsscores_.x_[index]);
         }
         bgLog("\n");
      }  
   }
}


void BgMdiImMatchingChild::OnTreeFrameSelect(wxTreeEvent& treevent)
{
  
   const wxTreeItemId clickedIt = treevent.GetItem();
   long index = -1;
   if (clickedIt == seqRootAllId_)
   {
      wxPoint wp = treevent.GetPoint();

      wxMenu mpop;
      mpop.Append(BG_IMMATCH_REMOVEALL, "Remove all");
      mpop.AppendCheckItem(BG_IMMATCH_ADDPOINTS, "Add points");
      if (addPointsCheck_)
         mpop.Check(BG_IMMATCH_ADDPOINTS,1);
      PopupMenu(&mpop,wp);
   }
}

void BgMdiImMatchingChild::OnRemoveAllPoints(wxCommandEvent& WXUNUSED(event))
{
   ClearData();
   limpoints_.CleanData();
   rimpoints_.CleanData();
   ResetPointsTree();
//   addPointsCheck_ = 0;
}

void BgMdiImMatchingChild::OnAddPointsCheck(wxCommandEvent& WXUNUSED(event))
{
   if (addPointsCheck_)
      addPointsCheck_ = 0;
   else
      addPointsCheck_ = 1;
}

void BgMdiImMatchingChild::OnAddCanvasPoint(wxCommandEvent& WXUNUSED(event))
{
   if (leftCanvas_->haveMouseClick_)
   {
      if (addPointsCheck_)
      {
         limpoints_.AddPoints(leftCanvas_->mouseLClick_);
         leftCanvas_->RemovePointSet(&limpoints_);
         leftCanvas_->AddPointSet(&limpoints_);

         wxString tstr;
         tstr = tstr.Format("Point %d",limpoints_.n_-1);
         seqTreeCtrl_->AppendItem(seqRootAllId_, tstr);
         seqTreeCtrl_->Expand(seqRootAllId_);
      } else
      {
         ClearData();
         limpoints_.CleanData();
         rimpoints_.CleanData();
         ResetPointsTree();
         limpoints_.AddPoints(leftCanvas_->mouseLClick_);

         leftCanvas_->RemovePointSet(&limpoints_);
         leftCanvas_->AddPointSet(&limpoints_);

         wxString tstr;
         tstr = tstr.Format("Point %d",limpoints_.n_-1);
         seqTreeCtrl_->AppendItem(seqRootAllId_, tstr);
         seqTreeCtrl_->Expand(seqRootAllId_);
      }
      leftCanvas_->haveMouseClick_ = 0;
   }
}


void BgMdiImMatchingChild::ResetPointsTree()
{
   seqTreeCtrl_->DeleteAllItems();
   seqRootAllId_ = seqTreeCtrl_->AddRoot("Left Points");

   wxString tstr;
   int i;
   for (i=0; i<limpoints_.n_; i++)
   {
      tstr = tstr.Format("Point %d",i);
      seqTreeCtrl_->AppendItem(seqRootAllId_, tstr);
   }
   seqTreeCtrl_->Expand(seqRootAllId_);
}


void BgMdiImMatchingChild::OnLoadImages(wxCommandEvent& WXUNUSED(event))
{
   OnLoadLeftImage(wxCommandEvent());
   OnLoadRightImage(wxCommandEvent());
}


// compute corners with Harris method for left image
void BgMdiImMatchingChild::OnHarrisCorners(wxCommandEvent& WXUNUSED(event))
{
   if (hasLImage_ == 0)
   {
      bgLog("Load left image first!\n");
      return;
   }

   bgLog("detect corners left image...");
   // clear views
   leftCanvas_->RemovePointSet(&limselpoints_);
   leftCanvas_->RemovePointSet(&limpoints_);
   rightCanvas_->RemovePointSet(&rimpoints_);
   rightCanvas_->RemovePointSet(&rimselpoints_);

   // set parameters

   // detect corners   
   BgHarrisCorners cHarrisCorners(
   pcornFilterSize_->GetValue().IntegerValue(),
      pcornVecinitySize_->GetValue().IntegerValue(),
      pcornPercentSelect_->GetValue().RealValue());

   float *cornx;
   float *corny;
   int nCorn;
   int imWidth = bglimage_.GetWidth();
   int imHeight = bglimage_.GetHeight();
   cornx =  new float[imWidth*imHeight];
   corny =  new float[imWidth*imHeight];

   cHarrisCorners.DoHarrisCorners(&bglimage_, cornx, corny, &nCorn);

   //select only the ones inside border
   int border = pcornBorder_->GetValue().IntegerValue();
   int i, nVCorn;
   nVCorn = 0;
   float *vcornx, *vcorny;
   vcornx = new float[nCorn];
   vcorny = new float[nCorn];
   for (i=0; i<nCorn; i++)
   {
      if ((cornx[i]>=border) && (corny[i]>=border) &&
         (cornx[i]<(imWidth-border)) && (corny[i]<(imHeight-border)))
      {
         vcornx[nVCorn] = cornx[i];
         vcorny[nVCorn] = corny[i];
         nVCorn++;
      }
   }

   if (nVCorn > 0)
      limpoints_.SetPoints(vcornx, vcorny, nVCorn);
   delete [] vcornx;
   delete [] vcorny;
   
   delete [] cornx;
   delete [] corny;

   // update image canvas
   leftCanvas_->AddPointSet(&limpoints_);

   ResetPointsTree();
   // done
   bgLog("done\n");
}

// find current points in right image
void BgMdiImMatchingChild::OnCDOFMatching(wxCommandEvent& WXUNUSED(event))
{
   if ((hasLImage_ == 0) || (hasRImage_ == 0) || (limpoints_.n_<=0))
   {
      bgLog("something is missing...\n");
      return;
   }
   // clear views
   rightCanvas_->RemovePointSet(&rimselpoints_);
   rightCanvas_->RemovePointSet(&rimpoints_);

   // set parameters
   BgCdOfTracker cdofc;

   int searchType;
   char* tmpchar;
   char* tmplist[]={"same as left", "best grid", "full grid"};

   tmpchar = pcdofsearchType_->GetValue().StringValue();
   searchType = 1;
   if (strcmp(tmpchar, tmplist[0]) == 0)
      searchType = 0;
   else if (strcmp(tmpchar, tmplist[1]) == 0)
      searchType = 1;
   else if (strcmp(tmpchar, tmplist[2]) == 0)
      searchType = 2;


   cdofc.SetParameters(pcdofpyrLevels_->GetValue().IntegerValue(),
      pcdofpyrRatio_->GetValue().IntegerValue(),
      pcdofpyrFSize_->GetValue().IntegerValue(),
      pcdofpyrType_->GetValue().IntegerValue(),
      pcdofdt_->GetValue().IntegerValue(),
      pcdofnormLimit_->GetValue().RealValue(),
      pcdofmaxNTrial_->GetValue().IntegerValue(),
      pcdofuseBiweight_->GetValue().IntegerValue(),
      pcdofnBwTrials_->GetValue().IntegerValue(),
      pcdofbwSigmaOF_->GetValue().RealValue(),
      pcdofbwSigmaCDP_->GetValue().RealValue(),
      pcdofbwSigmaCDM_->GetValue().RealValue(),
      pcdoflblend_->GetValue().RealValue(),
      pcdofratioOF_->GetValue().RealValue(),
      pcdofratioCD_->GetValue().RealValue(),
      pcdofdeltaGS_->GetValue().IntegerValue(),
      pcdofalgUseTr_->GetValue().IntegerValue(),
      pcdofalgUseRot1_->GetValue().IntegerValue(),
      pcdofalgUseRot2_->GetValue().IntegerValue(),
      pcdofalgUseScale_->GetValue().IntegerValue(),
      pcdofalgUseProj_->GetValue().IntegerValue(),
      pcdofalgUseCScale_->GetValue().IntegerValue(),
      searchType,
      pcdofnbins_->GetValue().IntegerValue());

   // run
   bgLog("Start CdOf Matching...\n");
   rimpoints_.CleanData();
   rimpoints_.AddPoints(limpoints_);
   rimpointsscores_.Resize(rimpoints_.n_);

   if(pcdofsave_->GetValue().IntegerValue())
      cdofc.fullsave_ = 1;

   cdofc.MainMatch(&bglimage_, &bgrimage_, &limpoints_, &rimpoints_, rimpointsscores_.x_);

   bgLog("CdOf Matching done.\n");

   // update image canvas
   // rightCanvas_->AddPointSet(&rimselpoints_);
   rightCanvas_->AddPointSet(&rimpoints_);

}

// End BgMdiMatchingChild
/******************************************************************************/
