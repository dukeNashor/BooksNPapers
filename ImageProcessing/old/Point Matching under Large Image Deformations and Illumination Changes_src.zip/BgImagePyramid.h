/////////////////////////////////////////////////////////////////////////////
// Name:        BgImagePyramid.h
// Purpose:     BgImagePyramid class
// Author:      Bogdan Georgescu
// Modified by:
// Created:     11/14/2002
// Copyright:   (c) Bogdan Georgescu
// Version:     v0.1
/////////////////////////////////////////////////////////////////////////////

#ifndef _BG_IMAGEPYRAMID_H
#define _BG_IMAGEPYRAMID_H

#include "BgImage.h"

#define BG_IP_GAUSS_TAIL 0.01

class BgImagePyramid
{
public:
   BgImagePyramid();
   ~BgImagePyramid();

   int BuildPyramid(BgImage& image, int n_levels, int ratio, int type, int f_size);
   int ClearData();
   int Resize(int wx, int wy, int bpp, int n_levels, int ratio);

   void binomial_filters(double* smofil, int WL);
   void gauss_filters(double* smofil, int WL);
   double factorial(double num);

   int hasPyramid_;
   double* pyramid_; // pyramid data wx0*wy0 + wx0/ratio*wy0/ratio + ...
   int n_levels_;    // number of levels
   int ratio_;
   int type_;        // 0 gaussian pyramids
                     // 1 laplacian pyramids
                     // 2 binomial pyramids
                     // 3 laplacian-binomial pyramids
                     // 4 laplacian pyramids, last level is also laplacian (gauss filter)
                     // 5 laplacian pyramids, last level is also laplacian (binomial filter)
   int bpp_;         // bits/pixel supports only 1 (gray) or 3 (color)


   int *wx_;       // pyramid dimensions
   int *wy_;

};

#endif