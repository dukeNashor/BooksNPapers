/////////////////////////////////////////////////////////////////////////////
// Name:        BgImagePyramid.cpp
// Purpose:     BgImagePyramid class functions
// Author:      Bogdan Georgescu
// Modified by:
// Created:     11/14/2002
// Copyright:   (c) Bogdan Georgescu
// Version:     v0.1
/////////////////////////////////////////////////////////////////////////////

#include <math.h>
#include <stdlib.h>
#include "BgImagePyramid.h"


BgImagePyramid::BgImagePyramid()
{
   pyramid_ = 0;
   hasPyramid_ = 0;
   wx_ = 0;
   wy_ = 0;
   bpp_ = 1;
   n_levels_ = 0;
   ratio_ = 0;
   type_ = 0;
}

BgImagePyramid::~BgImagePyramid()
{
   ClearData();
}

int BgImagePyramid::BuildPyramid(BgImage& image, int n_levels, int ratio, int type, int f_size)
{
   int bpp=1;
   if (image.colorIm_)
      bpp = 3;

   Resize(image.GetWidth(), image.GetHeight(), bpp, n_levels, ratio);

   type_ = type;

   int c_level;
   int c_idx, pn_idx, c_x, c_y, w_y, w_x, hf_size_b_wy, hratio, w_x_b_wy, p_ratio;
   int wx, wy;
   wx = wx_[0];
   wy = wy_[0];
   unsigned char* pimage;
   pimage = image.im_;

   // create filters
   int hf_size = (f_size-1)/2;
   f_size = 2*hf_size+1;

   double *s_filt;
   s_filt = new double[f_size];

   switch (type_)
   {
   case 0:
   case 1:
   case 4:
      gauss_filters(s_filt, hf_size);
      break;
   case 2:
   case 3:
   case 5:
      binomial_filters(s_filt, hf_size);
      break;
   }

   // copy image base
   // !!! image is organized by columns in the pyramid and by rows in BgImage
   if (bpp_ == 1)
   {
      c_idx = 0;
      for (c_y=0; c_y<wy; c_y++)
      {
         for (c_x=0; c_x<wx; c_x++)
         {
            pyramid_[c_y+c_x*wy] = pimage[c_idx++]/256.0;
         }
      }
   } else if (bpp_ == 3)
   {
      c_idx = 0;
      for (c_y=0; c_y<wy; c_y++)
      {
         for (c_x=0; c_x<wx; c_x++)
         {
            pn_idx = 3*(c_y+c_x*wy);
            pyramid_[pn_idx+0] = pimage[c_idx++]/256.0;
            pyramid_[pn_idx+1] = pimage[c_idx++]/256.0;
            pyramid_[pn_idx+2] = pimage[c_idx++]/256.0;
         }
      }
   } else
   {
      bgLog("Error, bpp not valid\n");
      exit(0);
   }

   // create the levels
   double *b_image, *f1_image, *f2_image, *p_image;
   f1_image = new double[wx*wy*bpp_]; // temporary filter image 1
   f2_image = new double[wx*wy*bpp_]; // temporary filter image 2

   int b_wx, b_wy, p_wx, p_wy;
   b_wx = wx;
   b_wy = wy;
   double ft_image, whf;
   double ft_image0, ft_image1, ft_image2;
   hratio = ratio/2;
   int nmx_level;
   switch (type_)
   {
   case 4:
   case 5:
      nmx_level = n_levels+1;
      break;
   default:
      nmx_level = n_levels;
      break;
   }
   
   int idx_base, idx_top;
   idx_base = 0;
   idx_top = wx*wy;

   if (bpp_ == 1)
   {
      
      for (c_level = 1; c_level<nmx_level; c_level++)
      {
         b_image = &pyramid_[idx_base];
         
         if (c_level < n_levels)
            p_image = &pyramid_[idx_top];
         else
            p_image = 0;
         
         p_wx = b_wx/ratio;
         p_wy = b_wy/ratio;
         
         idx_base += b_wx*b_wy;
         idx_top += p_wx*p_wy;
         
         // filter on y, result in f1_image
         c_idx = 0;
         for (c_x=0; c_x<b_wx; c_x++)
         {
            // upper border
            for (c_y=0; c_y<hf_size; c_y++)
            {
               ft_image = 0;
               whf = 0;
               for (w_y=-c_y; w_y<=hf_size; w_y++)
               {
                  ft_image += s_filt[w_y+hf_size]*b_image[c_idx+w_y];
                  whf += s_filt[w_y+hf_size];
               }
               f1_image[c_idx] = ft_image/whf;
               c_idx++;
            }
            
            // middle
            for (; c_y<(b_wy-hf_size); c_y++)
            {
               ft_image = 0;
               for (w_y=-hf_size; w_y<=hf_size; w_y++)
               {
                  ft_image += s_filt[w_y+hf_size]*b_image[c_idx+w_y];
               }
               f1_image[c_idx] = ft_image;
               c_idx++;
            }
            
            // lower border
            for (; c_y<b_wy; c_y++)
            {
               ft_image = 0;
               whf = 0;
               for (w_y=-hf_size; w_y<(b_wy-c_y); w_y++)
               {
                  ft_image += s_filt[w_y+hf_size]*b_image[c_idx+w_y];
                  whf += s_filt[w_y+hf_size];
               }
               f1_image[c_idx] = ft_image/whf;
               c_idx++;
            }
         }
         
         hf_size_b_wy = hf_size*b_wy;
         // filter on x, result in f2_image
         for (c_y=0; c_y<b_wy; c_y++)
         {
            c_idx = c_y;
            // left border
            for (c_x=0; c_x<hf_size; c_x++)
            {
               ft_image = 0;
               whf = 0;
               w_x_b_wy = -c_x*b_wy;
               for (w_x=-c_x; w_x<=hf_size; w_x++, w_x_b_wy+=b_wy)
               {
                  ft_image += s_filt[w_x+hf_size]*f1_image[c_idx+w_x_b_wy];
                  whf += s_filt[w_x+hf_size];
               }
               f2_image[c_idx] = ft_image/whf;
               c_idx+=b_wy;
            }
            
            // middle
            for (; c_x<(b_wx-hf_size); c_x++)
            {
               ft_image = 0;
               w_x_b_wy = -hf_size_b_wy;
               for (w_x=-hf_size; w_x<=hf_size; w_x++, w_x_b_wy+=b_wy)
               {
                  ft_image += s_filt[w_x+hf_size]*f1_image[c_idx+w_x_b_wy];
               }
               f2_image[c_idx] = ft_image;
               c_idx+=b_wy;
            }
            
            // lower border
            for (; c_x<b_wx; c_x++)
            {
               ft_image = 0;
               whf = 0;
               w_x_b_wy = -hf_size_b_wy;
               for (w_x=-hf_size; w_x<(b_wx-c_x); w_x++, w_x_b_wy+=b_wy)
               {
                  ft_image += s_filt[w_x+hf_size]*f1_image[c_idx+w_x_b_wy];
                  whf += s_filt[w_x+hf_size];
               }
               f2_image[c_idx] = ft_image/whf;
               c_idx+=b_wy;
            }
         }
         
         // compute the upper pyramid level by subsampling the filtered image
         if (c_level < n_levels)
         {
            pn_idx = 0;
            c_idx = hratio;
            p_ratio = (ratio-1)*b_wy;
            for (c_x=0; c_x<p_wx; c_x++)
            {
               for (c_y=0; c_y<p_wy; c_y++)
               {
                  p_image[pn_idx] = f2_image[c_idx];
                  pn_idx++;
                  c_idx+=ratio;
               }
               c_idx += p_ratio;
            }
         }
         
         // if laplacian replace current image by the difference
         if ((type_ == 1) || (type_ == 3) || (type_ == 4) || (type_==5))
         {
            for (c_idx=0; c_idx<(b_wx*b_wy); c_idx++)
            {
               b_image[c_idx] -= f2_image[c_idx];
            }
         }
         
         b_wx /= ratio;
         b_wy /= ratio;
      }
   } else
   {
      // color images
      idx_top = 3*wx*wy;
      
      for (c_level = 1; c_level<nmx_level; c_level++)
      {
         b_image = &pyramid_[idx_base];
         
         if (c_level < n_levels)
            p_image = &pyramid_[idx_top];
         else
            p_image = 0;
         
         p_wx = b_wx/ratio;
         p_wy = b_wy/ratio;
         
         idx_base += 3*b_wx*b_wy;
         idx_top += 3*p_wx*p_wy;
         
         // filter on y, result in f1_image
         c_idx = 0;
         for (c_x=0; c_x<b_wx; c_x++)
         {
            // upper border
            for (c_y=0; c_y<hf_size; c_y++)
            {
               ft_image0 = ft_image1 = ft_image2 = 0;
               whf = 0;
               for (w_y=-c_y; w_y<=hf_size; w_y++)
               {
                  ft_image0 += s_filt[w_y+hf_size]*b_image[3*(c_idx+w_y)+0];
                  ft_image1 += s_filt[w_y+hf_size]*b_image[3*(c_idx+w_y)+1];
                  ft_image2 += s_filt[w_y+hf_size]*b_image[3*(c_idx+w_y)+2];
                  whf += s_filt[w_y+hf_size];
               }
               f1_image[3*c_idx+0] = ft_image0/whf;
               f1_image[3*c_idx+1] = ft_image1/whf;
               f1_image[3*c_idx+2] = ft_image2/whf;
               c_idx++;
            }
            
            // middle
            for (; c_y<(b_wy-hf_size); c_y++)
            {
               ft_image0 = ft_image1 = ft_image2 = 0;
               for (w_y=-hf_size; w_y<=hf_size; w_y++)
               {
                  ft_image0 += s_filt[w_y+hf_size]*b_image[3*(c_idx+w_y)+0];
                  ft_image1 += s_filt[w_y+hf_size]*b_image[3*(c_idx+w_y)+1];
                  ft_image2 += s_filt[w_y+hf_size]*b_image[3*(c_idx+w_y)+2];
               }
               f1_image[3*c_idx+0] = ft_image0;
               f1_image[3*c_idx+1] = ft_image1;
               f1_image[3*c_idx+2] = ft_image2;
               c_idx++;
            }
            
            // lower border
            for (; c_y<b_wy; c_y++)
            {
               ft_image0 = ft_image1 = ft_image2 = 0;
               whf = 0;
               for (w_y=-hf_size; w_y<(b_wy-c_y); w_y++)
               {
                  ft_image0 += s_filt[w_y+hf_size]*b_image[3*(c_idx+w_y)+0];
                  ft_image1 += s_filt[w_y+hf_size]*b_image[3*(c_idx+w_y)+1];
                  ft_image2 += s_filt[w_y+hf_size]*b_image[3*(c_idx+w_y)+2];
                  whf += s_filt[w_y+hf_size];
               }
               f1_image[3*c_idx+0] = ft_image0/whf;
               f1_image[3*c_idx+1] = ft_image1/whf;
               f1_image[3*c_idx+2] = ft_image2/whf;
               c_idx++;
            }
         }
         
         hf_size_b_wy = hf_size*b_wy;
         // filter on x, result in f2_image
         for (c_y=0; c_y<b_wy; c_y++)
         {
            c_idx = c_y;
            // left border
            for (c_x=0; c_x<hf_size; c_x++)
            {
               ft_image0 = ft_image1 = ft_image2 = 0;
               whf = 0;
               w_x_b_wy = -c_x*b_wy;
               for (w_x=-c_x; w_x<=hf_size; w_x++, w_x_b_wy+=b_wy)
               {
                  ft_image0 += s_filt[w_x+hf_size]*f1_image[3*(c_idx+w_x_b_wy)+0];
                  ft_image1 += s_filt[w_x+hf_size]*f1_image[3*(c_idx+w_x_b_wy)+1];
                  ft_image2 += s_filt[w_x+hf_size]*f1_image[3*(c_idx+w_x_b_wy)+2];
                  whf += s_filt[w_x+hf_size];
               }
               f2_image[3*c_idx+0] = ft_image0/whf;
               f2_image[3*c_idx+1] = ft_image1/whf;
               f2_image[3*c_idx+2] = ft_image2/whf;
               c_idx+=b_wy;
            }
            
            // middle
            for (; c_x<(b_wx-hf_size); c_x++)
            {
               ft_image0 = ft_image1 = ft_image2 = 0;
               w_x_b_wy = -hf_size_b_wy;
               for (w_x=-hf_size; w_x<=hf_size; w_x++, w_x_b_wy+=b_wy)
               {
                  ft_image0 += s_filt[w_x+hf_size]*f1_image[3*(c_idx+w_x_b_wy)+0];
                  ft_image1 += s_filt[w_x+hf_size]*f1_image[3*(c_idx+w_x_b_wy)+1];
                  ft_image2 += s_filt[w_x+hf_size]*f1_image[3*(c_idx+w_x_b_wy)+2];
               }
               f2_image[3*c_idx+0] = ft_image0;
               f2_image[3*c_idx+1] = ft_image1;
               f2_image[3*c_idx+2] = ft_image2;
               c_idx+=b_wy;
            }
            
            // lower border
            for (; c_x<b_wx; c_x++)
            {
               ft_image0 = ft_image1 = ft_image2 = 0;
               whf = 0;
               w_x_b_wy = -hf_size_b_wy;
               for (w_x=-hf_size; w_x<(b_wx-c_x); w_x++, w_x_b_wy+=b_wy)
               {
                  ft_image0 += s_filt[w_x+hf_size]*f1_image[3*(c_idx+w_x_b_wy)+0];
                  ft_image1 += s_filt[w_x+hf_size]*f1_image[3*(c_idx+w_x_b_wy)+1];
                  ft_image2 += s_filt[w_x+hf_size]*f1_image[3*(c_idx+w_x_b_wy)+2];
                  whf += s_filt[w_x+hf_size];
               }
               f2_image[3*c_idx+0] = ft_image0/whf;
               f2_image[3*c_idx+1] = ft_image1/whf;
               f2_image[3*c_idx+2] = ft_image2/whf;
               c_idx+=b_wy;
            }
         }
         
         // compute the upper pyramid level by subsampling the filtered image
         if (c_level < n_levels)
         {
            pn_idx = 0;
            c_idx = hratio;
            p_ratio = (ratio-1)*b_wy;
            for (c_x=0; c_x<p_wx; c_x++)
            {
               for (c_y=0; c_y<p_wy; c_y++)
               {
                  p_image[3*pn_idx+0] = f2_image[3*c_idx+0];
                  p_image[3*pn_idx+1] = f2_image[3*c_idx+1];
                  p_image[3*pn_idx+2] = f2_image[3*c_idx+2];
                  pn_idx++;
                  c_idx+=ratio;
               }
               c_idx += p_ratio;
            }
         }
         
         // if laplacian replace current image by the difference
         if ((type_ == 1) || (type_ == 3) || (type_ == 4) || (type_==5))
         {
            for (c_idx=0; c_idx<(3*b_wx*b_wy); c_idx++)
            {
               b_image[c_idx] -= f2_image[c_idx];
            }
         }
         
         b_wx /= ratio;
         b_wy /= ratio;
      }
   }

   delete [] f2_image;
   delete [] f1_image;
   delete [] s_filt;

   return 0;
}


int BgImagePyramid::ClearData()
{
   if (hasPyramid_ == 0)
      return 0;
   delete [] pyramid_;
   delete [] wx_;
   delete [] wy_;
   hasPyramid_ = 0;

   return 0;
}

int BgImagePyramid::Resize(int wx, int wy, int bpp, int n_levels, int ratio)
{
   if (hasPyramid_ == 1)
   {
      if ((n_levels_ == n_levels) && (ratio_ == ratio) && (wx_[0] == wx) && (wy_[0] == wy) && (bpp_ == bpp))
      {
         // same size, no need to alloc or dealloc
         return 0;
      } else
      {
         // different size
         ClearData();
      }
   }

   bpp_ = bpp;
   n_levels_ = n_levels;
   ratio_ = ratio;

   // create pyramid storage
   wx_ = new int[n_levels_];
   wy_ = new int[n_levels_];

   int sz, c_level, c_wx, c_wy;
   double c_ratio;

   sz = 0;

   for (c_level = 0; c_level<n_levels_; c_level++)
   {
      c_ratio = pow(ratio_, c_level);
      c_wx = (int) (wx/c_ratio);
      c_wy = (int) (wy/c_ratio);
      wx_[c_level] = c_wx;
      wy_[c_level] = c_wy;
      sz += c_wx*c_wy;
   }
   
   sz *= bpp_;

   pyramid_ = new double[sz];
   hasPyramid_ = 1;

   return 0;
}

void BgImagePyramid::binomial_filters(double* smofil, int WL)
{
   int i;
   double w;
   for (i=-WL; i<=WL; i++)
   {
      w = pow(2,(-2*WL))*factorial(2*WL)/(factorial(WL-i)*factorial(WL+i));
      smofil[i+WL] = w;
   }
}

void BgImagePyramid::gauss_filters(double* smofil, int WL)
{
   int WL2 = 2*WL+1;
   double sigma2 = -(WL2*WL2)/log(BG_IP_GAUSS_TAIL);
   double sumv;
   int i;
   sumv = 0;
   for (i=-WL; i<=WL; i++)
      sumv += smofil[i+WL] = exp(- (i*i)/sigma2);
   for (i=0; i<WL2; i++)
      smofil[i] /= sumv;
}

double BgImagePyramid::factorial(double num)
{
   int i;
   double fnum = 1;
   for (i=2; i<=num; i++)
      fnum *= i;
   return fnum;
}
