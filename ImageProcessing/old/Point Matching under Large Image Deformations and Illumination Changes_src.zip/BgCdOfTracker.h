/////////////////////////////////////////////////////////////////////////////
// Name:        BgCdOfTracker.h
// Purpose:     BgCdOfTracker class
// Author:      Bogdan Georgescu
// Modified by:
// Created:     11/14/2002
// Copyright:   (c) Bogdan Georgescu
// Version:     v0.1
/////////////////////////////////////////////////////////////////////////////

#ifndef _BG_CDOFTRACKER_H
#define _BG_CDOFTRACKER_H

#include "BgImagePyramid.h"
#include "BgPoints2D.h"
#include "BgFilterFactory.h"
#include "BgImageProcessing.h"

#define BG_CDOF_DEFAULT_IM0 0
#define BG_CDOF_DEFAULT_IM1 1

#define BG_CDOF_NOZEROMEAN
#define BG_CDOF_PIRAMID_ALIGN

#define BG_CDOF_BLEND 0.3

#define BG_CDOF_LAMBDA_LM 0.001

#define BG_CDOF_GAUSS_TAIL 0.01

// defaults
#define BG_CDOF_PLEVELS 3
#define BG_CDOF_PRATIO 2
#define BG_CDOF_PFSIZE 11
#define BG_CDOF_DT 25
#define BG_CDOF_DELTAGS 25
#define BG_CDOF_MAXTRIAL 25
#define BG_CDOF_MINNORM 0.005
#define BG_CDOF_USEBW 0
#define BG_CDOF_NBWTRIALS 3
#define BG_CDOF_SIGMAOF 0.2
#define BG_CDOF_SIGMACDP 0.4
#define BG_CDOF_SIGMACDM 0.2
#define BG_CDOF_USETR 1
#define BG_CDOF_USER1 1
#define BG_CDOF_USER2 1
#define BG_CDOF_USESC 1
#define BG_CDOF_USEPR 1
#define BG_CDOF_USECSC 1
#define BG_CDOF_RATIOOF 1.0
#define BG_CDOF_RATIOCD 1.0
#define BG_CDOF_PTYPE 0
#define BG_CDOF_TBLEND 0.01
#define BG_CDOF_SEARCHTYPE 1
#define BG_CDOF_NBINS 16
#define BG_CDOF_NKERNELS 5 //max 5

#define BG_CDOF_BESTGRIDTOPN 5

#define BG_SQRT3 1.7320508

#define BG_MULTIPLE_EXP
#define GPT_INTERPOLATED
//#define BG_DEBUG_GPTRMSRSCL
//#define BGOFT_USEEPANECHK
//#define BG_USEGRAY

// if it is defined saves the points
#define BGCDOF_SAVELR
//#define CDOF_TEST_COV


class BgCdOfTracker
{
public:
   BgCdOfTracker();
   ~BgCdOfTracker();

   int MainMatch(BgImage* im0, BgImage* im1, BgPoints2D* pt0, BgPoints2D* pt1, double* score=0);

   void SetParameters(int pyrLevels, int pyrRatio, int pyrFSize, int pyramidType,
      int dt, double normLimit, int maxNTrial,
      int useBiweight, int nBwTrials, double bwSigmaOF, double bwSigmaCDP, double bwSigmaCDM,
      double l_blend,
      double ratioOF, double ratioCD, int deltaGS,
      int algUseTr, int algUseRot1, int algUseRot2, int algUseScale, int algUseProj, int algUseCScale,
      int searchType, int nBins);

   int InitImPiramid();

   int GMatchPoints(double* l_pt, int n_pt, double* r_pt,
                    double* score, double* params, double* r_cov=0);

   void ClearPiramids();

   int pyramidType_;
   // left image piramid
   BgImagePyramid pyramidL_;

   // right image piramid
   BgImagePyramid pyramidR_;

   // control
   int oprint_;

   // internal algorithm parameters
   int deltaGS_; // grid search step
   int searchType_; // how the point is searched in the other image
                    // 0 one time starting from the initial position in ptout
                    // 1 best grid search
                    // 2 full grid search
                    // n>10 using a grid search around the initial position of max +/- n

   int pyrLevels_ ; // no of pyramid levels
   int pyrRatio_  ; // ratio between pyramid levels
   int pyrFSize_  ; // filter size for pyramid building

   int dt_ ; // base window size for matching
   int maxNTrial_; // max iterations of alg
   double normLimit_; // limit of update step size

   int useBiweight_ ; // use biweight estimator
   int nBwTrials_; // number of M-estimator steps
   double bwSigmaOF_; // sigma for optical flow
   double bwSigmaCDP_; // sigma for CD plus
   double bwSigmaCDM_; // sigma for CD minus

   int algUseTr_; // use translation
   int algUseRot1_; // use rotation 1
   int algUseRot2_; // use rotation 2
   int algUseScale_; // use scaling
   int algUseProj_; // use projective
   int algUseCScale_; // use illumination scale change

   int nBins_; // number of bins per color component

   // ratio of/cd
   double ratioOF_;
   double ratioCD_;

   // tracking blend
   double l_blend_;

   int fullsave_;
};

#endif
