/////////////////////////////////////////////////////////////////////////////
// Name:        BgPoints2D.cpp
// Purpose:     BgPoints2D class functions
// Author:      Bogdan Georgescu
// Modified by:
// Created:     06/22/2000
// Copyright:   (c) Bogdan Georgescu
// Version:     v0.1
/////////////////////////////////////////////////////////////////////////////
#include "BgPoints2D.h"


BgPoints2D::BgPoints2D()
{
   x_ = y_ = 0;
   n_ = 0;
}

BgPoints2D::~BgPoints2D()
{
   CleanData();
}

void BgPoints2D::CleanData()
{
   if (n_ > 0)
   {
      delete [] x_;
      delete [] y_;
      x_ = y_ = 0;
      n_ = 0;
   }
}

void BgPoints2D::Resize(int n)
{
   if (n_ != n)
      CleanData();
   n_ = n;
   x_ = new double[n_];
   y_ = new double[n_];
}

void BgPoints2D::SetPoints(int* x, int* y, int n)
{
   CleanData();
   n_ = n;
   x_ = new double[n_];
   y_ = new double[n_];
   for (int i=0; i<n; i++)
   {
      x_[i] = x[i];
      y_[i] = y[i];
   }
}

void BgPoints2D::SetPoints(double* x, double* y, int n)
{
   CleanData();
   n_ = n;
   x_ = new double[n_];
   y_ = new double[n_];
   for (int i=0; i<n; i++)
   {
      x_[i] = x[i];
      y_[i] = y[i];
   }
}

//very expensive
void BgPoints2D::AddPoints(double* x, double* y, int n)
{
   if (n<=0)
      return;
   double *tempx, *tempy;
   int nn;
   nn = n_+n;
   tempx = new double[nn];
   tempy = new double[nn];
   memcpy(tempx, x_, n_*sizeof(double));
   memcpy(tempy, y_, n_*sizeof(double));
   memcpy(&tempx[n_], x, n*sizeof(double));
   memcpy(&tempy[n_], y, n*sizeof(double));
   CleanData();
   n_ = nn;
   x_ = tempx;
   y_ = tempy;
}

//very expensive
void BgPoints2D::AddPoints(BgPoints2D& p2d)
{
   AddPoints(p2d.x_, p2d.y_, p2d.n_);
}


void BgPoints2D::SetPoints(double* pin, int n)
{
   CleanData();
   n_ = n;
   x_ = new double[n_]; 
   y_ = new double[n_];
   for (int i=0; i<n; i++)
   {
      x_[i] = pin[2*i+0];
      y_[i] = pin[2*i+1];
   }
}

void BgPoints2D::GetPoints(double* pout)
{
   for (int i=0; i<n_; i++)
   {
      pout[2*i+0] = x_[i];
      pout[2*i+1] = y_[i];
   }
}

void BgPoints2D::SetPoints(float* x, float* y, int n)
{
   CleanData();
   n_ = n;
   x_ = new double[n_];
   y_ = new double[n_];
   for (int i=0; i<n; i++)
   {
      x_[i] = x[i];
      y_[i] = y[i];
   }
}

void BgPoints2D::SetHomogPoints(double* p2d, int n)
{
   CleanData();
   n_ = n;
   x_ = new double[n_];
   y_ = new double[n_];
   for (int i=0; i<n; i++)
   {
      x_[i] = p2d[3*i+0];
      y_[i] = p2d[3*i+1];
   }
}

void BgPoints2D::InverseYValues(double val)
{
   for (int i=0; i<n_; i++)
   {
      y_[i] = val-y_[i];
   }
}

void BgPoints2D::InverseXValues(double val)
{
   for (int i=0; i<n_; i++)
   {
      x_[i] = val-x_[i];
   }
}

void BgPoints2D::Read(const char* filename)
{
   FILE* fd;
   fd = fopen(filename,"rb");
   Read(fd);
   fclose(fd);
}

void BgPoints2D::Write(const char* filename, int bin_wr)
{
   FILE* fd;
   fd = fopen(filename,"wb");
   Write(fd, bin_wr);
   fclose(fd);
}

void BgPoints2D::Read(FILE* fd)
{
   CleanData();
   char s[100];
   fscanf(fd, "%s", s);
   if ((strcmp(s, "BgPoints2D") != 0) && (strcmp(s,"BgPoints2DB") != 0)) {
      bgLog("BgPoints2D::Read: file doesn't start with BgPoints2D or BgPoints2DB.\n");
      return;
   }
   int type = 0;
   if (strcmp(s,"BgPoints2DB") == 0)
      type = 1;
   fgets(s,50,fd);
   fgets(s, 50, fd);
   int length;
   sscanf(s, "%d", &length);
   //fscanf(fd, "%d", &length);
   if (length<=0)
   {
      bgLog("error reading p2d file\n");
      return;
   }
   
   n_ = length;
   x_ = new double[n_];
   y_ = new double[n_];
   float x, y;
   int i;
   if (type == 0)
   {
      for (i=0; i<n_; i++)
      {
         fscanf(fd, "%f %f", &x, &y);
         x_[i] = x;
         y_[i] = y;
      }
   } else
   {
      // binary
      fread(x_, sizeof(double), length, fd);
      fread(y_, sizeof(double), length, fd);
   }
}

void BgPoints2D::Write(FILE* fd, int bin_wr)
{
   if (bin_wr == 0)
   {
      fprintf(fd, "BgPoints2D\n%d\n", n_);
      int i;
      for (i=0; i<n_; i++)
      {
         fprintf(fd, "%f %f\n", x_[i], y_[i]);
      }
   } else
   {
      fprintf(fd, "BgPoints2DB\n%d\n", n_);
      fwrite(x_, sizeof(double), n_, fd);
      fwrite(y_, sizeof(double), n_, fd);
      fprintf(fd, "\n");
   }
}
