/////////////////////////////////////////////////////////////////////////////
// Name:        CDOFMatch.h
// Purpose:     Color Distribution/Optical Flow Matcher
// Author:      Bogdan Georgescu
// Modified by:
// Created:     09/01/2003
// Copyright:   (c) Bogdan Georgescu
// Version:     v0.1
/////////////////////////////////////////////////////////////////////////////

#include <wx/toolbar.h>
#include <wx/image.h>
#include <wx/bitmap.h>
#include <wx/splitter.h>
#include <wx/textfile.h>
#include <wx/textctrl.h>
#include <wx/log.h>
#include <wx/proplist.h>
#include <wx/treectrl.h>
#include <wx/spinctrl.h>
#include <wx/progdlg.h>

#define MAX_POINT_SET 100
#define MAX_LINE_SET 100

// left panel sizes
#define SEQ_PANEL_SIZE_X 250
#define SEQ_BPANEL_SIZE_Y 150
#define SEQ_APANEL_SIZE_Y 200
#define SEQ_TPANEL_POZ_Y 45
#define SEQ_APPANEL_POZ_Y 45

#define BG_HAR_BORDER 10

// log everything to a text window (GUI only of course)
class bgLogTextCtrl : public wxLog
{
public:
    bgLogTextCtrl(wxTextCtrl *pTextCtrl);

private:
    // implement sink function
    virtual void DoLogString(const wxChar *szString, time_t t);

    // the control we use
    wxTextCtrl *m_pTextCtrl;
};

// Define a new application
class BgApp : public wxApp
{
public:
   bool OnInit();
};


struct BgPointStyle
{
   wxPen pen_;
   int type_;
};

struct BgLineStyle
{
   wxPen pen_;
   int type_;
};


class BgImageCanvas:public wxScrolledWindow
{
public:
   BgImageCanvas(wxWindow *parent, const wxPoint& pos, const wxSize& size);
   ~BgImageCanvas();
   void OnDraw(wxDC& dc);
   bool IsDirty() const { return m_dirty; }

   int vimg_;
   
   wxBitmap *pbitmap_;
   wxImage *pimage_;
   bool hasbitmap_;
   bool showbitmap_;
   int overDraw_;
   BgPoints2D* pointSet_[MAX_POINT_SET];
   int nPointSets_;
   int pointSetStyle_[MAX_POINT_SET];

   BgPoints2D mouseLClick_;

   BgPoints2D* lineSet_[MAX_LINE_SET];
   int nLineSets_;
   int lineSetStyle_[MAX_LINE_SET];

   void AddPointSet(BgPoints2D* p2d, int style = 0);
   void RemovePointSet(BgPoints2D* p2d);

   void AddLineSet(BgPoints2D* p2d, int style = 0);
   void RemoveLineSet(BgPoints2D* p2d);

   int SetImage(wxString imname);
   void SetImage(wxImage& image);
   void SetSameImage(wxImage& image);
   void SetImageFromGray(unsigned char* data, int w, int h);

   void OnMouseLClick(wxMouseEvent& event);
   void ShowMouseClick(bool show);
   int showMouseClick_;
   int haveMouseClick_;

   void ClearData();

private:
   bool m_dirty;
   void InitStyles();
   BgPointStyle pstyle_[10];
   BgLineStyle lstyle_[10];

   
   DECLARE_EVENT_TABLE()
};

// Define a new frame
class BgMdiFrame : public wxMDIParentFrame
{
public:
   wxToolBar* toolbar_;
    wxTextCtrl    *logtext_;
    wxLog *logTargetOld_;
    int logsize_;
   bgLogTextCtrl* bglogctrl_;
   
   BgMdiFrame(wxWindow *parent, const wxWindowID id, const wxString& title,
      const wxPoint& pos, const wxSize& size, const long style);
   
   void InitToolBar(wxToolBar* toolBar);

   void OnSize(wxSizeEvent&);
   void OnAbout(wxCommandEvent&);
   void OnNewImageWindow(wxCommandEvent&);
   void OnNewImMatchWindow(wxCommandEvent&);
   void OnLoadImage(wxCommandEvent& event);
   void OnQuit(wxCommandEvent&);
   void OnClose(wxCloseEvent&);

   DECLARE_EVENT_TABLE()
};

class BgMdiImChild : public wxMDIChildFrame
{
public:
   BgImageCanvas* canvas;
   BgMdiImChild(wxMDIParentFrame *parent, const wxString& title, const wxPoint& pos, const wxSize& size, const long style);
   ~BgMdiImChild();
   
   void OnActivate(wxActivateEvent& );
   
   void OnRefresh(wxCommandEvent& );
   void OnChangeTitle(wxCommandEvent& );
   void OnQuit(wxCommandEvent& );
   void OnClose(wxCloseEvent& );
   void OnLoadImage(wxCommandEvent& );

   DECLARE_EVENT_TABLE()
};

class BgMdiImMatchingChild: public wxMDIChildFrame
{
public:
   // main canvas
   BgImageCanvas* leftCanvas_;

   // secondary canvas
   BgImageCanvas* rightCanvas_;

   // splitter stuff
   wxSplitterWindow* canvasSplitter_;

   int addPointsCheck_;
   // left image
   BgImage bglimage_;
   BgPoints2D limpoints_;
   char limname_[100];
   int hasLImage_;
   BgPoints2D limselpoints_;

   // right image
   BgImage bgrimage_;
   BgPoints2D rimpoints_;
   char rimname_[100];
   int hasRImage_;
   BgPoints2D rimselpoints_;
   BgPoints2D rimpointsscores_;

   // left panel stuff
   // buttons
   wxPanel* buttonPanel_;

   wxButton* buttonLLImage_;
   wxButton* buttonLRImage_;

   //wxBitmapButton* buttonLLImage_;
   //wxBitmap* buttonLLImageBmp_;
   //wxBitmapButton* buttonRLImage_;
   //wxBitmap* buttonRLImageBmp_;

   // tree control with corners
   wxTreeCtrl* seqTreeCtrl_;
   wxTreeItemId seqRootAllId_;
   wxTreeItemId seqLeftCornId_;

   // algorithm panel
   wxPanel* algorithmPanel_;
   wxChoice* algorithmChoice_;
   wxStaticText* labelChoice_;
   wxButton* algorithmRunButton_;

   // property panel
   wxPropertyListPanel* propListPanel_;
   wxPropertyListView* propListView_;
   wxPropertyValidatorRegistry listValidatorRegistry_;
   wxPropertySheet* cornerPropSheet_;
   wxPropertySheet* cdofSheet_;

   // corner propery values 
   wxProperty* pcornFilterSize_;
   wxProperty* pcornVecinitySize_;
   wxProperty* pcornPercentSelect_;
   wxProperty* pcornBorder_;

   // color distribution/optical flow params
   wxProperty* pcdofpyrLevels_ ; //int
   wxProperty* pcdofpyrRatio_  ; //int
   wxProperty* pcdofpyrFSize_  ; //int
   wxProperty* pcdofpyrType_   ; //string
   wxStringList* pSearchTypeString_;
   wxProperty* pcdofsearchType_; //int
   wxProperty* pcdofdt_ ; //int
   wxProperty* pcdofmaxNTrial_; //int
   wxProperty* pcdofnormLimit_; //double
   wxProperty* pcdofuseBiweight_ ; //int
   wxProperty* pcdofnBwTrials_; //int
   wxProperty* pcdofbwSigmaOF_; //double
   wxProperty* pcdofbwSigmaCDP_; //double
   wxProperty* pcdofbwSigmaCDM_; //double
   wxProperty* pcdofalgUseTr_; //int
   wxProperty* pcdofalgUseRot1_; //int
   wxProperty* pcdofalgUseRot2_; //int
   wxProperty* pcdofalgUseScale_; //int
   wxProperty* pcdofalgUseProj_; //int
   wxProperty* pcdofalgUseCScale_; //int
   wxProperty* pcdofratioOF_; // double
   wxProperty* pcdofratioCD_; // double
   wxProperty* pcdofdeltaGS_; // int
   wxProperty* pcdoflblend_; // double
   wxProperty* pcdofnbins_; // int
   wxProperty* pcdofsave_; // int

   BgMdiImMatchingChild(wxMDIParentFrame *parent, const wxString& title, const wxPoint& pos, const wxSize& size, const long style);
   ~BgMdiImMatchingChild();

   
   // internal methods
   void ClearData();
   void OnSize(wxSizeEvent& );
   void OnRefresh(wxCommandEvent& );
   void OnQuit(wxCommandEvent& );
   void OnClose(wxCloseEvent& );

   void OnTreeFrameClick(wxTreeEvent& treevent);
   void OnTreeFrameSelect(wxTreeEvent& treevent);
   void ResetPointsTree();
   void OnRemoveAllPoints(wxCommandEvent& );
   void OnAddPointsCheck(wxCommandEvent& );
   void OnAddCanvasPoint(wxCommandEvent& );

   // algorithm choice/params methods
   void OnChoiceAlgorithm(wxCommandEvent& );
   void OnRunAlgorithm(wxCommandEvent& );

   // algorithm apply
   void OnLoadImages(wxCommandEvent& );
   void OnLoadLeftImage(wxCommandEvent& );
   void OnLoadRightImage(wxCommandEvent& );
   void OnHarrisCorners(wxCommandEvent& );
   void OnCDOFMatching(wxCommandEvent& );

   void InitToolBar(wxToolBar*);

   // file data access
   void OnLoadCorners(wxCommandEvent& );
   void OnLoadMatches(wxCommandEvent& );
   void OnSaveCorners(wxCommandEvent& );
   void OnSaveMatches(wxCommandEvent& );

   DECLARE_EVENT_TABLE()
   
};

// menu items ids
enum
{
   BG_QUIT = 100,
   BG_NEW_IMAGE_WINDOW,
   BG_NEW_IMMATCH_WINDOW,
   BG_ABOUT,
   BG_LOAD_IMAGE,
   BG_CHILD_IMAGE_QUIT,
   BG_REFRESH,
   BG_IMMATCH_QUIT,
   BG_IMMATCH_CORNERS,
   BG_IMMATCH_MATCH,
   BG_IMMATCH_LOAD_POINTS,
   BG_IMMATCH_LOAD_MATCHES,
   BG_IMMATCH_SAVE_POINTS,
   BG_IMMATCH_SAVE_MATCHES,
   BG_IMMATCH_RUNALG,
   BG_IMMATCH_ALG_SEL,
   BG_IMMATCH_LOADLIMAGE,
   BG_IMMATCH_LOADRIMAGE,
   BG_IMMATCH_TREE_CLICK,
   BG_IMMATCH_REMOVEALL,
   BG_IMMATCH_ADDPOINTS,
   BG_IMMATCH_ADDCANVASPOINT
};


