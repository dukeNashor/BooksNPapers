/////////////////////////////////////////////////////////////////////////////
// Name:        BgCdOfTracker.cpp
// Purpose:     BgCdOfTracker class functions
// Author:      Bogdan Georgescu
// Modified by:
// Created:     11/14/2002
// Copyright:   (c) Bogdan Georgescu
// Version:     v0.1
/////////////////////////////////////////////////////////////////////////////

#include <math.h>
#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <string.h>

#include "BgDefaults.h"
#include "BgCdOfTracker.h"

BgCdOfTracker::BgCdOfTracker()
{
   pyrLevels_ = BG_CDOF_PLEVELS;
   pyrRatio_ = BG_CDOF_PRATIO;
   pyrFSize_ = BG_CDOF_PFSIZE;
   pyramidType_ = BG_CDOF_PTYPE;

   dt_ = BG_CDOF_DT;
   normLimit_ = BG_CDOF_MINNORM;
   maxNTrial_ = BG_CDOF_MAXTRIAL;
   oprint_ = 0;
   ratioOF_ = BG_CDOF_RATIOOF*BG_CDOF_NKERNELS;
   ratioCD_ = BG_CDOF_RATIOCD;
   deltaGS_ = BG_CDOF_DELTAGS;

   useBiweight_ = BG_CDOF_USEBW;
   nBwTrials_ = BG_CDOF_NBWTRIALS;
   bwSigmaOF_ = BG_CDOF_SIGMAOF;
   bwSigmaCDP_ = BG_CDOF_SIGMACDP;
   bwSigmaCDM_ = BG_CDOF_SIGMACDM;

   algUseTr_ = BG_CDOF_USETR;
   algUseRot1_ = BG_CDOF_USER1;
   algUseRot2_ = BG_CDOF_USER2;
   algUseScale_ = BG_CDOF_USESC;
   algUseProj_ = BG_CDOF_USEPR;
   algUseCScale_ = BG_CDOF_USECSC;

   l_blend_ = BG_CDOF_TBLEND;
   searchType_ = BG_CDOF_SEARCHTYPE;
   
   nBins_ = BG_CDOF_NBINS;
   fullsave_ = 0;
}

BgCdOfTracker::~BgCdOfTracker()
{
   ClearPiramids();
}

void BgCdOfTracker::SetParameters(int pyrLevels, int pyrRatio, int pyrFSize, int pyramidType,
      int dt, double normLimit, int maxNTrial,
      int useBiweight, int nBwTrials, double bwSigmaOF, double bwSigmaCDP, double bwSigmaCDM,
      double l_blend,
      double ratioOF, double ratioCD, int deltaGS,
      int algUseTr, int algUseRot1, int algUseRot2, int algUseScale, int algUseProj, int algUseCScale,
      int searchType, int nBins)
{
   pyrLevels_ = pyrLevels;
   pyrRatio_ = pyrRatio;
   pyrFSize_ = pyrFSize;
   pyramidType_ = pyramidType;

   dt_ = dt;
   normLimit_ = normLimit;
   maxNTrial_ = maxNTrial;
   oprint_ = 0;
   ratioOF_ = ratioOF*BG_CDOF_NKERNELS;
   ratioCD_ = ratioCD;
   deltaGS_ = deltaGS;

   useBiweight_ = useBiweight;
   nBwTrials_ = nBwTrials;
   bwSigmaOF_ = bwSigmaOF;
   bwSigmaCDP_ = bwSigmaCDP;
   bwSigmaCDM_ = bwSigmaCDM;

   algUseTr_ = algUseTr;
   algUseRot1_ = algUseRot1;
   algUseRot2_ = algUseRot2;
   algUseScale_ = algUseScale;
   algUseProj_ = algUseProj;
   algUseCScale_ = algUseCScale;

   l_blend_ = l_blend;
   searchType_ = searchType;

   nBins_ = nBins;
}

void BgCdOfTracker::ClearPiramids()
{
   pyramidL_.ClearData();
   pyramidR_.ClearData();
}

// match color distribution + optical flow, assumes images that are color
// main matching function!, pyramids already constructed
int BgCdOfTracker::GMatchPoints(double* l_pt, int n_pt, double* r_pt,
                                 double* score, double* params, double* r_cov)
{
   // l_pt in left points
   // n_pt in number of points
   // r_pt out right points
   // output score for each and rotations
   // does a search at the high level

   // search grid
   int grid_search;
   double best_score;
   double best_params[7]; // hx, hy, angle 1, angle 2, v0, v1 (inf. plane), csc: color shift
                          // hx and hy are absolute 
   double best_location[2];
   double *d_params;

   double best_grid_scores[BG_CDOF_BESTGRIDTOPN];
   double best_grid_params[BG_CDOF_BESTGRIDTOPN*9];
   int ibestgrid;
   double potential_score;

   double *potential_grid_scores;
   double *potential_grid_params;
   int *ipotential_temp;
   int npotential, ipotential;
   npotential = 1+(pyramidL_.wx_[pyrLevels_-1]*pyramidL_.wy_[pyrLevels_-1]/((deltaGS_-1)*(deltaGS_-1)));

   potential_grid_scores = new double[npotential];
   potential_grid_params = new double[2*npotential];
   ipotential_temp = new int[npotential];
   double xr_orig, yr_orig; //always use them




   // start search for each point
   int c_point, c_level;
   double xl, yl; // current point in left
   double xr, yr; // current point in right
   double c_ratio;
   int ixl, iyl;
   int ixr, iyr;
   double dcx_left, dcy_left, dcx_right, dcy_right;
   int ixw, iyw;

   int n_bins, n_bins_color, n_bins_color2;
   int n_kernels;
   int c_kernel, cu_idx, cug_idx;
   int cu_idx0;
#ifndef BG_USEGRAY
   int cu_idx1, cu_idx2;
#endif

   n_kernels = BG_CDOF_NKERNELS;
   n_bins_color = nBins_;
   n_bins_color2 = n_bins_color*n_bins_color;
   n_bins = n_bins_color*n_bins_color*n_bins_color;

#ifdef BG_USEGRAY
   n_bins = n_bins_color2 = n_bins_color;
#endif
   
   // last kernel is for movment, does not count in rotation ! not anymore
   double SigmasI[5][4] = {{1.44, 0, 0, 0.5184}, {0.5184, 0, 0, 1.44}, {0.9792, 0.4608, 0.4608, 0.9792}, {0.9792, -0.4608, -0.4608, 0.9792}, {1.2, 0, 0, 1.2}};
//   double SigmasI[5][4] = {{1.2, 0, 0, 1.2}, {1.44, 0, 0, 0.5184}, {0.5184, 0, 0, 1.44}, {0.9792, 0.4608, 0.4608, 0.9792}, {0.9792, -0.4608, -0.4608, 0.9792}};
   double SLM[5][4];
   double SLMJ[5][4];
   double *SI, *SIJ;

   // add the M-estimator stuff
   double* wghtBw;
   wghtBw = new double[n_bins];
   double ab = 1;
   double ab2 = ab*ab;
   int c_bw_iter;
   int do_bw_iter;
   double c_bwght, u_bw, u_bwsign;
   double bwSigmaOF2;
   bwSigmaOF2 = bwSigmaOF_*bwSigmaOF_;


   double k_value, kx_value0, ky_value0, kx_value1, ky_value1;
   double old_error, old_error2;

   // working data
   BgImageProcessing cbgimp;
   BgFilterFactory cbgff;

   double *Ch_left, *Ch_right;
   double **pu, **qu, **pq_dif, **xGI;

   int i_k, i_i, i_j;
   double i_m;

   int idx_l, idx_r;

   double DH[4];
   double d_angle1, d_angle2;
   double d_v0, d_v1;
   double W[90];
   double Wof[90];
   double vD[9];
   double DeltaTr[2];
   double d_csc;

#ifdef CDOF_TEST_COV
   // covariance
   BgMatrix mW(9,10);
   double *dmW;
   dmW = mW.GetData();
   double Worig[90];
#endif

   int dt = dt_;
   int hratio = (int) pyrRatio_/2;

   double dhx_left, dhx_right; // real window size
   double dhy_left, dhy_right; // real window size
   int ihx_left, ihy_left; // descrete window size
   int ih_max; // descrete window size
   double dh_max;

   double dtemp;
   int idx, xw, yw;
   int c_wxl, c_wyl, c_wxr, c_wyr, c_trial;
   double normMove;
   double *c_iml, *c_imr;
   double mx_w, my_w;
   double mz_w;
   double pmx_w, pmy_w;

   // temp deriv data
   double cos1, sin1, cos2, sin2;
   double alpha1, alpha2, alpha12;
   double alpha1_hx, alpha2_hx, alpha12_hx;
   double dalpha_hx0, dalpha_hx1, dalpha_hx2, dalpha_hx3;
   double alpha1_hy, alpha2_hy, alpha12_hy;
   double dalpha_hy0, dalpha_hy1, dalpha_hy2, dalpha_hy3;
   double dalpha_a10, dalpha_a11, dalpha_a12, dalpha_a13;
   double alpha1_a2, alpha2_a2, alpha12_a2;
   double dalpha_a20, dalpha_a21, dalpha_a22, dalpha_a23;

   double vI0R, vI0G, vI0B, vI1R, vI1G, vI1B;
   double voI1R, voI1G, voI1B;
   int max_trial;


#ifdef GPT_INTERPOLATED
   double dcu_idx0, dcu_idx1, dcu_idx2;
#ifndef BG_USEGRAY
   double alpha_c[8];

   double aidxR_0, aidxR_1, aidxG_0, aidxG_1, aidxB_0, aidxB_1;
   double alpha_d[8];
#else
   double aidx0;
#endif
   int cc_idx;
   double xderiv0, xderiv1, xderiv2, xderiv3, xderiv4, xderiv5, xderiv6, xderiv7, xderiv8;
#endif

   double c_iwght;
   int W_i, W_c, W_r;
   double *xGIa;
   double o_error;
   int *valid_colors;
   int n_valid_colors, c_valid_color;

   Ch_left = new double[n_kernels];
   Ch_right = new double[n_kernels];

   xGI = new double*[n_kernels];
   pu = new double*[n_kernels];
   qu = new double*[n_kernels];
   pq_dif = new double*[n_kernels];

   valid_colors = new int[n_bins];

   // special timing
   timer_start();

   for (c_kernel = 0; c_kernel<n_kernels; c_kernel++)
   {
      xGI[c_kernel] = new double[9*n_bins];
      pu[c_kernel] = new double[n_bins];
      qu[c_kernel] = new double[n_bins];
      pq_dif[c_kernel] = new double[n_bins];
   }

   int i;

   // precompute sizes for each pyramid level
   int sz_l, sz_r;
   sz_l = sz_r = 0;
   for (c_level=0; c_level<pyrLevels_; c_level++)
   {
      sz_l += pyramidL_.wx_[c_level]*pyramidL_.wy_[c_level];
      sz_r += pyramidR_.wx_[c_level]*pyramidR_.wy_[c_level];
   }

   ihx_left = dt;
   ihy_left = dt;
   dhx_left = dt;
   dhy_left = dt;

   dhx_right = dt;
   dhy_right = dt;

   // the optical flow data
   int dw = 2*dt+1;
   int dw2 = dw*dw;

   double best_ms, best_of;
   double cs_ms, cs_of;

      // image data
   double *wim_left; // left image data
   double *wim_right; // right image data
   wim_left = new double[3*dw2];
   wim_right = new double[3*dw2];

      // gradient image
   double *gimx_right, *gimy_right;
   double *c_gimx_r, *c_gimy_r;
   gimx_right = new double[3*sz_r];
   gimy_right = new double[3*sz_r];
   int rwxya = 0;
   for (c_level = 0; c_level<pyrLevels_; c_level++)
   {
      c_imr = &pyramidR_.pyramid_[3*rwxya];
      c_gimx_r = &gimx_right[3*rwxya];
      c_gimy_r = &gimy_right[3*rwxya];
      cbgimp.GradientFilter(c_imr, pyramidR_.wx_[c_level], pyramidR_.wy_[c_level], c_gimx_r, c_gimy_r, 1, 5);
      rwxya += pyramidR_.wx_[c_level]*pyramidR_.wy_[c_level];
   }

   //bgLog("after grad:");
   //timer_elapsed(0);


   double **xGIof;
   double *xGIofa;
   double *wim_diff;
   xGIof = new double*[3];
   xGIof[0] = new double[9*dw2];
   xGIof[1] = new double[9*dw2];
   xGIof[2] = new double[9*dw2];

   wim_diff = new double[3*dw2];

   double oalpha1, oalpha2, oalpha12;
   double oDH[4];
   double oDH0_hx, oDH1_hx, oDH2_hx, oDH3_hx;
   double oDH0_hy, oDH1_hy, oDH2_hy, oDH3_hy;
   double oDH0_a1, oDH1_a1, oDH2_a1, oDH3_a1;
   double oDH0_a2, oDH1_a2, oDH2_a2, oDH3_a2;
   double dpmx_hx, dpmy_hx, dmx_hx, dmy_hx;
   double dpmx_hy, dpmy_hy, dmx_hy, dmy_hy;
   double dpmx_a1, dpmy_a1, dmx_a1, dmy_a1;
   double dpmx_a2, dpmy_a2, dmx_a2, dmy_a2;
   double gvxR, gvyR, gvxG, gvyG, gvxB, gvyB;
   int wim_idx, wgim_idx, oi_x0, oi_x1, oi_x2, oi_x3;
   double xw_dt, yw_dt;
   double z11, z12, z21, z22;
   double of_error;
   double mxz_w, myz_w, dmx_pmx, dmy_pmx, dmx_pmy, dmy_pmy;
   double mxx_w, myy_w, mxy_w;
   double *wghtBw_of, *of_wght;
   wghtBw_of = new double[dw2];
   of_wght = new double[dw2];
   // init filter
   cbgff.gauss_filters(wghtBw_of, dt);
   idx = 0;
   for (xw=-dt; xw<=dt; xw++)
   {
      for (yw=-dt; yw<=dt; yw++)
      {
         of_wght[idx] = wghtBw_of[yw+dt]*wghtBw_of[xw+dt];
         //of_wght[idx] = 1.0/dw2;
         idx++;
      }
   }

   //bgLog("after init filt:");
   //timer_elapsed(0);

   // elimination eq
   int elimIdx[9];
   int nelim;
   nelim = 0;
   if (algUseTr_ == 0)
   {
      elimIdx[nelim++] = 2; //0
      elimIdx[nelim++] = 3; //1
   }
   if (algUseScale_ == 0)
   {
      elimIdx[nelim++] = 0; //2
      elimIdx[nelim++] = 1; //3
   }
   if (algUseProj_ == 0)
   {
      elimIdx[nelim++] = 6; //4
      elimIdx[nelim++] = 7; //5
   }
   if (algUseRot1_ == 0)
   {
      elimIdx[nelim++] = 4; //6
   }
   if (algUseRot2_ == 0)
   {
      elimIdx[nelim++] = 5; //7
   }
   if (algUseCScale_ == 0)
   {
      elimIdx[nelim++] = 8; //8
   }

   
   //!BG
   int nelimOrig = nelim;
   if (algUseScale_ != 0)
   {
      elimIdx[nelim++] = 0;
      elimIdx[nelim++] = 1;
   }
   if (algUseProj_ != 0)
   {
      elimIdx[nelim++] = 6;
      elimIdx[nelim++] = 7;
   }
   if (algUseRot2_ != 0)
   {
      elimIdx[nelim++] = 5;
   }
   int nelimNew = nelim;


   int *giig;
   giig = new int[n_bins];
   int tmp_idx;

   for (c_point=0; c_point<n_pt; c_point++)
   {
      bgLog("CDOF point: %d\n", c_point);
      d_params = &params[7*c_point];

      // current point
      xl = l_pt[2*c_point];   // left image
      yl = l_pt[2*c_point+1];
      xr = r_pt[2*c_point];//xl;                // right image starting point
      yr = r_pt[2*c_point+1];//yl;

      //bgLog("left: %d, %d; right: %d, %d -->", (int) xl, (int) yl, (int) xr, (int) yr);
      bgLog("left: %d, %d \n", (int) xl, (int) yl);
      
      max_trial = maxNTrial_;

      // adjust coordinates to current pyramid level
      c_ratio = pow(pyrRatio_,pyrLevels_-1);

      for (i=0; i<(pyrLevels_-1); i++)
      {
         xl = (xl-hratio)/pyrRatio_;
         yl = (yl-hratio)/pyrRatio_;
         xr = (xr-hratio)/pyrRatio_;
         yr = (yr-hratio)/pyrRatio_;
      }
      //xl = xl/c_ratio;
      //yl = yl/c_ratio;
      //xr = xr/c_ratio;
      //yr = yr/c_ratio;
      
      // indexes in current pyramid levels
      idx_l = sz_l;
      idx_r = sz_r;

      // for each pyramid level
      for (c_level=pyrLevels_-1; c_level>=0; c_level--)
      {
         idx_l -= pyramidL_.wx_[c_level]*pyramidL_.wy_[c_level];
         idx_r -= pyramidR_.wx_[c_level]*pyramidR_.wy_[c_level];

         if (oprint_ == 1)
            printf("level %d, (xl,yl)=(%g,%g), (xr,yr)=(%g,%g)\n",
            c_level, xl, yl, xr, yr);

         // set initial data values
         c_iml = &pyramidL_.pyramid_[3*idx_l]; // left image pointer
         c_imr = &pyramidR_.pyramid_[3*idx_r]; // right image pointer
         c_gimx_r = &gimx_right[3*idx_r];
         c_gimy_r = &gimy_right[3*idx_r];
         c_ratio = pow(pyrRatio_, c_level);  // current reduction ratio

         c_wxl = pyramidL_.wx_[c_level];          // image sizes for current pyramid levels
         c_wyl = pyramidL_.wy_[c_level];
         c_wxr = pyramidR_.wx_[c_level];
         c_wyr = pyramidR_.wy_[c_level];

         // compute reference distribution (qu) for all kernels
         for (c_kernel = 0; c_kernel<n_kernels; c_kernel++)
         {
            memset(qu[c_kernel], 0, n_bins*sizeof(double));
            Ch_left[c_kernel] = 0;
         }

         for (i=0; i<n_bins; i++)
            giig[i] = 0;

         ixl = (int) (xl+0.5);
         iyl = (int) (yl+0.5);
         dcx_left = xl - ixl;
         dcy_left = yl - iyl;
         for (xw = -ihx_left; xw<= ihx_left; xw++)
         {
            for (yw = -ihy_left; yw<= ihy_left; yw++)
            {
               ixw = ixl+xw;
               iyw = iyl+yw;
               // test if it is in the image
               if ((ixw>=0) && (iyw>=0) && (iyw<c_wyl) && (ixw<c_wxl))
               {
                  tmp_idx = 3*(iyw+ixw*c_wyl);
                  vI0R = c_iml[tmp_idx+0];
                  vI0G = c_iml[tmp_idx+1];
                  vI0B = c_iml[tmp_idx+2];

                  mx_w = (xw+dcx_left)/dhx_left;
                  my_w = (yw+dcy_left)/dhy_left; 
                  mxx_w = mx_w*mx_w;
                  myy_w = my_w*my_w;
                  mxy_w = mx_w*my_w;
#ifndef GPT_INTERPOLATED
#ifndef BG_USEGRAY
                  // not interpolated
                  cu_idx0 = (int) (vI0R*n_bins_color);
                  cu_idx1 = (int) (vI0G*n_bins_color);
                  cu_idx2 = (int) (vI0B*n_bins_color);
                  
                  cu_idx = cu_idx0 + cu_idx1*n_bins_color + cu_idx2*n_bins_color2;

                  giig[cu_idx] = 1;
                  // for each kernel
                  for (c_kernel=0; c_kernel<n_kernels; c_kernel++)
                  {
                     SI = SigmasI[c_kernel];

                     // compute actual kernel values
                     k_value = 1-(SI[0]*mxx_w+SI[2]*mxy_w+SI[1]*mxy_w+SI[3]*myy_w);

                     if (k_value < 0)
                        continue;

                     qu[c_kernel][cu_idx] += k_value;
                     Ch_left[c_kernel] += k_value;
                  }
#else
                  // not interpolated
                  cu_idx0 = (int) (vI0R*n_bins_color);
                  cu_idx1 = (int) (vI0G*n_bins_color);
                  cu_idx2 = (int) (vI0B*n_bins_color);
                  
                  cu_idx = cu_idx0;

                  giig[cu_idx] = 1;
                  // for each kernel
                  for (c_kernel=0; c_kernel<n_kernels; c_kernel++)
                  {
                     SI = SigmasI[c_kernel];

                     // compute actual kernel values
                     k_value = 1-(SI[0]*mxx_w+SI[2]*mxy_w+SI[1]*mxy_w+SI[3]*myy_w);

                     if (k_value < 0)
                        continue;

                     qu[c_kernel][cu_idx] += k_value;
                     Ch_left[c_kernel] += k_value;
                  }
#endif
#else
#ifndef BG_USEGRAY
                  // interpolated
                  dcu_idx0 = (vI0R*(n_bins_color-1));
                  cu_idx0 = (int) dcu_idx0;
                  aidxR_0 = 1-(dcu_idx0-cu_idx0);
                  aidxR_1 = 1-aidxR_0;
                  
                  dcu_idx1 = (vI0G*(n_bins_color-1));
                  cu_idx1 = (int) dcu_idx1;
                  aidxG_0 = 1-(dcu_idx1-cu_idx1);
                  aidxG_1 = 1-aidxG_0;//!-1
                  
                  dcu_idx2 = (vI0B*(n_bins_color-1));
                  cu_idx2 = (int) dcu_idx2;
                  aidxB_0 = 1-(dcu_idx2-cu_idx2);
                  aidxB_1 = 1-aidxB_0;//!-1
                  
                  alpha_c[0] = aidxR_0*aidxG_0*aidxB_0; 
                  alpha_c[1] = aidxR_0*aidxG_0*aidxB_1;
                  alpha_c[2] = aidxR_0*aidxG_1*aidxB_0;
                  alpha_c[3] = aidxR_0*aidxG_1*aidxB_1;
                  alpha_c[4] = aidxR_1*aidxG_0*aidxB_0;
                  alpha_c[5] = aidxR_1*aidxG_0*aidxB_1;
                  alpha_c[6] = aidxR_1*aidxG_1*aidxB_0;
                  alpha_c[7] = aidxR_1*aidxG_1*aidxB_1;

                  cu_idx = cu_idx0 + cu_idx1*n_bins_color + cu_idx2*n_bins_color2;

                  for (c_kernel = 0; c_kernel<n_kernels; c_kernel++)
                  {
                     SI = SigmasI[c_kernel];

                     // compute actual kernel values
                     k_value = 1-(SI[0]*mxx_w+SI[2]*mxy_w+SI[1]*mxy_w+SI[3]*myy_w);

                     if (k_value < 0)
                        continue;

                     Ch_left[c_kernel] += k_value;

                     // add colors
                     cc_idx = cu_idx;
                     giig[cc_idx] = 1;
                     qu[c_kernel][cc_idx] += alpha_c[0]*k_value;

                     // add colors
                     cc_idx = cu_idx+n_bins_color2;
                     giig[cc_idx] = 1;
                     qu[c_kernel][cc_idx] += alpha_c[1]*k_value;

                     // add colors
                     cc_idx = cu_idx+n_bins_color;
                     giig[cc_idx] = 1;
                     qu[c_kernel][cc_idx] += alpha_c[2]*k_value;

                     // add colors
                     cc_idx = cu_idx+n_bins_color2+n_bins_color;
                     giig[cc_idx] = 1;
                     qu[c_kernel][cc_idx] += alpha_c[3]*k_value;

                     // add colors
                     cc_idx = cu_idx+1;
                     giig[cc_idx] = 1;
                     qu[c_kernel][cc_idx] += alpha_c[4]*k_value;

                     // add colors
                     cc_idx = cu_idx+1+n_bins_color2;
                     giig[cc_idx] = 1;
                     qu[c_kernel][cc_idx] += alpha_c[5]*k_value;

                     // add colors
                     cc_idx = cu_idx+1+n_bins_color;
                     giig[cc_idx] = 1;
                     qu[c_kernel][cc_idx] += alpha_c[6]*k_value;

                     // add colors
                     cc_idx = cu_idx+1+n_bins_color2+n_bins_color;
                     giig[cc_idx] = 1;
                     qu[c_kernel][cc_idx] += alpha_c[7]*k_value;
                  }
#else
                  // interpolated, only gray
                  dcu_idx0 = (vI0R*(n_bins_color-1));
                  cu_idx0 = (int) dcu_idx0;
                  aidx0 = 1-(dcu_idx0 - cu_idx0);

                  dcu_idx1 = (vI0G*(n_bins_color-1));

                  dcu_idx2 = (vI0B*(n_bins_color-1));

                  cu_idx = cu_idx0;

                  for (c_kernel = 0; c_kernel<n_kernels; c_kernel++)
                  {
                     SI = SigmasI[c_kernel];

                     // compute actual kernel values
                     k_value = 1-(SI[0]*mxx_w+SI[2]*mxy_w+SI[1]*mxy_w+SI[3]*myy_w);

                     if (k_value < 0)
                        continue;

                     Ch_left[c_kernel] += k_value;

                     // add colors
                     cc_idx = cu_idx;
                     giig[cc_idx] = 1;
                     qu[c_kernel][cc_idx] += aidx0*k_value;

                     // add colors
                     cc_idx = cu_idx+1;
                     giig[cc_idx] = 1;
                     qu[c_kernel][cc_idx] += (1-aidx0)*k_value;
                  }
#endif
#endif

               } else
               {

               }
            }
         }

         n_valid_colors = 0;
         for (i=0; i<n_bins; i++)
         {
            if (giig[i] == 1)
            {
               valid_colors[n_valid_colors++] = i;
            }
         }

         // normalize distribution
         for (cu_idx=0; cu_idx<n_valid_colors; cu_idx++)
         {
            for (c_kernel=0; c_kernel<n_kernels; c_kernel++)
            {
               qu[c_kernel][valid_colors[cu_idx]] = sqrt(qu[c_kernel][valid_colors[cu_idx]]/(Ch_left[c_kernel]));
            }
         }

         //bgLog("after cd diff:");
         //timer_elapsed(0);
 

         // compute reference image patch for optical flow
         for (xw = -ihx_left; xw<= ihx_left; xw++)
         {
            for (yw = -ihy_left; yw<= ihy_left; yw++)
            {
               ixw = ixl+xw;
               iyw = iyl+yw;
               // test if it is in the image
               if ((ixw>=0) && (iyw>=0) && (iyw<c_wyl) && (ixw<c_wxl))
               {
                  tmp_idx = 3*(iyw+ixw*c_wyl);
                  vI0R = c_iml[tmp_idx+0];
                  vI0G = c_iml[tmp_idx+1];
                  vI0B = c_iml[tmp_idx+2];
                  tmp_idx = 3*(yw+ihy_left+(xw+ihx_left)*dw);
                  wim_left[tmp_idx+0] = vI0R;
                  wim_left[tmp_idx+1] = vI0G;
                  wim_left[tmp_idx+2] = vI0B;
               } else
               {
                  tmp_idx = 3*(yw+ihy_left+(xw+ihx_left));
                  wim_left[tmp_idx+0] = BG_CDOF_DEFAULT_IM0;
                  wim_left[tmp_idx+1] = BG_CDOF_DEFAULT_IM0;
                  wim_left[tmp_idx+2] = BG_CDOF_DEFAULT_IM0;
               }
            }
         }

         //bgLog("after of diff:");
         //timer_elapsed(0);

         // start iterate in right image
         grid_search = 0;
         xr_orig = xr;
         yr_orig = yr;
         // if highest level, select search type
         if ((c_level == (pyrLevels_-1)) && (searchType_ > 0))
         {
            //compute the possible grid vals
            xr = deltaGS_;
            yr = deltaGS_;
            npotential = 0;
            while (yr<c_wyr)
            {
               potential_grid_params[2*npotential+0] = xr;
               potential_grid_params[2*npotential+1] = yr;
               xr += deltaGS_;
               if (xr >= c_wxr)
               {
                  yr += deltaGS_;
                  xr = deltaGS_;
               }
               npotential++;
            }
            xr = potential_grid_params[0];
            yr = potential_grid_params[1];
            if (searchType_ == 1)
               grid_search = 1; //while grid_search is 1 only distribution is used
            if (searchType_ == 2)
               grid_search = 2;
            ipotential = 0;
         }
   
         best_score = 1e100;
         
         while (grid_search != -1)
         {
            // current delta transformation (comes from caller)
            d_angle1 = d_params[2];
            d_angle2 = d_params[3];
            dhx_right = dt*d_params[0];
            dhy_right = dt*d_params[1];

            d_v0 = d_params[4];
            d_v1 = d_params[5];

            d_csc = d_params[6];

            DeltaTr[0] = 0;
            DeltaTr[1] = 0;
            
            c_trial = 0;
            normMove = normLimit_+1;
            
            o_error = 1.0;
            old_error2 = 1e100;

            double best_local_score = 10.0;
            
            while((c_trial<max_trial) && (normMove>normLimit_))
            {
               c_trial++;
               
               // deform the neighborhood according to current transformation and compute
               // target distribution pu
               double *pu_ck;
               for (c_kernel=0; c_kernel<n_kernels; c_kernel++)
               {
                  pu_ck = pu[c_kernel];
                  for (cu_idx=0; cu_idx<n_valid_colors; cu_idx++)
                     pu_ck[valid_colors[cu_idx]] = 0;
               }

               for (c_kernel=0; c_kernel<n_kernels; c_kernel++)
                  Ch_right[c_kernel] = 0;

               cos1 = cos(d_angle1);
               sin1 = sin(d_angle1);
               cos2 = cos(d_angle2);
               sin2 = sin(d_angle2);
               alpha1 = cos2*cos2/dhx_right + sin2*sin2/dhy_right;
               alpha2 = sin2*sin2/dhx_right + cos2*cos2/dhy_right;
               alpha12 = cos2*sin2*(1.0/dhx_right - 1.0/dhy_right);

               DH[0] = cos1*alpha1+sin1*alpha12;
               DH[1] = cos1*alpha12+sin1*alpha2;
               DH[2] = -sin1*alpha1+cos1*alpha12;
               DH[3] = -sin1*alpha12+cos1*alpha2;
               
               ixr = (int) (xr + 0.5 + DeltaTr[0]);
               iyr = (int) (yr + 0.5 + DeltaTr[1]);
               dcx_right = xr+DeltaTr[0] - ixr;
               dcy_right = yr+DeltaTr[1] - iyr;

               // determine original window bounds
               dh_max = (dhx_right>dhy_right) ? dhx_right : dhy_right;
               ih_max = (int) (0.5+fabs(dh_max/(1.0-dh_max*(fabs(d_v0)+fabs(d_v1)))));

               // precompute kernel transformation
               for (c_kernel = 0; c_kernel<n_kernels; c_kernel++)
               {
                  SI = SigmasI[c_kernel];

                  SLMJ[c_kernel][0] = SI[0]*DH[0]+SI[1]*DH[2];
                  SLMJ[c_kernel][1] = SI[0]*DH[1]+SI[1]*DH[3];
                  SLMJ[c_kernel][2] = SI[2]*DH[0]+SI[3]*DH[2];
                  SLMJ[c_kernel][3] = SI[2]*DH[1]+SI[3]*DH[3];

                  SLM[c_kernel][0] = DH[0]*(SI[0]*DH[0]+SI[1]*DH[2])+DH[2]*(SI[2]*DH[0]+SI[3]*DH[2]);
                  SLM[c_kernel][1] = DH[0]*(SI[0]*DH[1]+SI[1]*DH[3])+DH[2]*(SI[2]*DH[1]+SI[3]*DH[3]);
                  SLM[c_kernel][2] = DH[1]*(SI[0]*DH[0]+SI[1]*DH[2])+DH[3]*(SI[2]*DH[0]+SI[3]*DH[2]);
                  SLM[c_kernel][3] = DH[1]*(SI[0]*DH[1]+SI[1]*DH[3])+DH[3]*(SI[2]*DH[1]+SI[3]*DH[3]);

               }

               if(grid_search != 1)
               {
               // precompute some values for derivatives

               // d/d_hx
               alpha1_hx = -1.0/(dhx_right*dhx_right);
               alpha12_hx = alpha1_hx*sin2*cos2;
               alpha2_hx = alpha1_hx*sin2*sin2;
               alpha1_hx *= cos2*cos2;
               dalpha_hx0 = cos1*alpha1_hx+sin1*alpha12_hx;
               dalpha_hx1 = cos1*alpha12_hx+sin1*alpha2_hx;
               dalpha_hx2 = -sin1*alpha1_hx+cos1*alpha12_hx;
               dalpha_hx3 = -sin1*alpha12_hx+cos1*alpha2_hx;

               // d/d_hy
               alpha1_hy = -1.0/(dhy_right*dhy_right);
               alpha12_hy = -alpha1_hy*sin2*cos2;
               alpha2_hy = alpha1_hy*cos2*cos2;
               alpha1_hy *= sin2*sin2;
               dalpha_hy0 = cos1*alpha1_hy+sin1*alpha12_hy;
               dalpha_hy1 = cos1*alpha12_hy+sin1*alpha2_hy;
               dalpha_hy2 = -sin1*alpha1_hy+cos1*alpha12_hy;
               dalpha_hy3 = -sin1*alpha12_hy+cos1*alpha2_hy;

               // d/d_a1
               dalpha_a10 = -sin1*alpha1+cos1*alpha12;
               dalpha_a11 = -sin1*alpha12+cos1*alpha2;
               dalpha_a12 = -cos1*alpha1-sin1*alpha12;
               dalpha_a13 = -cos1*alpha12-sin1*alpha2;

               // d/d_a2
               alpha1_a2 = -2.0*alpha12;
               alpha2_a2 = 2.0*alpha12;
               alpha12_a2 = (1.0-2.0*sin2*sin2)*(1.0/dhx_right - 1.0/dhy_right);
               dalpha_a20 = cos1*alpha1_a2+sin1*alpha12_a2;
               dalpha_a21 = cos1*alpha12_a2+sin1*alpha2_a2;
               dalpha_a22 = -sin1*alpha1_a2+cos1*alpha12_a2;
               dalpha_a23 = -sin1*alpha12_a2+cos1*alpha2_a2;

               // set to zero the gradients
               for (c_kernel = 0; c_kernel<n_kernels; c_kernel++)
               {
                  xGIa = xGI[c_kernel];
                  for (idx=0; idx<n_valid_colors; idx++)
                  {
                     c_valid_color = 9*valid_colors[idx];
                     xGIa[c_valid_color+0] = 0;
                     xGIa[c_valid_color+1] = 0;
                     xGIa[c_valid_color+2] = 0;
                     xGIa[c_valid_color+3] = 0;
                     xGIa[c_valid_color+4] = 0;
                     xGIa[c_valid_color+5] = 0;
                     xGIa[c_valid_color+6] = 0;
                     xGIa[c_valid_color+7] = 0;
                     xGIa[c_valid_color+8] = 0;
                  }
               }

               if (ih_max > 10*dt)
               {
                  //printf("%d ", ih_max);
                  ih_max = 10*dt;
                  c_trial = max_trial+1;
               }

               } //end grid search!=1

               for (xw=-ih_max; xw<=ih_max; xw++)
               {
                  for (yw=-ih_max; yw<=ih_max; yw++)
                  {
                     ixw = ixr+xw;
                     iyw = iyr+yw;

                     // test if it is in the image
                     if ((ixw>=0) && (iyw>=0) && (iyw<c_wyr) && (ixw<c_wxr))
                     {
                        tmp_idx = 3*(iyw+ixw*c_wyr);
                        voI1R = c_imr[tmp_idx+0];
                        voI1G = c_imr[tmp_idx+1];
                        voI1B = c_imr[tmp_idx+2];
                        vI1R = d_csc*voI1R;
                        vI1G = d_csc*voI1G;
                        vI1B = d_csc*voI1B;
                        if (vI1R>0.9961)
                           vI1R = 0.9961;
                        if (vI1G>0.9961)
                           vI1G = 0.9961;
                        if (vI1B>0.9961)
                           vI1B = 0.9961;

                        pmx_w = xw+dcx_right;
                        pmy_w = yw+dcy_right;
                        mz_w = pmx_w*d_v0+pmy_w*d_v1+1.0;
                        mx_w = pmx_w/mz_w;
                        my_w = pmy_w/mz_w;
                        mxx_w = mx_w*mx_w;
                        myy_w = my_w*my_w;
                        mxy_w = mx_w*my_w;
                        
#ifndef GPT_INTERPOLATED
                        // not interpolated
                        cu_idx0 = (int) (vI1R*n_bins_color);
                        cu_idx1 = (int) (vI1G*n_bins_color);
                        cu_idx2 = (int) (vI1B*n_bins_color);
#ifndef BG_USEGRAY
                        cu_idx = cu_idx0 + cu_idx1*n_bins_color + cu_idx2*n_bins_color2;
#else
                        cu_idx = cu_idx0;
#endif

                        if (grid_search == 1)
                        {
                           c_kernel = 4;
                           SI = SLM[c_kernel];

                           // compute actual kernel values
                           k_value = 1-(SI[0]*mxx_w+SI[2]*mxy_w+SI[1]*mxy_w+SI[3]*myy_w);

                           if (k_value < 0)
                              k_value = 0;

                           pu[c_kernel][cu_idx] += k_value;
                           Ch_right[c_kernel] += k_value;
                        } else
                        {
                        // for each kernel
                        for (c_kernel=0; c_kernel<n_kernels; c_kernel++)
                        {
                           SI = SLM[c_kernel];

                           // compute actual kernel values
                           k_value = 1-(SI[0]*mxx_w+SI[2]*mxy_w+SI[1]*mxy_w+SI[3]*myy_w);

                           if (k_value < 0)
                              continue;

                           pu[c_kernel][cu_idx] += k_value;
                           Ch_right[c_kernel] += k_value;

                           SIJ = SLMJ[c_kernel];

                           // compute derivative
                           kx_value0 = -2.0*(SI[0]*mx_w + SI[1]*my_w);
                           ky_value0 = -2.0*(SI[2]*mx_w + SI[3]*my_w);

                           kx_value1 = -2.0*(SIJ[0]*mx_w + SIJ[1]*my_w);
                           ky_value1 = -2.0*(SIJ[2]*mx_w + SIJ[3]*my_w);

                           xGIa = xGI[c_kernel];
                           cug_idx = cu_idx*8;
                           xGIa[cug_idx+0] += kx_value1*(mx_w*dalpha_hx0+my_w*dalpha_hx1) + ky_value1*(mx_w*dalpha_hx2+my_w*dalpha_hx3);           // hx
                           xGIa[cug_idx+1] += kx_value1*(mx_w*dalpha_hy0+my_w*dalpha_hy1) + ky_value1*(mx_w*dalpha_hy2+my_w*dalpha_hy3);           // hy
                           xGIa[cug_idx+2] += kx_value0*(-1.0+mx_w*d_v0)/mz_w + ky_value0*(my_w*d_v0)/mz_w;           // dx
                           xGIa[cug_idx+3] += kx_value0*(mx_w*d_v1)/mz_w + ky_value0*(-1.0+my_w*d_v1)/mz_w;           // dy
                           xGIa[cug_idx+4] += kx_value1*(mx_w*dalpha_a10+my_w*dalpha_a11) + ky_value1*(mx_w*dalpha_a12+my_w*dalpha_a13);           // a1
                           xGIa[cug_idx+5] += kx_value1*(mx_w*dalpha_a20+my_w*dalpha_a21) + ky_value1*(mx_w*dalpha_a22+my_w*dalpha_a23);           // a2
                           xGIa[cug_idx+6] += kx_value0*(-mx_w*pmx_w/mz_w) + ky_value0*(-my_w*pmx_w/mz_w);                                          // v0
                           xGIa[cug_idx+7] += kx_value0*(-mx_w*pmy_w/mz_w) + ky_value0*(-my_w*pmy_w/mz_w);           // v1
                           xGIa[cug_idx+8] += 0; // csc
                        }
                        }
#else
#ifndef BG_USEGRAY

                        // interpolated
                        dcu_idx0 = (vI1R*(n_bins_color-1));
                        cu_idx0 = (int) dcu_idx0;
                        aidxR_0 = 1-(dcu_idx0-cu_idx0);
                        aidxR_1 = 1-aidxR_0;
                        
                        dcu_idx1 = (vI1G*(n_bins_color-1));
                        cu_idx1 = (int) dcu_idx1;
                        aidxG_0 = 1-(dcu_idx1-cu_idx1);
                        aidxG_1 = 1-aidxG_0;//!-1
                        
                        dcu_idx2 = (vI1B*(n_bins_color-1));
                        cu_idx2 = (int) dcu_idx2;
                        aidxB_0 = 1-(dcu_idx2-cu_idx2);
                        aidxB_1 = 1-aidxB_0;//!-1
                        
                        alpha_c[0] = aidxR_0*aidxG_0*aidxB_0; 
                        alpha_c[1] = aidxR_0*aidxG_0*aidxB_1;
                        alpha_c[2] = aidxR_0*aidxG_1*aidxB_0;
                        alpha_c[3] = aidxR_0*aidxG_1*aidxB_1;
                        alpha_c[4] = aidxR_1*aidxG_0*aidxB_0;
                        alpha_c[5] = aidxR_1*aidxG_0*aidxB_1;
                        alpha_c[6] = aidxR_1*aidxG_1*aidxB_0;
                        alpha_c[7] = aidxR_1*aidxG_1*aidxB_1;

                        cu_idx = cu_idx0 + cu_idx1*n_bins_color + cu_idx2*n_bins_color2;

                        if (grid_search == 1)
                        {
                           //special compute
                           c_kernel = 4;
                           SI = SLM[c_kernel];
                           
                           // compute actual kernel values
                           k_value = 1-(SI[0]*mxx_w+SI[2]*mxy_w+SI[1]*mxy_w+SI[3]*myy_w);
                           
                           if (k_value < 0)
                              k_value = 0;
                           
                           Ch_right[c_kernel] += k_value;

                           cc_idx = cu_idx;
                           pu[c_kernel][cc_idx] += alpha_c[0]*k_value;

                           cc_idx = cu_idx+n_bins_color2;
                           pu[c_kernel][cc_idx] += alpha_c[1]*k_value;

                           cc_idx = cu_idx+n_bins_color;
                           pu[c_kernel][cc_idx] += alpha_c[2]*k_value;

                           cc_idx = cu_idx+n_bins_color2+n_bins_color;
                           pu[c_kernel][cc_idx] += alpha_c[3]*k_value;

                           cc_idx = cu_idx+1;
                           pu[c_kernel][cc_idx] += alpha_c[4]*k_value;
                           
                           cc_idx = cu_idx+1+n_bins_color2;
                           pu[c_kernel][cc_idx] += alpha_c[5]*k_value;
                          
                           cc_idx = cu_idx+1+n_bins_color;
                           pu[c_kernel][cc_idx] += alpha_c[6]*k_value;
                           
                           cc_idx = cu_idx+1+n_bins_color2+n_bins_color;
                           pu[c_kernel][cc_idx] += alpha_c[7]*k_value;
                        } else
                        {


                        alpha_d[0] = (-dcu_idx0)*aidxG_0*aidxB_0+aidxR_0*(-dcu_idx1)*aidxB_0+aidxR_0*aidxG_0*(-dcu_idx2);
                        alpha_d[1] = (-dcu_idx0)*aidxG_0*aidxB_1+aidxR_0*(-dcu_idx1)*aidxB_1+aidxR_0*aidxG_0*(dcu_idx2);
                        alpha_d[2] = (-dcu_idx0)*aidxG_1*aidxB_0+aidxR_0*(dcu_idx1)*aidxB_0+aidxR_0*aidxG_1*(-dcu_idx2);
                        alpha_d[3] = (-dcu_idx0)*aidxG_1*aidxB_1+aidxR_0*(dcu_idx1)*aidxB_1+aidxR_0*aidxG_1*(dcu_idx2);
                        alpha_d[4] = (dcu_idx0)*aidxG_0*aidxB_0+aidxR_1*(-dcu_idx1)*aidxB_0+aidxR_1*aidxG_0*(-dcu_idx2);
                        alpha_d[5] = (dcu_idx0)*aidxG_0*aidxB_1+aidxR_1*(-dcu_idx1)*aidxB_1+aidxR_1*aidxG_0*(dcu_idx2);
                        alpha_d[6] = (dcu_idx0)*aidxG_1*aidxB_0+aidxR_1*(dcu_idx1)*aidxB_0+aidxR_1*aidxG_1*(-dcu_idx2);
                        alpha_d[7] = (dcu_idx0)*aidxG_1*aidxB_1+aidxR_1*(dcu_idx1)*aidxB_1+aidxR_1*aidxG_1*(dcu_idx2);
                        
                        for (c_kernel = 0; c_kernel<n_kernels; c_kernel++)
                        {
                           SI = SLM[c_kernel];
                           
                           // compute actual kernel values
                           k_value = 1-(SI[0]*mxx_w+SI[2]*mxy_w+SI[1]*mxy_w+SI[3]*myy_w);
                           
                           if (k_value < 0)
                              continue;
                           
                           Ch_right[c_kernel] += k_value;

                           SIJ = SLMJ[c_kernel];

                           // derivatives
                           kx_value0 = -2.0*(SI[0]*mx_w + SI[1]*my_w);
                           ky_value0 = -2.0*(SI[2]*mx_w + SI[3]*my_w);

                           kx_value1 = -2.0*(SIJ[0]*mx_w + SIJ[1]*my_w);
                           ky_value1 = -2.0*(SIJ[2]*mx_w + SIJ[3]*my_w);

                           xderiv0 = kx_value1*(mx_w*dalpha_hx0+my_w*dalpha_hx1) + ky_value1*(mx_w*dalpha_hx2+my_w*dalpha_hx3);           // hx
                           xderiv1 = kx_value1*(mx_w*dalpha_hy0+my_w*dalpha_hy1) + ky_value1*(mx_w*dalpha_hy2+my_w*dalpha_hy3);           // hy
                           xderiv2 = kx_value0*(-1.0+mx_w*d_v0)/mz_w + ky_value0*(my_w*d_v0)/mz_w;           // dx
                           xderiv3 = kx_value0*(mx_w*d_v1)/mz_w + ky_value0*(-1.0+my_w*d_v1)/mz_w;           // dy
                           xderiv4 = kx_value1*(mx_w*dalpha_a10+my_w*dalpha_a11) + ky_value1*(mx_w*dalpha_a12+my_w*dalpha_a13);           // a1
                           xderiv5 = kx_value1*(mx_w*dalpha_a20+my_w*dalpha_a21) + ky_value1*(mx_w*dalpha_a22+my_w*dalpha_a23);           // a2
                           xderiv6 = kx_value0*(-mx_w*pmx_w/mz_w) + ky_value0*(-my_w*pmx_w/mz_w);                                          // v0
                           xderiv7 = kx_value0*(-mx_w*pmy_w/mz_w) + ky_value0*(-my_w*pmy_w/mz_w);           // v1
                           xderiv8 = k_value; // csc //!-1
                           
                           xGIa = xGI[c_kernel];

                           // add colors
                           cc_idx = cu_idx;
                           pu[c_kernel][cc_idx] += alpha_c[0]*k_value;
                           cug_idx = cc_idx*9;
                           xGIa[cug_idx+0] += alpha_c[0]*xderiv0;
                           xGIa[cug_idx+1] += alpha_c[0]*xderiv1;
                           xGIa[cug_idx+2] += alpha_c[0]*xderiv2;
                           xGIa[cug_idx+3] += alpha_c[0]*xderiv3;
                           xGIa[cug_idx+4] += alpha_c[0]*xderiv4;
                           xGIa[cug_idx+5] += alpha_c[0]*xderiv5;
                           xGIa[cug_idx+6] += alpha_c[0]*xderiv6;
                           xGIa[cug_idx+7] += alpha_c[0]*xderiv7;
                           xGIa[cug_idx+8] += alpha_d[0]*xderiv8;

                           cc_idx = cu_idx+n_bins_color2;
                           pu[c_kernel][cc_idx] += alpha_c[1]*k_value;
                           cug_idx = cc_idx*9;
                           xGIa[cug_idx+0] += alpha_c[1]*xderiv0;
                           xGIa[cug_idx+1] += alpha_c[1]*xderiv1;
                           xGIa[cug_idx+2] += alpha_c[1]*xderiv2;
                           xGIa[cug_idx+3] += alpha_c[1]*xderiv3;
                           xGIa[cug_idx+4] += alpha_c[1]*xderiv4;
                           xGIa[cug_idx+5] += alpha_c[1]*xderiv5;
                           xGIa[cug_idx+6] += alpha_c[1]*xderiv6;
                           xGIa[cug_idx+7] += alpha_c[1]*xderiv7;
                           xGIa[cug_idx+8] += alpha_d[1]*xderiv8;
                           
                           cc_idx = cu_idx+n_bins_color;
                           pu[c_kernel][cc_idx] += alpha_c[2]*k_value;
                           cug_idx = cc_idx*9;
                           xGIa[cug_idx+0] += alpha_c[2]*xderiv0;
                           xGIa[cug_idx+1] += alpha_c[2]*xderiv1;
                           xGIa[cug_idx+2] += alpha_c[2]*xderiv2;
                           xGIa[cug_idx+3] += alpha_c[2]*xderiv3;
                           xGIa[cug_idx+4] += alpha_c[2]*xderiv4;
                           xGIa[cug_idx+5] += alpha_c[2]*xderiv5;
                           xGIa[cug_idx+6] += alpha_c[2]*xderiv6;
                           xGIa[cug_idx+7] += alpha_c[2]*xderiv7;
                           xGIa[cug_idx+8] += alpha_d[2]*xderiv8;
                           
                           cc_idx = cu_idx+n_bins_color2+n_bins_color;
                           pu[c_kernel][cc_idx] += alpha_c[3]*k_value;
                           cug_idx = cc_idx*9;
                           xGIa[cug_idx+0] += alpha_c[3]*xderiv0;
                           xGIa[cug_idx+1] += alpha_c[3]*xderiv1;
                           xGIa[cug_idx+2] += alpha_c[3]*xderiv2;
                           xGIa[cug_idx+3] += alpha_c[3]*xderiv3;
                           xGIa[cug_idx+4] += alpha_c[3]*xderiv4;
                           xGIa[cug_idx+5] += alpha_c[3]*xderiv5;
                           xGIa[cug_idx+6] += alpha_c[3]*xderiv6;
                           xGIa[cug_idx+7] += alpha_c[3]*xderiv7;
                           xGIa[cug_idx+8] += alpha_d[3]*xderiv8;
                           
                           cc_idx = cu_idx+1;
                           pu[c_kernel][cc_idx] += alpha_c[4]*k_value;
                           cug_idx = cc_idx*9;
                           xGIa[cug_idx+0] += alpha_c[4]*xderiv0;
                           xGIa[cug_idx+1] += alpha_c[4]*xderiv1;
                           xGIa[cug_idx+2] += alpha_c[4]*xderiv2;
                           xGIa[cug_idx+3] += alpha_c[4]*xderiv3;
                           xGIa[cug_idx+4] += alpha_c[4]*xderiv4;
                           xGIa[cug_idx+5] += alpha_c[4]*xderiv5;
                           xGIa[cug_idx+6] += alpha_c[4]*xderiv6;
                           xGIa[cug_idx+7] += alpha_c[4]*xderiv7;
                           xGIa[cug_idx+8] += alpha_d[4]*xderiv8;
                           
                           cc_idx = cu_idx+1+n_bins_color2;
                           pu[c_kernel][cc_idx] += alpha_c[5]*k_value;
                           cug_idx = cc_idx*9;
                           xGIa[cug_idx+0] += alpha_c[5]*xderiv0;
                           xGIa[cug_idx+1] += alpha_c[5]*xderiv1;
                           xGIa[cug_idx+2] += alpha_c[5]*xderiv2;
                           xGIa[cug_idx+3] += alpha_c[5]*xderiv3;
                           xGIa[cug_idx+4] += alpha_c[5]*xderiv4;
                           xGIa[cug_idx+5] += alpha_c[5]*xderiv5;
                           xGIa[cug_idx+6] += alpha_c[5]*xderiv6;
                           xGIa[cug_idx+7] += alpha_c[5]*xderiv7;
                           xGIa[cug_idx+8] += alpha_d[5]*xderiv8;
                          
                           cc_idx = cu_idx+1+n_bins_color;
                           pu[c_kernel][cc_idx] += alpha_c[6]*k_value;
                           cug_idx = cc_idx*9;
                           xGIa[cug_idx+0] += alpha_c[6]*xderiv0;
                           xGIa[cug_idx+1] += alpha_c[6]*xderiv1;
                           xGIa[cug_idx+2] += alpha_c[6]*xderiv2;
                           xGIa[cug_idx+3] += alpha_c[6]*xderiv3;
                           xGIa[cug_idx+4] += alpha_c[6]*xderiv4;
                           xGIa[cug_idx+5] += alpha_c[6]*xderiv5;
                           xGIa[cug_idx+6] += alpha_c[6]*xderiv6;
                           xGIa[cug_idx+7] += alpha_c[6]*xderiv7;
                           xGIa[cug_idx+8] += alpha_d[6]*xderiv8;
                           
                           cc_idx = cu_idx+1+n_bins_color2+n_bins_color;
                           pu[c_kernel][cc_idx] += alpha_c[7]*k_value;
                           cug_idx = cc_idx*9;
                           xGIa[cug_idx+0] += alpha_c[7]*xderiv0;
                           xGIa[cug_idx+1] += alpha_c[7]*xderiv1;
                           xGIa[cug_idx+2] += alpha_c[7]*xderiv2;
                           xGIa[cug_idx+3] += alpha_c[7]*xderiv3;
                           xGIa[cug_idx+4] += alpha_c[7]*xderiv4;
                           xGIa[cug_idx+5] += alpha_c[7]*xderiv5;
                           xGIa[cug_idx+6] += alpha_c[7]*xderiv6;
                           xGIa[cug_idx+7] += alpha_c[7]*xderiv7;
                           xGIa[cug_idx+8] += alpha_d[7]*xderiv8;
                        } 
                        }
#else
                        // interpolated
                        dcu_idx0 = (vI1R*(n_bins_color-1));
                        cu_idx0 = (int) dcu_idx0;
                        aidx0 = 1-(dcu_idx0 - cu_idx0);
                        
                        dcu_idx1 = (vI1G*(n_bins_color-1));
                        
                        dcu_idx2 = (vI1B*(n_bins_color-1));
                        
                        cu_idx = cu_idx0;

                        if (grid_search == 1)
                        {
                           c_kernel = 4;
                           SI = SLM[c_kernel];
                           
                           // compute actual kernel values
                           k_value = 1-(SI[0]*mxx_w+SI[2]*mxy_w+SI[1]*mxy_w+SI[3]*myy_w);
                           
                           if (k_value < 0)
                              k_value = 0;
                           
                           Ch_right[c_kernel] += k_value;
                           // add colors
                           cc_idx = cu_idx;
                           pu[c_kernel][cc_idx] += aidx0*k_value;

                           cc_idx = cu_idx+1;
                           pu[c_kernel][cc_idx] += (1-aidx0)*k_value;

                        } else
                        {
                        
                        for (c_kernel = 0; c_kernel<n_kernels; c_kernel++)
                        {
                           SI = SLM[c_kernel];
                           
                           // compute actual kernel values
                           k_value = 1-(SI[0]*mxx_w+SI[2]*mxy_w+SI[1]*mxy_w+SI[3]*myy_w);
                           
                           if (k_value < 0)
                              continue;
                           
                           Ch_right[c_kernel] += k_value;

                           SIJ = SLMJ[c_kernel];

                           // derivatives
                           kx_value0 = -2.0*(SI[0]*mx_w + SI[1]*my_w);
                           ky_value0 = -2.0*(SI[2]*mx_w + SI[3]*my_w);

                           kx_value1 = -2.0*(SIJ[0]*mx_w + SIJ[1]*my_w);
                           ky_value1 = -2.0*(SIJ[2]*mx_w + SIJ[3]*my_w);

                           xderiv0 = kx_value1*(mx_w*dalpha_hx0+my_w*dalpha_hx1) + ky_value1*(mx_w*dalpha_hx2+my_w*dalpha_hx3);           // hx
                           xderiv1 = kx_value1*(mx_w*dalpha_hy0+my_w*dalpha_hy1) + ky_value1*(mx_w*dalpha_hy2+my_w*dalpha_hy3);           // hy
                           xderiv2 = kx_value0*(-1.0+mx_w*d_v0)/mz_w + ky_value0*(my_w*d_v0)/mz_w;           // dx
                           xderiv3 = kx_value0*(mx_w*d_v1)/mz_w + ky_value0*(-1.0+my_w*d_v1)/mz_w;           // dy
                           xderiv4 = kx_value1*(mx_w*dalpha_a10+my_w*dalpha_a11) + ky_value1*(mx_w*dalpha_a12+my_w*dalpha_a13);           // a1
                           xderiv5 = kx_value1*(mx_w*dalpha_a20+my_w*dalpha_a21) + ky_value1*(mx_w*dalpha_a22+my_w*dalpha_a23);           // a2
                           xderiv6 = kx_value0*(-mx_w*pmx_w/mz_w) + ky_value0*(-my_w*pmx_w/mz_w);                                          // v0
                           xderiv7 = kx_value0*(-mx_w*pmy_w/mz_w) + ky_value0*(-my_w*pmy_w/mz_w);           // v1
                           xderiv8 = k_value; // csc
                           
                           xGIa = xGI[c_kernel];

                           // add colors
                           cc_idx = cu_idx;
                           pu[c_kernel][cc_idx] += aidx0*k_value;
                           cug_idx = cc_idx*9;
                           xGIa[cug_idx+0] += aidx0*xderiv0;
                           xGIa[cug_idx+1] += aidx0*xderiv1;
                           xGIa[cug_idx+2] += aidx0*xderiv2;
                           xGIa[cug_idx+3] += aidx0*xderiv3;
                           xGIa[cug_idx+4] += aidx0*xderiv4;
                           xGIa[cug_idx+5] += aidx0*xderiv5;
                           xGIa[cug_idx+6] += aidx0*xderiv6;
                           xGIa[cug_idx+7] += aidx0*xderiv7;
                           xGIa[cug_idx+8] += -dcu_idx0*xderiv8;

                           cc_idx = cu_idx+1;
                           pu[c_kernel][cc_idx] += (1-aidx0)*k_value;
                           cug_idx = cc_idx*9;
                           xGIa[cug_idx+0] += (1-aidx0)*xderiv0;
                           xGIa[cug_idx+1] += (1-aidx0)*xderiv1;
                           xGIa[cug_idx+2] += (1-aidx0)*xderiv2;
                           xGIa[cug_idx+3] += (1-aidx0)*xderiv3;
                           xGIa[cug_idx+4] += (1-aidx0)*xderiv4;
                           xGIa[cug_idx+5] += (1-aidx0)*xderiv5;
                           xGIa[cug_idx+6] += (1-aidx0)*xderiv6;
                           xGIa[cug_idx+7] += (1-aidx0)*xderiv7;
                           xGIa[cug_idx+8] += dcu_idx0*xderiv8;
                        }
                        }
#endif
#endif
                      
                     } else
                     {

                     }
                  }
               }

               if(grid_search == 1)
               {

                  potential_score = 0;
                  c_kernel = 4;
                  for (cu_idx=0; cu_idx<n_valid_colors; cu_idx++)
                  {
                     c_valid_color = valid_colors[cu_idx];
                     dtemp = qu[c_kernel][c_valid_color]-sqrt(pu[c_kernel][c_valid_color]/(Ch_right[c_kernel]));
                     potential_score += dtemp*dtemp;
                  }
                  c_trial = max_trial+1;
               } else
               {
               
               // normalize distribution
               for (cu_idx=0; cu_idx<n_valid_colors; cu_idx++)
               {
                  for (c_kernel=0; c_kernel<n_kernels; c_kernel++)
                  {
                     pu[c_kernel][valid_colors[cu_idx]] = sqrt(pu[c_kernel][valid_colors[cu_idx]]/(Ch_right[c_kernel]));
                  }
               }
               
               // set distribution difference values
               for (cu_idx=0; cu_idx<n_valid_colors; cu_idx++)
               {
                  c_valid_color = valid_colors[cu_idx];
                  for (c_kernel=0; c_kernel<n_kernels; c_kernel++)
                  {
                     pq_dif[c_kernel][c_valid_color] = qu[c_kernel][c_valid_color]-pu[c_kernel][c_valid_color];
                  }
               }
                                    
               // for each kernel
               for (c_kernel=0; c_kernel<n_kernels; c_kernel++)
               {
                  for (cu_idx=0; cu_idx<n_valid_colors; cu_idx++)
                  {
                     c_valid_color = valid_colors[cu_idx];
                     xGIa = &xGI[c_kernel][9*c_valid_color];
                     dtemp = (2*pu[c_kernel][c_valid_color]*Ch_right[c_kernel]); //!!!?
                     if (dtemp > 0.0000001)
                     {
                        xGIa[0] /= dtemp;
                        xGIa[1] /= dtemp;
                        xGIa[2] /= dtemp;
                        xGIa[3] /= dtemp;
                        xGIa[4] /= dtemp;
                        xGIa[5] /= dtemp;
                        xGIa[6] /= dtemp;
                        xGIa[7] /= dtemp;
                        xGIa[8] /= dtemp;

                     } else
                     {
                        xGIa[0] = 0;
                        xGIa[1] = 0;
                        xGIa[2] = 0;
                        xGIa[3] = 0;
                        xGIa[4] = 0;
                        xGIa[5] = 0;
                        xGIa[6] = 0;
                        xGIa[7] = 0;
                        xGIa[8] = 0;
                     }
                  }
               }

               //bgLog("after cd upd:");
               //timer_elapsed(0);


               // optical flow difference
               oalpha1 = cos2*cos2*dhx_right + sin2*sin2*dhy_right;
               oalpha2 = sin2*sin2*dhx_right + cos2*cos2*dhy_right;
               oalpha12 = cos2*sin2*(dhx_right - dhy_right);

               oDH[0] = cos1*oalpha1+sin1*oalpha12;
               oDH[1] = cos1*oalpha12-sin1*oalpha1;
               oDH[2] = sin1*oalpha2+cos1*oalpha12;
               oDH[3] = -sin1*oalpha12+cos1*oalpha2;

               // precompute some gradients
               oDH0_hx = cos1*(cos2*cos2)+sin1*(cos2*sin2);
               oDH1_hx = cos1*(cos2*sin2)-sin1*(cos2*cos2);
               oDH2_hx = sin1*(sin2*sin2)+cos1*(cos2*sin2);
               oDH3_hx = -sin1*(cos2*sin2)+cos1*(sin2*sin2);

               oDH0_hy = cos1*(sin2*sin2)+sin1*(-cos2*sin2);
               oDH1_hy = cos1*(-cos2*sin2)-sin1*(sin2*sin2);
               oDH2_hy = sin1*(cos2*cos2)+cos1*(-cos2*sin2);
               oDH3_hy = -sin1*(-cos2*sin2)+cos1*(cos2*cos2);

               oDH0_a1 = -sin1*oalpha1+cos1*oalpha12;
               oDH1_a1 = -sin1*oalpha12-cos1*oalpha1;
               oDH2_a1 = cos1*oalpha2-sin1*oalpha12;
               oDH3_a1 = -cos1*oalpha12-sin1*oalpha2;

               gvxR = (dhx_right-dhy_right)*(cos2*cos2-sin2*sin2);
               oDH0_a2 = cos1*(-2.0*oalpha12)+sin1*(gvxR);
               oDH1_a2 = cos1*(gvxR)-sin1*(-2.0*oalpha12);
               oDH2_a2 = sin1*(2.0*oalpha12)+cos1*(gvxR);
               oDH3_a2 = -sin1*(gvxR)+cos1*(2.0*oalpha12);

               for (xw = -ihx_left; xw<= ihx_left; xw++)
               {
                  for (yw = -ihy_left; yw<= ihy_left; yw++)
                  {
                     wgim_idx = (yw+ihy_left+(xw+ihx_left)*dw);
                     wim_idx = 3*wgim_idx;
                     int cc_idx = 9*wgim_idx;

                     xw_dt = xw/((double) dt);
                     yw_dt = yw/((double) dt);
                     pmx_w = oDH[0]*xw_dt + oDH[1]*yw_dt;
                     pmy_w = oDH[2]*xw_dt + oDH[3]*yw_dt;

                     mz_w = -d_v0*pmx_w-d_v1*pmy_w+1;
                     mx_w = pmx_w/mz_w;
                     my_w = pmy_w/mz_w;

                     ixw = (int) (mx_w + xr + DeltaTr[0]);
                     iyw = (int) (my_w + yr + DeltaTr[1]);
                     dcx_right = mx_w + xr + DeltaTr[0] - ixw;
                     dcy_right = my_w + yr + DeltaTr[1] - iyw;

                     // test if it is in the image
                     if ((ixw>=0) && (iyw>=0) && (iyw<(c_wyr-1)) && (ixw<(c_wxr-1)))
                     {
                        oi_x0 = 3*(iyw+ixw*c_wyr);
                        oi_x1 = 3*(iyw+(ixw+1)*c_wyr);
                        oi_x2 = 3*(iyw+1+ixw*c_wyr);
                        oi_x3 = 3*(iyw+1+(ixw+1)*c_wyr);

                        // image
                        z11=c_imr[oi_x0+0]; z21=c_imr[oi_x1+0]; z12=c_imr[oi_x2+0]; z22=c_imr[oi_x3+0];
                        voI1R = z11+dcx_right*(z21-z11)+dcy_right*(z12-z11)+dcx_right*dcy_right*(z11-z12-z21+z22);
                        z11=c_imr[oi_x0+1]; z21=c_imr[oi_x1+1]; z12=c_imr[oi_x2+1]; z22=c_imr[oi_x3+1];
                        voI1G = z11+dcx_right*(z21-z11)+dcy_right*(z12-z11)+dcx_right*dcy_right*(z11-z12-z21+z22);
                        z11=c_imr[oi_x0+2]; z21=c_imr[oi_x1+2]; z12=c_imr[oi_x2+2]; z22=c_imr[oi_x3+2];
                        voI1B = z11+dcx_right*(z21-z11)+dcy_right*(z12-z11)+dcx_right*dcy_right*(z11-z12-z21+z22);

                        vI1R = voI1R*d_csc;
                        vI1G = voI1G*d_csc;
                        vI1B = voI1B*d_csc;

                        wim_right[wim_idx+0] = vI1R;
                        wim_right[wim_idx+1] = vI1G;
                        wim_right[wim_idx+2] = vI1B;

                        // difference
                        wim_diff[wim_idx+0] = -(vI1R-wim_left[wim_idx+0]);
                        wim_diff[wim_idx+1] = -(vI1G-wim_left[wim_idx+1]);
                        wim_diff[wim_idx+2] = -(vI1B-wim_left[wim_idx+2]);

                        // grad x
                        z11=c_gimx_r[oi_x0+0]; z21=c_gimx_r[oi_x1+0]; z12=c_gimx_r[oi_x2+0]; z22=c_gimx_r[oi_x3+0];
                        gvxR = z11+dcx_right*(z21-z11)+dcy_right*(z12-z11)+dcx_right*dcy_right*(z11-z12-z21+z22);
                        z11=c_gimx_r[oi_x0+1]; z21=c_gimx_r[oi_x1+1]; z12=c_gimx_r[oi_x2+1]; z22=c_gimx_r[oi_x3+1];
                        gvxG = z11+dcx_right*(z21-z11)+dcy_right*(z12-z11)+dcx_right*dcy_right*(z11-z12-z21+z22);
                        z11=c_gimx_r[oi_x0+2]; z21=c_gimx_r[oi_x1+2]; z12=c_gimx_r[oi_x2+2]; z22=c_gimx_r[oi_x3+2];
                        gvxB = z11+dcx_right*(z21-z11)+dcy_right*(z12-z11)+dcx_right*dcy_right*(z11-z12-z21+z22);

                        gvxR *= d_csc;gvxG *= d_csc;gvxB *= d_csc;

                        // grad y
                        z11=c_gimy_r[oi_x0+0]; z21=c_gimy_r[oi_x1+0]; z12=c_gimy_r[oi_x2+0]; z22=c_gimy_r[oi_x3+0];
                        gvyR = z11+dcx_right*(z21-z11)+dcy_right*(z12-z11)+dcx_right*dcy_right*(z11-z12-z21+z22);
                        z11=c_gimy_r[oi_x0+1]; z21=c_gimy_r[oi_x1+1]; z12=c_gimy_r[oi_x2+1]; z22=c_gimy_r[oi_x3+1];
                        gvyG = z11+dcx_right*(z21-z11)+dcy_right*(z12-z11)+dcx_right*dcy_right*(z11-z12-z21+z22);
                        z11=c_gimy_r[oi_x0+2]; z21=c_gimy_r[oi_x1+2]; z12=c_gimy_r[oi_x2+2]; z22=c_gimy_r[oi_x3+2];
                        gvyB = z11+dcx_right*(z21-z11)+dcy_right*(z12-z11)+dcx_right*dcy_right*(z11-z12-z21+z22);

                        gvyR *= d_csc;gvyG *= d_csc;gvyB *= d_csc;

                        // compute jacobian of the criterion
                        mxz_w = mx_w/mz_w;
                        myz_w = my_w/mz_w;

                        dmx_pmx = 1.0/mz_w+d_v0*mxz_w;
                        dmy_pmx = d_v0*myz_w;
                        dmx_pmy = d_v1*mxz_w;
                        dmy_pmy = 1.0/mz_w+d_v1*myz_w;

                        // d_hx
                        dpmx_hx = oDH0_hx*xw_dt + oDH1_hx*yw_dt;
                        dpmy_hx = oDH2_hx*xw_dt + oDH3_hx*yw_dt;
                        dmx_hx = dmx_pmx*dpmx_hx+dmx_pmy*dpmy_hx;
                        dmy_hx = dmy_pmx*dpmx_hx+dmy_pmy*dpmy_hx;

                        xGIof[0][cc_idx+0] = gvxR*dmx_hx + gvyR*dmy_hx;
                        xGIof[1][cc_idx+0] = gvxG*dmx_hx + gvyG*dmy_hx;
                        xGIof[2][cc_idx+0] = gvxB*dmx_hx + gvyB*dmy_hx;

                        // d_hy
                        dpmx_hy = oDH0_hy*xw_dt + oDH1_hy*yw_dt;
                        dpmy_hy = oDH2_hy*xw_dt + oDH3_hy*yw_dt;
                        dmx_hy = dmx_pmx*dpmx_hy+dmx_pmy*dpmy_hy;
                        dmy_hy = dmy_pmx*dpmx_hy+dmy_pmy*dpmy_hy;

                        xGIof[0][cc_idx+1] = gvxR*dmx_hy + gvyR*dmy_hy;
                        xGIof[1][cc_idx+1] = gvxG*dmx_hy + gvyG*dmy_hy;
                        xGIof[2][cc_idx+1] = gvxB*dmx_hy + gvyB*dmy_hy;

                        // d_dx
                        xGIof[0][cc_idx+2] = gvxR;
                        xGIof[1][cc_idx+2] = gvxG;
                        xGIof[2][cc_idx+2] = gvxB;

                        // d_dy
                        xGIof[0][cc_idx+3] = gvyR;
                        xGIof[1][cc_idx+3] = gvyG;
                        xGIof[2][cc_idx+3] = gvyB;

                        // d_a1
                        dpmx_a1 = oDH0_a1*xw_dt + oDH1_a1*yw_dt;
                        dpmy_a1 = oDH2_a1*xw_dt + oDH3_a1*yw_dt;
                        dmx_a1 = dmx_pmx*dpmx_a1+dmx_pmy*dpmy_a1;
                        dmy_a1 = dmy_pmx*dpmx_a1+dmy_pmy*dpmy_a1;

                        xGIof[0][cc_idx+4] = gvxR*dmx_a1 + gvyR*dmy_a1;
                        xGIof[1][cc_idx+4] = gvxG*dmx_a1 + gvyG*dmy_a1;
                        xGIof[2][cc_idx+4] = gvxB*dmx_a1 + gvyB*dmy_a1;

                        // d_a2
                        dpmx_a2 = oDH0_a2*xw_dt + oDH1_a2*yw_dt;
                        dpmy_a2 = oDH2_a2*xw_dt + oDH3_a2*yw_dt;
                        dmx_a2 = dmx_pmx*dpmx_a2+dmx_pmy*dpmy_a2;
                        dmy_a2 = dmy_pmx*dpmx_a2+dmy_pmy*dpmy_a2;

                        xGIof[0][cc_idx+5] = gvxR*dmx_a2 + gvyR*dmy_a2;
                        xGIof[1][cc_idx+5] = gvxG*dmx_a2 + gvyG*dmy_a2;
                        xGIof[2][cc_idx+5] = gvxB*dmx_a2 + gvyB*dmy_a2;

                        // d_v0
                        xGIof[0][cc_idx+6] = pmx_w*(gvxR*mxz_w+gvyR*myz_w);
                        xGIof[1][cc_idx+6] = pmx_w*(gvxG*mxz_w+gvyG*myz_w);
                        xGIof[2][cc_idx+6] = pmx_w*(gvxB*mxz_w+gvyB*myz_w);

                        // d_v1
                        xGIof[0][cc_idx+7] = pmy_w*(gvxR*mxz_w+gvyR*myz_w);
                        xGIof[1][cc_idx+7] = pmy_w*(gvxG*mxz_w+gvyG*myz_w);
                        xGIof[2][cc_idx+7] = pmy_w*(gvxB*mxz_w+gvyB*myz_w);

                        // d_csc
                        xGIof[0][cc_idx+8] = voI1R;
                        xGIof[1][cc_idx+8] = voI1G;
                        xGIof[2][cc_idx+8] = voI1B;
                     } else
                     {
                        wim_right[wim_idx+0] = BG_CDOF_DEFAULT_IM1;
                        wim_right[wim_idx+1] = BG_CDOF_DEFAULT_IM1;
                        wim_right[wim_idx+2] = BG_CDOF_DEFAULT_IM1;

                        // difference
                        wim_diff[wim_idx+0] = wim_left[wim_idx+0]-BG_CDOF_DEFAULT_IM1;
                        wim_diff[wim_idx+1] = wim_left[wim_idx+1]-BG_CDOF_DEFAULT_IM1;
                        wim_diff[wim_idx+2] = wim_left[wim_idx+2]-BG_CDOF_DEFAULT_IM1;

                        // set gradient influence to 0
                        for (i=0; i<9; i++)
                        {
                           xGIof[0][cc_idx+i] = 0;
                           xGIof[1][cc_idx+i] = 0;
                           xGIof[2][cc_idx+i] = 0;
                        }
                     }
                  }
               }

              //bgLog("after of upd:");
               //timer_elapsed(0);

               c_bw_iter = 1;
               do_bw_iter = 1;

               if (useBiweight_ == 1)
               {
                  // init weight matrix for first solution
                  for (cu_idx=0; cu_idx<n_valid_colors; cu_idx++)
                  {
                     c_valid_color = valid_colors[cu_idx];
                     wghtBw[c_valid_color] = 1.0;
                  }

                  // init weight matrix for of part
                  for (cu_idx=0; cu_idx<dw2; cu_idx++)
                     wghtBw_of[cu_idx] = 1.0;
               }

               while (do_bw_iter == 1)
               {
                  // this is for distribution
                  // init system matrix to 0
                  for (idx=0; idx<90; idx++)
                     W[idx] = 0;

                  if (useBiweight_ == 1)
                  {
                     for (c_kernel=0; c_kernel<n_kernels; c_kernel++)
                     {                  
                        for (cu_idx=0; cu_idx<n_valid_colors; cu_idx++)
                        {
                           c_valid_color = valid_colors[cu_idx];
                           xGIa = &xGI[c_kernel][9*c_valid_color];
                           c_bwght = wghtBw[c_valid_color];
                           c_iwght = c_bwght*pq_dif[c_kernel][c_valid_color];
                           W_i = 0;
                           for (W_c=0; W_c<9; W_c++)
                           {
                              W_i += W_c;
                              for (W_r=W_c; W_r<9; W_r++)
                              {
                                 W[W_i] += c_bwght*xGIa[W_r]*xGIa[W_c];
                                 W_i++;
                              }
                              W[81+W_c] += xGIa[W_c]*c_iwght;
                           }
                        }
                     }
                  }
                  else
                  {
                     for (c_kernel=0; c_kernel<n_kernels; c_kernel++)
                     {                  
                        for (cu_idx=0; cu_idx<n_valid_colors; cu_idx++)
                        {
                           c_valid_color = valid_colors[cu_idx];
                           xGIa = &xGI[c_kernel][9*c_valid_color];
                           c_iwght = pq_dif[c_kernel][c_valid_color];
                           W_i = 0;
                           for (W_c=0; W_c<9; W_c++)
                           {
                              W_i += W_c;
                              for (W_r=W_c; W_r<9; W_r++)
                              {
                                 W[W_i] += xGIa[W_r]*xGIa[W_c];
                                 W_i++;
                              }
                              W[81+W_c] += xGIa[W_c]*c_iwght;
                           }
                        }
                     }
                  }

                  // this is for optical flow
                  for (idx=0; idx<90; idx++)
                     Wof[idx] = 0;

                  if (useBiweight_ == 1)
                  {
                     for (c_kernel=0; c_kernel<3; c_kernel++)
                     {                  
                        for (cu_idx=0; cu_idx<dw2; cu_idx++)
                        {
                           xGIofa = &xGIof[c_kernel][9*cu_idx];
                           c_bwght = wghtBw_of[cu_idx]*of_wght[cu_idx];
                           c_iwght = c_bwght*wim_diff[3*cu_idx+c_kernel];
                           W_i = 0;
                           for (W_c=0; W_c<9; W_c++)
                           {
                              W_i += W_c;
                              for (W_r=W_c; W_r<9; W_r++)
                              {
                                 Wof[W_i] += c_bwght*xGIofa[W_r]*xGIofa[W_c];
                                 W_i++;
                              }
                              Wof[81+W_c] += xGIofa[W_c]*c_iwght;
                           }
                        }
                     }
                  }
                  else
                  {
                     for (c_kernel=0; c_kernel<3; c_kernel++) // 3 colors
                     {                  
                        for (cu_idx=0; cu_idx<dw2; cu_idx++) // window index
                        {
                           xGIofa = &xGIof[c_kernel][9*cu_idx];
                           c_bwght = of_wght[cu_idx];
                           c_iwght = c_bwght*wim_diff[3*cu_idx+c_kernel];
                           W_i = 0;
                           for (W_c=0; W_c<9; W_c++)
                           {
                              W_i += W_c;
                              for (W_r=W_c; W_r<9; W_r++)
                              {
                                 Wof[W_i] += c_bwght*xGIofa[W_r]*xGIofa[W_c];
                                 W_i++;
                              }
                              Wof[81+W_c] += xGIofa[W_c]*c_iwght;
                           }
                        }
                     }
                  }

                  // combine the two systems!
                  for (idx=0; idx<90; idx++)
                     W[idx] = ratioCD_*W[idx]+ratioOF_*Wof[idx];

                  // eliminate unwanted parameters
                  for (idx=0; idx<nelim; idx++)
                  {
                     i_k = elimIdx[idx];
                     for (W_r=(i_k+1); W_r<9; W_r++)
                        W[W_r+i_k*9] = 0;
                     for (W_c=0; W_c<i_k; W_c++)
                        W[i_k+W_c*9] = 0;
                     W[i_k+i_k*9] = 1.0;
                     W[81+i_k] = 0.0;
                  }

                  // solve
                  for (W_c=0; W_c<9; W_c++)
                  {
                     for (W_r=W_c+1; W_r<9; W_r++)
                     {
                        W[W_c+W_r*9] = W[W_r+W_c*9];
                     }
                  }

                  /*
                  //!save W
                  FILE *fd;
                  fd = fopen("wt.txt","w");
                  for (W_r=0; W_r<9; W_r++)
                  {
                     for(W_c=0; W_c<10; W_c++)
                     {
                        fprintf(fd, "%g ", W[W_r+W_c*9]);
                     }
                     fprintf(fd,"\n");
                  }
                  fclose(fd);
                  */

#ifdef CDOF_TEST_COV
                  // covariance
                  for (idx=0; idx<90; idx++)
                     Worig[idx] = W[idx];
#endif
                  
                  // augment lambda? (stability)
                  double lambda = 1e-9;
                  for (W_c=0; W_c<9; W_c++)
                     W[W_c+W_c*9] += lambda;
                  
                  // compute affine transform sol.
                  // Gauss elimin
                  int good_solution = 1;
                  for (i_k = 0; i_k<8; i_k++)
                  {
                     for (i_i = i_k+1; i_i<9; i_i++)
                     {
                        if (fabs(W[i_k + 9*i_k]) < 1e-20)
                           good_solution = 0;
                        
                        W[i_i+9*i_k] /= W[i_k + 9*i_k];
                        i_m = W[i_i+9*i_k];
                        for (i_j = i_k+1; i_j<=9; i_j++)
                        {
                           W[i_i+9*i_j] -= i_m*W[i_k+9*i_j];
                        }
                     }
                  }
                  // backsubst
                  for (i_k = 8; i_k>=0; i_k--)
                  {
                     dtemp = 0;
                     for (i_j=(i_k+1); i_j<9; i_j++)
                     {
                        dtemp += W[i_k+9*i_j]*vD[i_j];
                     }
                     if (fabs(W[i_k+9*i_k]) < 1e-20)
                        good_solution = 0;
                     vD[i_k] = (W[81+i_k] - dtemp)/W[i_k+9*i_k];
                  }
                  
                  if (good_solution == 0)
                  {
                     vD[0] = vD[1] = vD[2] = vD[3] = vD[4] = vD[5] = vD[6] = vD[7] = vD[8] = 0.0;
                  }

                  if (useBiweight_ == 1)
                  {
                     c_bw_iter++;
                     if (c_bw_iter>=nBwTrials_)
                     {
                        // done
                        do_bw_iter = 0;
                     } else
                     {
                        // update weights and do again recompute solution
                        for (cu_idx=0; cu_idx<n_valid_colors; cu_idx++)
                        {
                           c_valid_color = valid_colors[cu_idx];

                           u_bw = 0;
                           u_bwsign = 0;
                           
                           for (c_kernel=0; c_kernel<n_kernels; c_kernel++)
                           {                  
                              xGIa = &xGI[c_kernel][9*c_valid_color];
                              //u_bw = 0;
                              for (i_k=0; i_k<9; i_k++)
                                 u_bw += xGIa[i_k]*vD[i_k];
                              u_bw -= pq_dif[c_kernel][c_valid_color];
                              u_bwsign += pq_dif[c_kernel][c_valid_color];
                           }

                           if (u_bwsign < 0)
                              u_bw /= bwSigmaCDM_;
                           else
                              u_bw /= bwSigmaCDP_;

                           u_bw *= u_bw; // square it
                           if (u_bw < ab2)
                           {
                              u_bw /= ab2;
                              u_bw = 1.0-u_bw;
                              wghtBw[c_valid_color] = u_bw*u_bw; // set weight
                           } else
                           {
                              wghtBw[c_valid_color] = 0.0;
                           }
                        }

                        // optical flow weights
                        for (cu_idx=0; cu_idx<dw2; cu_idx++)
                        {
                           u_bw = 0;
                           for (i_k=0; i_k<9; i_k++)
                           {
                              u_bw += xGIof[0][9*cu_idx] * vD[i_k];
                              u_bw += xGIof[1][9*cu_idx] * vD[i_k];
                              u_bw += xGIof[2][9*cu_idx] * vD[i_k];
                           }
                           u_bw -= wim_diff[3*cu_idx+0];
                           u_bw -= wim_diff[3*cu_idx+1];
                           u_bw -= wim_diff[3*cu_idx+2];


                           u_bw /= bwSigmaOF_;
                           u_bw *= u_bw;
                           if (u_bw<ab2)
                           {
                              u_bw /= ab2;
                              u_bw = 1.0 - u_bw;
                              wghtBw_of[cu_idx] = u_bw*u_bw;
                           } else
                           {
                              wghtBw_of[cu_idx] = 0.0;
                           }
                        }
                     }
                  } else
                  {
                     do_bw_iter = 0;
                  }
               } // end while bw_iterations
               
               if (useBiweight_ == 1)
               {
                  // compute old error & new error
                  old_error = 0;
                  for (cu_idx=0; cu_idx<n_valid_colors; cu_idx++)
                  {
                     c_valid_color = valid_colors[cu_idx];
                     
                     for (c_kernel=0; c_kernel<n_kernels; c_kernel++)
                     {                  
                        u_bw = pq_dif[c_kernel][c_valid_color];
                        u_bwsign = -u_bw;
                        
                        if (u_bwsign < 0)
                           u_bw /= bwSigmaCDM_;
                        else
                           u_bw /= bwSigmaCDP_;
                        
                        u_bw *= u_bw; // square it
                        if (u_bw < ab2)
                        {
                           u_bw /= ab2;
                           u_bw = 1.0-u_bw;
                           old_error += ab2*(1.0-u_bw*u_bw*u_bw)/6.0; // set weight
                        } else
                        {
                           old_error += ab2/6.0;
                        }
                     }
                  }
                  
                  old_error /= n_kernels;
                  
                  cs_ms = old_error;
                  
                  
                  // compute optical flow error
                  of_error = 0;
                  for (cu_idx=0; cu_idx<dw2; cu_idx++)
                  {
                     u_bw = 0;
                     u_bwsign = wim_diff[3*cu_idx+0];
                     u_bw += u_bwsign*u_bwsign;
                     u_bwsign = wim_diff[3*cu_idx+1];
                     u_bw += u_bwsign*u_bwsign;
                     u_bwsign = wim_diff[3*cu_idx+2];
                     u_bw += u_bwsign*u_bwsign;

                     u_bw /= bwSigmaOF2;
                     if (u_bw<ab2)
                     {
                        u_bw /= ab2;
                        u_bw = 1.0 - u_bw;
                        of_error = ab2*(1.0-u_bw*u_bw*u_bw)/6.0;
                     } else
                     {
                        of_error = ab2/6.0;
                     }
                  }
                  
                  cs_of = of_error;
               } else 
               {
                  // compute old error & new error
                  old_error = 0;
                  for (c_kernel=0; c_kernel<n_kernels; c_kernel++)
                  {
                     for (idx=0; idx<n_valid_colors; idx++)
                     {
                        dtemp = pq_dif[c_kernel][valid_colors[idx]];
                        old_error += dtemp*dtemp;
                     }
                  }
                  
                  old_error /= n_kernels;
                  
                  cs_ms = old_error;
                  
                  
                  // compute optical flow error
                  of_error = 0;
                  for (idx=0; idx<dw2; idx++)
                  {
                     of_error+=of_wght[idx]*wim_diff[3*idx+0]*wim_diff[3*idx+0];
                     of_error+=of_wght[idx]*wim_diff[3*idx+1]*wim_diff[3*idx+1];
                     of_error+=of_wght[idx]*wim_diff[3*idx+2]*wim_diff[3*idx+2];
                  }
                  
                  cs_of = of_error;              
               }
               old_error = ratioCD_*old_error + ratioOF_*of_error;

               // set best if plauzible
               if (old_error < best_score)
               {
                  best_score = old_error;
                  best_params[0] = dhx_right;
                  best_params[1] = dhy_right;
                  best_params[2] = d_angle1;
                  best_params[3] = d_angle2;
                  best_params[4] = d_v0;
                  best_params[5] = d_v1;
                  best_params[6] = d_csc;
                  best_location[0] = xr+DeltaTr[0];
                  best_location[1] = yr+DeltaTr[1];

                  best_ms = cs_ms;
                  best_of = cs_of;
#ifdef CDOF_TEST_COV
                  //covariance
                  if (c_level==0)
                  {
                     for (idx=0; idx<90; idx++)
                        dmW[idx]=Worig[idx];
                  }
#endif
               }


               // update transformation
               //if(c_level==(pyrLevels_-1))
               dhx_right += vD[0];
               dhy_right += vD[1];

               DeltaTr[0] += vD[2];
               DeltaTr[1] += vD[3];

               d_angle1 += vD[4];
               d_angle2 += vD[5];

               d_v0 += vD[6];
               d_v1 += vD[7];

               d_csc += vD[8];

               // cut the search if not improve
               if (((c_trial > 15) && (old_error > (10*best_score))) || (dhy_right < (dt/4)) || (dhx_right < (dt/4)))
               {
//                  bgLog("err %g, %g, %g, %g\n", old_error, best_score, dhy_right, dhx_right);

                  c_trial = max_trial + 1;
               }
               
               if ((xr+DeltaTr[0]<0) || ((xr+DeltaTr[0])>=c_wxr) ||
                  ((yr+DeltaTr[1]<0) || ((yr+DeltaTr[1])>=c_wyr)))
                  c_trial = max_trial+1;
               
               normMove = 0;
               for (i_k=0; i_k<9; i_k++)
                  normMove += vD[i_k]*vD[i_k];

               if ((normMove < 0.1) && (nelim!=nelimOrig))
               {
                  nelim = nelimOrig;
               }

//               bgLogFile("trial %d, pt: %d %d, ms: %g, of: %g, norm: %g %g\n", c_trial, bgRound(xr+DeltaTr[0]), bgRound(yr+DeltaTr[1]), cs_of, cs_ms, normMove, fabs(old_error2-old_error));
//               bgLogFile("          h: %g %g, v: %g %g, c: %g\n", dhx_right, dhy_right, d_v0, d_v1, d_csc);
               old_error2 = old_error;

#ifdef CDOF_TEST_COV
//               bgLog("trial %d, pt: %d %d, ms: %g, of: %g, norm: %g\n", c_trial, bgRound(xr+DeltaTr[0]), bgRound(yr+DeltaTr[1]), cs_of, cs_ms, normMove);
//               bgLog("          h: %g %g, v: %g %g, c: %g\n", dhx_right, dhy_right, d_v0, d_v1, d_csc);
#endif

            }
            }

         // here ends the while
            nelim = nelimNew;

            if((searchType_ <=0) && (grid_search <= 0))
               grid_search = -1; //end

            if(searchType_ == 2)
            {
               if (grid_search == 2)
               {
                  //go to next, full 
                  ipotential++;
                  if (ipotential < npotential)
                  {
                     xr = potential_grid_params[2*ipotential+0];
                     yr = potential_grid_params[2*ipotential+1];
                  } else
                  {
                     grid_search = -1; //end
                  }
               } else
               {
                  grid_search = -1;
               }
            }

            if(searchType_ == 1)
            {
               if (grid_search == 0)
               {
                  grid_search = -1;
               }
               else
               {
                  if (grid_search == 1)
                  {
                     potential_grid_scores[ipotential] = potential_score;
                     ipotential++;
                     if (ipotential < npotential)
                     {
                        xr = potential_grid_params[2*ipotential+0];
                        yr = potential_grid_params[2*ipotential+1];

                     } else
                     {
                        // potential detected, sort and get only best
                        for (idx=0; idx<npotential; idx++)
                           ipotential_temp[idx] = idx;
                        bgISort(potential_grid_scores, npotential, ipotential_temp);
                        for (idx=0; idx<(BG_CDOF_BESTGRIDTOPN-1); idx++)
                        {
                           best_grid_params[9*idx+0] = potential_grid_params[2*ipotential_temp[idx]+0];
                           best_grid_params[9*idx+1] = potential_grid_params[2*ipotential_temp[idx]+1];
                        }
                        // last one alway is the original
                        best_grid_params[9*idx+0] = xr_orig;
                        best_grid_params[9*idx+1] = yr_orig;
                        
                        xr = best_grid_params[0];
                        yr = best_grid_params[1];
                        grid_search = 2;
                        ibestgrid = 0;
                     }
                  } else if(grid_search == 2)//go to next, full
                  {
                     // record score
                     best_grid_scores[ibestgrid] = best_score;
                     best_grid_params[9*ibestgrid+0] = best_location[0];
                     best_grid_params[9*ibestgrid+1] = best_location[1];
                     best_grid_params[9*ibestgrid+2] = best_params[0];
                     best_grid_params[9*ibestgrid+3] = best_params[1];
                     best_grid_params[9*ibestgrid+4] = best_params[2];
                     best_grid_params[9*ibestgrid+5] = best_params[3];
                     best_grid_params[9*ibestgrid+6] = best_params[4];
                     best_grid_params[9*ibestgrid+7] = best_params[5];
                     best_grid_params[9*ibestgrid+8] = best_params[6];
                     
                     best_score = 1e100;
                     
                     ibestgrid++;
                     if (ibestgrid<BG_CDOF_BESTGRIDTOPN)
                     {
                        xr = best_grid_params[9*ibestgrid+0];
                        yr = best_grid_params[9*ibestgrid+1];
                     } else
                     {
                        //end, put best in best params
                        for (idx=0; idx<BG_CDOF_BESTGRIDTOPN; idx++)
                           ipotential_temp[idx] = idx;
                        bgISort(best_grid_scores, BG_CDOF_BESTGRIDTOPN, ipotential_temp);
                        ibestgrid = ipotential_temp[0];
                        best_score = best_grid_scores[0];
                        best_location[0] = best_grid_params[9*ibestgrid+0];
                        best_location[1] = best_grid_params[9*ibestgrid+1];
                        best_params[0] = best_grid_params[9*ibestgrid+2];
                        best_params[1] = best_grid_params[9*ibestgrid+3];
                        best_params[2] = best_grid_params[9*ibestgrid+4];
                        best_params[3] = best_grid_params[9*ibestgrid+5];
                        best_params[4] = best_grid_params[9*ibestgrid+6];
                        best_params[5] = best_grid_params[9*ibestgrid+7];
                        best_params[6] = best_grid_params[9*ibestgrid+8];
                        
                        grid_search = -1;
                     }
                  }
               }
            }

            if (grid_search < 0)
            {
               xr = best_location[0];
               yr = best_location[1];
               d_params[0] = best_params[0]/dt; //hx
               d_params[1] = best_params[1]/dt; //hy
               d_params[2] = best_params[2];    //angle1
               d_params[3] = best_params[3];    //angle2
               d_params[4] = best_params[4];    //v0
               d_params[5] = best_params[5];    //v1
               d_params[6] = best_params[6];

            }
            
         } //end while(gridsearch != -1)

         bgLogFile("total end (%.1f %.1f) to (%.1f %.1f) gl: %g\n", 
              xl, yl, best_location[0], best_location[1], best_score);


         xr = best_location[0];
         yr = best_location[1];

         // switch to higher resolution
         
         //Dtr stays the same
         if (c_level>0)
         {
            xr = hratio+xr*pyrRatio_;
            yr = hratio+yr*pyrRatio_;

            xl = hratio+xl*pyrRatio_;
            yl = hratio+yl*pyrRatio_;

            DeltaTr[0] = 0;
            DeltaTr[1] = 0;

            // upgrade v0, v1
            d_params[4] /= pyrRatio_;
            d_params[5] /= pyrRatio_;

            //max_trial += maxNTrial_;
         }
      bgLog("after pir. level %d:", c_level);
      timer_elapsed(1);
      }



      bgLog("right: %d, %d, score: %g\n", (int) xr, (int) yr, best_score);

      r_pt[2*c_point] = xr;
      r_pt[2*c_point+1] = yr;
      score[c_point] = best_score;
      d_params[0] = best_params[0]/dt; //hx
      d_params[1] = best_params[1]/dt; //hy
      d_params[2] = best_params[2];    //angle1
      d_params[3] = best_params[3];    //angle2
      d_params[4] = best_params[4];    //v0
      d_params[5] = best_params[5];    //v1
      d_params[6] = best_params[6];    // csc

#ifdef CDOF_TEST_COV
      // my temp save
//      FILE* fd;
//      fd = fopen("data0.txt","wb");
//      fprintf(fd, "%g %g %g %g %g %g %g %g %g\n",
//         (double) dt, (double) dt, (double) xl, (double) yl, 0.0, 0.0, 0.0, 0.0, 1.0);
//      fclose(fd);
//      fd = fopen("data1.txt","wb");
//      fprintf(fd, "%g %g %g %g %g %g %g %g %g\n",
//         d_params[0]*dt, d_params[1]*dt, xr, yr, d_params[2], d_params[3], d_params[4], d_params[5], d_params[6]);
//      fclose(fd);
//      mW.Write("CovD.txt");
         r_cov[4*c_point+0] = mW(0,0);
         r_cov[4*c_point+1] = mW(1,0);
         r_cov[4*c_point+2] = mW(0,1);
         r_cov[4*c_point+3] = mW(1,1);
#endif
   }

   delete [] potential_grid_scores;
   delete [] ipotential_temp;
   delete [] potential_grid_params;


   // of delete
   delete [] wim_left;
   delete [] wim_right;
   delete [] gimx_right;
   delete [] gimy_right;
   delete [] xGIof[0];
   delete [] xGIof[1];
   delete [] xGIof[2];
   delete [] xGIof;

   delete [] wim_diff;
   delete [] wghtBw_of;
   delete [] of_wght;

   delete [] giig;

   delete [] Ch_left;
   delete [] Ch_right;
   delete [] wghtBw;

   for (c_kernel = 0; c_kernel<n_kernels; c_kernel++)
   {
      delete [] xGI[c_kernel];
      delete [] pu[c_kernel];
      delete [] qu[c_kernel];
      delete [] pq_dif[c_kernel];
   }

   delete [] valid_colors;
   delete [] xGI;
   delete [] pu;
   delete [] qu;
   delete [] pq_dif;
   return 0;
}


int BgCdOfTracker::MainMatch(BgImage* im0, BgImage* im1, BgPoints2D* pt0, BgPoints2D* pt1, double* score)
{

   int npoints = pt0->n_;
   int wx0, wy0, wx1, wy1;
   int i;

   wx0 = im0->GetWidth();
   wy0 = im0->GetHeight();
   wx1 = im1->GetWidth();
   wy1 = im1->GetHeight();

   // build the image pyramids
   pyramidL_.BuildPyramid(*im0, pyrLevels_, pyrRatio_, pyramidType_, pyrFSize_);
   pyramidR_.BuildPyramid(*im1, pyrLevels_, pyrRatio_, pyramidType_, pyrFSize_);
   
   // call the matcher 
   double* ptin;
   double* ptout;
   double* pt_cov;
   pt_cov = 0;

   ptin= new double[2*npoints];
   ptout = new double[2*npoints];

#ifdef CDOF_TEST_COV
   pt_cov = new double[4*npoints];
#endif

   pt0->GetPoints(ptin);
   pt1->GetPoints(ptout);

   // !! image normalization
   // !! initial parameters set for all points
   double *scorep, *params;
   if (score == 0)
   {
      scorep = new double[npoints];
   } else
   {
      scorep = score;
   }

   double best_c = 1.0;

   /*
   // mean norm
   int ridx = 0;
   int lidx = 0;
   double *c_imr, *c_iml;
   int c_level;
   int szr, szl;
   for (c_level = 0; c_level<pyrLevels_; c_level++)
   {
      c_imr = &pyramidR_.pyramid_[3*ridx];
      c_iml = &pyramidL_.pyramid_[3*lidx];
      szr = pyramidR_.wx_[c_level]*pyramidR_.wy_[c_level];
      szl = pyramidL_.wx_[c_level]*pyramidL_.wy_[c_level];
      ridx += szr;
      lidx += szl;
   }
   double mnr = 0;
   double mnl = 0;
   ridx = 0;
   while(ridx<3*szr)
   {
      mnr += 0.299*c_imr[ridx]+0.587*c_imr[ridx+1]+0.114*c_imr[ridx+2];
      ridx += 3;
   }
   mnr /= szr;
   lidx = 0;
   while(lidx<3*szl)
   {
      mnl += 0.299*c_iml[lidx]+0.587*c_iml[lidx+1]+0.114*c_iml[lidx+2];
      lidx += 3;
   }
   mnl /= szl;
   best_c = mnr/mnl;
   */

   
   /*
   // do some image statistics to determine global luminance
   int ridx = 0;
   int lidx = 0;
   double *c_imr, *c_iml;
   int c_level;
   int szr, szl;
   for (c_level = 0; c_level<pyrLevels_; c_level++)
   {
      c_imr = &pyramidR_.pyramid_[3*ridx];
      c_iml = &pyramidL_.pyramid_[3*lidx];
      szr = pyramidR_.wx_[c_level]*pyramidR_.wy_[c_level];
      szl = pyramidL_.wx_[c_level]*pyramidL_.wy_[c_level];
      ridx += szr;
      lidx += szl;
   }
   double *pu, *qu;
   double cpu, cqu;
   int n_bins = BG_CDOF_NBINS;
   int n_bins2 = n_bins*n_bins;
   int n_bins3 = n_bins*n_bins*n_bins;
   pu = new double[n_bins3];
   qu = new double[n_bins3];
   double cR, cG, cB;
   memset(pu,0, sizeof(double)*n_bins3);
   lidx = 0;
   cpu = 1.0/szl;
   int cu_idx;
   while (lidx<3*szl)
   {
      cR = c_iml[lidx++];
      cG = c_iml[lidx++];
      cB = c_iml[lidx++];
      cu_idx = ((int) (cR*n_bins)) + ((int) (cG*n_bins))*n_bins + ((int) (cB*n_bins))*n_bins2;
      pu[cu_idx] += cpu;
   }

   cqu = 1.0/szr;
   double bgc_list[] = {0.8, 0.9, 1.0, 1.1, 1.2};
   int nbgc = 5;
   best_c = 1e100;
   int ibest_c = 2;
   for (i=nbgc-1; i>=0; i--)
   {
      double cval = bgc_list[i];
      memset(qu,0, sizeof(double)*n_bins3);
      ridx = 0;
      cqu = 1.0/szr;
      while (ridx<3*szr)
      {
         cR = cval*c_imr[ridx++];
         cG = cval*c_imr[ridx++];
         cB = cval*c_imr[ridx++];
         if (cR>0.9961)
            cR = 0.9961;
         if (cG>0.9961)
            cG = 0.9961;
         if (cB>0.9961)
            cB = 0.9961;
         cu_idx = ((int) (cR*n_bins)) + ((int) (cG*n_bins))*n_bins + ((int) (cB*n_bins))*n_bins2;
         qu[cu_idx] += cqu;
      }
      double cdist = 0;
      for (ridx=0; ridx<n_bins3; ridx++)
      {
         cdist += (pu[ridx]-qu[ridx])*(pu[ridx]-qu[ridx]);
      }
      if (cdist<best_c)
      {
         best_c = cdist;
         ibest_c = i;
      }
   }

   delete [] qu;
   delete [] pu;
   best_c = bgc_list[ibest_c];
   */

   params = new double[7*npoints];
   for (i=0; i<npoints; i++)
   {
      params[7*i+0] = 1.0;
      params[7*i+1] = 1.0;
      params[7*i+2] = 0.0;
      params[7*i+3] = 0.0;
      params[7*i+4] = 0.0;
      params[7*i+5] = 0.0;
      params[7*i+6] = best_c;
   }



   GMatchPoints(ptin, npoints, ptout, scorep, params, pt_cov);

#ifdef BGCDOF_SAVELR
   if(fullsave_ == 1)
   {
   // save the full points
   FILE* fd;
   fd = fopen("pt_left.txt", "wb");
   fprintf(fd, "%d\n", npoints);
   for (i=0; i<npoints; i++)
   {
      fprintf(fd, "%g %g %g %g %g %g %g %g %g %g\n", 
         ptin[2*i+0], ptin[2*i+1], (double) dt_, (double) dt_,
         0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
      // covariance ?
      fprintf(fd, "%g %g\n%g %g\n", 1.0, 0.0, 0.0, 1.0);
   }
   fclose(fd);

   fd = fopen("pt_right.txt", "wb");
   fprintf(fd, "%d\n", npoints);
   for (i=0; i<npoints; i++)
   {
      fprintf(fd, "%g %g %g %g %g %g %g %g %g %g\n", 
         ptout[2*i+0], ptout[2*i+1], params[7*i+0]*dt_, params[7*i+1]*dt_,
         params[7*i+2], params[7*i+3], params[7*i+4], params[7*i+5], params[7*i+6], scorep[i]);
      // covariance ?
#ifdef CDOF_TEST_COV
      fprintf(fd, "%g %g\n%g %g\n", pt_cov[4*i+0], pt_cov[4*i+2], pt_cov[4*i+1], pt_cov[4*i+3]);
#else
      fprintf(fd, "%g %g\n%g %g\n", 1.0, 0.0, 0.0, 1.0);
#endif
   }
   fclose(fd);
   bgLog("full parameters saved in: pt_left.txt, pt_right.txt\n");
   }
#endif

#ifdef CDOF_TEST_COV
   delete [] pt_cov;
#endif

   pt1->SetPoints(ptout, npoints);

   if (score == 0)
      delete [] scorep;
   delete [] params;


   delete [] ptin;
   delete [] ptout;
   return 0;
}
